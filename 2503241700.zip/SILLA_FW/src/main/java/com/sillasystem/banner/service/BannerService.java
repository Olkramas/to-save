/**
 * 
 * 배너관리 Service
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.banner.service;

import org.springframework.data.domain.Page;


public interface BannerService {
	
	public Page<BannerVO> getBannerList(BannerVO vo) throws Exception;
		
	public BannerVO selectBannerDetail(BannerVO vo) throws Exception;
		
	public void insertBanner(BannerVO vo) throws Exception;
	
	public void removeBanner(BannerVO vo) throws Exception;
	
	public void removeChkBanner(BannerVO vo) throws Exception;
	
}
