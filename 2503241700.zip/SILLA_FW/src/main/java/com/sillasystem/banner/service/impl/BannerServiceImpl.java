/**
 * 
 * 배너관리 Service Impl
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.banner.service.impl;

import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;

import com.sillasystem.banner.repository.BannerRepository;
import com.sillasystem.banner.repository.SearchSpec;
import com.sillasystem.banner.service.BannerService;
import com.sillasystem.banner.service.BannerVO;


@Service("bannerService")
public class BannerServiceImpl implements BannerService {
	
	@Resource(name="bannerRepository")
	BannerRepository bannerRepository;
	
	// 배너 리스트
	public Page<BannerVO> getBannerList(BannerVO vo) throws Exception{
		
		// 페이징 셋팅
		int pageNum = vo.getPageIndex() - 1;
		PageRequest page = new PageRequest(pageNum , 10, new Sort(Direction.DESC,"seq"));
	
		// 삭제한거는 안나오게 필터링
		Specifications<Content> spec = Specifications.where(SearchSpec.delYnEquals("N"));
		
		// 제목 검색
		if(vo.getSearchTxt() != null && !vo.getSearchTxt().equals("")) {
			spec = spec.and(SearchSpec.titleLike(vo.getSearchTxt()));
		}
				
		// 시작날짜 검색
		if(vo.getSearchStartDt() != null && !vo.getSearchStartDt().equals("")) {
			// String > Date 변환						
			String[] tmpStr = vo.getSearchStartDt().split("-");
			int searchYear = Integer.parseInt(tmpStr[0]);
			int searchMonth = Integer.parseInt(tmpStr[1]) - 1;
			int searchDay = Integer.parseInt(tmpStr[2]);
			Calendar cal = Calendar.getInstance();			
			cal.set(searchYear, searchMonth, searchDay, 0,0,0);
			cal.set(Calendar.MILLISECOND,0);			
			Date dt = cal.getTime();
			
			// 검색 조건 추가
			spec = spec.and(SearchSpec.regDtGreater(dt));
		}
		
		// 종료날짜 검색
		if(vo.getSearchEndDt() != null && !vo.getSearchEndDt().equals("")) {			
			// String > Date 변환						
			String[] tmpStr = vo.getSearchEndDt().split("-");
			int searchYear = Integer.parseInt(tmpStr[0]);
			int searchMonth = Integer.parseInt(tmpStr[1]) - 1;
			int searchDay = Integer.parseInt(tmpStr[2]);
			Calendar cal = Calendar.getInstance();			
			cal.set(searchYear, searchMonth, searchDay, 23,59,59);
			cal.set(Calendar.MILLISECOND,0);			
			Date dt = cal.getTime();
			
			// 검색조건 추가
			spec = spec.and(SearchSpec.regDtLess(dt));
		}
		
		
		// JPA 호출
		Page<BannerVO> itemList = (Page<BannerVO>) bannerRepository.findAll(spec,page);
		return itemList;
		
	}
	
	// 배너 상세보기
	public BannerVO selectBannerDetail(BannerVO vo) throws Exception{
		return bannerRepository.findOneBySeq(vo.getSeq());
	}
	
	// 배너 등록/수정
	public void insertBanner(BannerVO vo) throws Exception{		
		bannerRepository.saveAndFlush(vo);
	}
	
	
	// 배너 삭제
	public void removeBanner(BannerVO vo) throws Exception{
		
		int seq = vo.getSeq();
		String updId = vo.getUpdId();		
		bannerRepository.updateDelYn(seq,updId);
		
	}
	
	// 배너 선택 삭제
	public void removeChkBanner(BannerVO vo) throws Exception{
		
		String[] chkSeq = vo.getChkDel().split(",");
		String updId = vo.getUpdId();		
		for(int i = 0;i < chkSeq.length;i++) {
			int seq = Integer.parseInt(chkSeq[i]);			
			bannerRepository.updateDelYn(seq,updId);			
		}
		
	}

}
