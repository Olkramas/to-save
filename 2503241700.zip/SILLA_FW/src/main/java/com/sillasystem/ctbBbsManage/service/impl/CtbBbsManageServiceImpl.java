package com.sillasystem.ctbBbsManage.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sillasystem.bbsManage.service.BbsManageService;
import com.sillasystem.ctbBbsManage.dao.CtbBbsManageDAO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("ctbBbsManageService")
public class CtbBbsManageServiceImpl extends EgovAbstractServiceImpl implements BbsManageService {
	
    @Resource(name = "ctbBbsManageDAO")
    private CtbBbsManageDAO bbsManageDAO;
    
    //게시판 목록 조회
    @Override
    public Map<String, Object> bbsManageList(Map<String,Object> paramMap) throws  Exception{
        List<EgovMap> result = bbsManageDAO.selectbbsManageList(paramMap);
        int cnt = bbsManageDAO.bbsManageListCnt(paramMap);

        Map<String,Object> map = new HashMap<>();
        map.put("resultList", result);
        map.put("resultCnt", Integer.toString(cnt));

        return map;
    }

    @Override
    public EgovMap selectBbsMastView(Map<String,Object> paramMap) throws Exception {
        return bbsManageDAO.selectBbsMastView(paramMap);
    }

    @Override
    public List<EgovMap> selectBbsMastManagerList(Map<String,Object> paramMap) throws Exception {
        return bbsManageDAO.selectBbsMastManagerList(paramMap);
    }

    @Override
    public void insertBbsManage(Map<String,Object> paramMap) throws Exception {
        //bbsMast등록
        bbsManageDAO.insertBbsMast(paramMap);
        
        //regLevel이 게시판 관리자 권한.
        String[] regLevel = (String[]) paramMap.get("regLevel");
        //bbsManager
        if (regLevel.length > 0){

            for (String groupId : regLevel){
                if (groupId.length() > 0 && !groupId.equals("")){
                    paramMap.put("groupId", groupId);
                    bbsManageDAO.insertBbsManager(paramMap);
                }
            }
        }

    }

    @Override
    public void updateBbsManage(Map<String,Object> paramMap) throws Exception {
        //bbsMast
        bbsManageDAO.updateBbsMast(paramMap);

        String[] regLevel = (String[]) paramMap.get("regLevel");
        //bbsManager
        if (regLevel.length > 0){
            //없는거 삭제
            bbsManageDAO.deleteBbsManager(paramMap);

            for (String groupId : regLevel){
                if (groupId.length() > 0 && !groupId.equals("")){
                    paramMap.put("groupId", groupId);
                    bbsManageDAO.insertBbsManager(paramMap);
                }
            }
        }

    }

	@Override
	public int duplicateCheck(Map<String, Object> paramMap) throws Exception {
		return bbsManageDAO.duplicateCheck(paramMap);
	}

	@Override
    public void deleteBbsMast(Map<String,Object> paramMap) throws Exception {
        bbsManageDAO.deleteBbsMast(paramMap);
    }

	@Override
	public EgovMap selectOffenseWordsMap() throws Exception {
		return bbsManageDAO.selectOffenseWordsMap();
	}

	@Override
	public void updateOffenseWordsManage(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EgovMap selectBbsCategoryDetail(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EgovMap> selectBbsCategoryList(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void mergeBbsCategory(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBbsCategory(Map<String, Object> paramMap) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
