package com.sillasystem.ctbBbsManage.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sillasystem.bbsManage.service.BbsManageService;
import com.sillasystem.member.service.EgovUserManageService;
import com.sillasystem.member.service.UserManageVO;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class CtbBbsManageController {
	
	
    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** bbsManageService **/
    @Resource(name = "ctbBbsManageService")
    protected BbsManageService bbsManageService;
	
    /** cmmUseService */
    @Resource(name = "EgovCmmUseService")
    private EgovCmmUseService cmmUseService;
    
    /** userManageService */
    @Resource(name = "userManageService")
    private EgovUserManageService userManageService;
    
    /**
     * 게시판 조회
     * @param paramMap
     * @param request
     * @param response
     * @param session
     * @param map
     * @return
     * @throws Exception
     */
	@RequestMapping("/ctbBoardManage/list.do")
	public String ctbBbsList(@RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            ModelMap map) throws Exception{
		if (paramMap.containsKey("pageIndex") == false || StringUtils.isEmpty(String.valueOf(paramMap.get("pageIndex")) ) == true){
            paramMap.put("pageIndex","1");
        }
		//페이징 관련
        PaginationInfo paginationInfo = new PaginationInfo();

        paginationInfo.setCurrentPageNo(Integer.parseInt(String.valueOf(paramMap.get("pageIndex"))));
        paginationInfo.setRecordCountPerPage(propertiesService.getInt("pageUnit"));
        paginationInfo.setPageSize(propertiesService.getInt("pageSize"));

        paramMap.put("firstIndex", paginationInfo.getFirstRecordIndex());
        paramMap.put("lastIndex", paginationInfo.getLastRecordIndex());
        paramMap.put("recordCountPerPage",paginationInfo.getRecordCountPerPage());
        
        //게시판 리스트 가져오기
        Map<String, Object> modelMap = bbsManageService.bbsManageList(paramMap);
        
        //게시판 총 개수
        int totCnt = Integer.parseInt((String)modelMap.get("resultCnt"));
        paginationInfo.setTotalRecordCount(totCnt);
        
        map.addAttribute("bbsMastList", modelMap.get("resultList"));
        map.addAttribute("resultCnt", modelMap.get("resultCnt"));
        map.addAttribute("paginationInfo", paginationInfo);
        map.addAttribute("paramMap", paramMap);

		return "com/sillasystem/ctbBbsManage/ctbBbsList";
	}
	
	/**
     * 게시판 등록 / 수정 페이지 이동
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
	@RequestMapping(value = "/ctbBoardManage/bbsManageRegForm.do")
    public String bbsManageRegForm(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {
		
        ComDefaultCodeVO vo = new ComDefaultCodeVO();

        //게시판 종류
        vo.setCodeId("SIL002");
        
        //공통 코드 리스트에서 select한 내용. 게시판 유형관련 공통코드 내용들 
        List<?> boardType = cmmUseService.selectCmmCodeDetail(vo);
        map.addAttribute("boardType",boardType);
        
        //게시판 스킨. 하나밖에 없음
        vo.setCodeId("SIL003");
        List<?> boardSkin = cmmUseService.selectCmmCodeDetail(vo);
        map.addAttribute("boardSkin",boardSkin);
        
        //권한 가져오기 같음. 원래는 Y였는데, system은 A임.
        List<UserManageVO> memberAuthList = userManageService.selectAuthorInfo("A");
        map.addAttribute("memberAuthList", memberAuthList);

        //수정: 게시판 id(bbsId)가 null이 아니거나 공백이 아닌경우 
        if(paramMap.get("bbsId") != null && !String.valueOf(paramMap.get("bbsId")).equals("")){
            //데이터를 가져오는 것 같음 수정 기능 시작하면 해보기 일단 나중에
        	map.addAttribute("bbsMastView", bbsManageService.selectBbsMastView(paramMap));
            map.addAttribute("bbsMastManagerList", bbsManageService.selectBbsMastManagerList(paramMap));
            //map.addAttribute("categoryList", bbsManageService.selectBbsCategoryList(paramMap));
        }

        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/ctbBbsManage/ctbRegForm";
    }
	
	/**
     * 게시판 id 중복체크
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBoardManage/ctbDuplicateCheckAjax.do", method=RequestMethod.POST)
    public ModelAndView duplicateCheckAjax(
            @RequestParam Map<String,Object> paramMap
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");

        mv.addObject("result", bbsManageService.duplicateCheck(paramMap));

        return mv;
    }
	
    /**
     * 게시판 관리 등록 프로세스
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBoardManage/ctbBbsManageWriteAjax.do", method = RequestMethod.POST)
    public ModelAndView bbsManageWriteAjax(
            @RequestParam Map<String,Object> paramMap,
            @RequestParam(value = "regLevel", defaultValue = "") String[] regLevel
    ) throws Exception {
        ModelAndView mv = new ModelAndView("jsonView");

        paramMap.put("regLevel", regLevel);
        
        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());

        bbsManageService.insertBbsManage(paramMap);

        return mv;
    }
    
    /**
     * 게시판 관리 수정 프로세스
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBoardManage/ctbBbsManageUpdateAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsManageUpdateAjax(
            @RequestParam Map<String,Object> paramMap,
            @RequestParam(value = "regLevel", defaultValue = "") String[] regLevel
    ) throws Exception {
        ModelAndView mv = new ModelAndView("jsonView");

        paramMap.put("regLevel", regLevel);

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId",user.getId());
        paramMap.put("updId",user.getId());

        bbsManageService.updateBbsManage(paramMap);

        return mv;
    }
    
    /**
     * 게시판 삭제
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBoardManage/ctbBbsDeleteAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsDeleteAjax(
            @RequestParam Map<String,Object> paramMap
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId",user.getId());
        paramMap.put("updId",user.getId());

        //삭제처리 DEL_YN -> Y
        bbsManageService.deleteBbsMast(paramMap);

        return mv;
    }
}
