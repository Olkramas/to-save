package com.sillasystem.roleGroup.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.roleGroup.service.RoleGroup;
import com.sillasystem.roleGroup.service.RoleGroupVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;



@Repository("authorGroupDAO")
public class RoleGroupDAO extends EgovComAbstractDAO{
	/**
	 * 그룹별 할당된 권한 목록 조회
	 * @param authorGroupVO AuthorGroupVO
	 * @return List<AuthorGroupVO>
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RoleGroupVO> selectAuthorGroupList(RoleGroupVO authorGroupVO) throws Exception {
		return (List<RoleGroupVO>) list("authorGroupDAO.selectAuthorGroupList", authorGroupVO);
	}
	
	/**
	 * 그룹에 권한정보를 할당하여 데이터베이스에 등록
	 * @param authorGroup AuthorGroup
	 * @exception Exception
	 */
	public void insertAuthorGroup(RoleGroup authorGroup) throws Exception {
		insert("authorGroupDAO.insertAuthorGroup", authorGroup);
	}
	
	/**
	 * 화면에 조회된 그룹권한정보를 수정하여 항목의 정합성을 체크하고 수정된 데이터를 데이터베이스에 반영
	 * @param authorGroup AuthorGroup
	 * @exception Exception
	 */
	public void updateAuthorGroup(RoleGroup authorGroup) throws Exception {
		update("authorGroupDAO.updateAuthorGroup", authorGroup);
	}
	
	/**
	 * 그룹별 할당된 시스템 메뉴 접근권한을 삭제
	 * @param authorGroup AuthorGroup
	 * @exception Exception
	 */
	public void deleteAuthorGroup(RoleGroup authorGroup) throws Exception {
		delete("authorGroupDAO.deleteAuthorGroup", authorGroup);
	}

    /**
	 * 그룹권한목록 총 갯수를 조회한다.
	 * @param authorGroupVO AuthorGroupVO
	 * @return int
	 * @exception Exception
	 */
    public int selectAuthorGroupListTotCnt(RoleGroupVO authorGroupVO) throws Exception {
        return (Integer)selectOne("authorGroupDAO.selectAuthorGroupListTotCnt", authorGroupVO);
    }
}
