package com.sillasystem.bat.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sillasystem.bat.service.BatOpertService;
import com.sillasystem.bat.vo.BatOpertVO;
@Service("batOpertService")
public class BatOpertServiceimpl implements BatOpertService{
	
	
	@Resource(name = "batOpertDao")
	private BatOpertDAO dao;
	/**
	 * 배치작업의 목록을 조회 한다.
	 * @return 배치작업목록
	 *
	 * @param searchVO 	조회정보가 담긴 VO
	 * @exception Exception Exception
	 */
	@Override
	public List<BatOpertVO> selectBatchOpertList(BatOpertVO searchVO) throws Exception {
		List<BatOpertVO> result = dao.selectBatchOpertList(searchVO);
		return result;
	}
	/**
	 * 배치작업 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 * @exception Exception Exception
	 */
	@Override
	public int selectBatchOpertListCnt(BatOpertVO searchVO) throws Exception {
		int cnt = dao.selectBatchOpertListCnt(searchVO);
		return cnt;
	}
	@Override
	public void deleteBatchOpert(BatOpertVO batchOpert) throws Exception {
		dao.deleteBatchOpert(batchOpert);
		
	}
	@Override
	public void insertBatchOpert(BatOpertVO batchOpert) throws Exception {
		dao.insertBatchOpert(batchOpert);
		
	}
	@Override
	public BatOpertVO selectBatchOpert(BatOpertVO batchOpert) throws Exception {
		return dao.selectBatchOpert(batchOpert);
	}
	@Override
	public void updateBatchOpert(BatOpertVO batchOpert) throws Exception {
		dao.updateBatchOpert(batchOpert);
	}

}
