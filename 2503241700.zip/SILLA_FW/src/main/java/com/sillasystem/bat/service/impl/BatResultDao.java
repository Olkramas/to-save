package com.sillasystem.bat.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.bat.vo.BatResultVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

@Repository("batResultDao")
public class BatResultDao extends EgovComAbstractDAO{
	/**
	 * 배치결과을 삭제한다.
	 *
	 * @param batchResult    삭제할 배치결과 VO
	 * @exception Exception Exception
	 */
	public void deleteBatchResult(BatResultVO batchResult) throws Exception {
		delete("batResultDao.deleteBatchResult", batchResult);
	}

	/**
	 * 배치결과을 등록한다.
	 *
	 * @param batchResult 저장할 배치결과 VO
	 * @exception Exception Exception
	 */
	public void insertBatchResult(BatResultVO batchResult) throws Exception {
		insert("batResultDao.insertBatchResult", batchResult);
	}

	/**
	 * 배치결과정보를 상세조회 한다.
	 * @return 배치결과정보
	 *
	 * @param batchResult    조회할 KEY가 있는 배치결과 VO
	 * @exception Exception Exception
	 */
	public BatResultVO selectBatchResult(BatResultVO batchResult) throws Exception {
		return (BatResultVO) selectOne("batResultDao.selectBatchResult", batchResult);
	}

	/**
	 * 배치결과정보목록을  조회한다.
	 * @return 배치결과목록
	 *
	 * @param searchVO    조회조건이 저장된 VO
	 * @exception Exception Exception
	 */
	public List<?> selectBatchResultList(BatResultVO searchVO) throws Exception {
		return selectList("batResultDao.selectBatchResultList", searchVO);
	}

	/**
	 * 배치결과 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 * @exception Exception Exception
	 */
	public int selectBatchResultListCnt(BatResultVO searchVO) throws Exception {
		return (Integer) selectOne("batResultDao.selectBatchResultListCnt", searchVO);
	}

	/**
	 * 배치결과정보를 수정한다.
	 *
	 * @param batchResult    수정대상 배치결과 VO
	 * @exception Exception Exception
	 */
	public void updateBatchResult(BatResultVO batchResult) throws Exception {
		update("batResultDao.updateBatchResult", batchResult);
	}

}
