package com.sillasystem.bat.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sillasystem.bat.service.BatResultService;
import com.sillasystem.bat.vo.BatResultVO;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import egovframework.com.cmm.util.EgovUserDetailsHelper;

@Controller
public class BatResultController {
	/** egovBatchResultService */
	@Resource(name = "batResultService")
	private BatResultService batResultService;

	/* Property 서비스 */
	@Resource(name = "propertiesService")
	private EgovPropertyService propertyService;

	/*  메세지 서비스 */
	@Resource(name = "egovMessageSource")
	private EgovMessageSource egovMessageSource;
	
	/** logger */
	//private static final Logger LOGGER = LoggerFactory.getLogger(EgovBatchResultController.class);
	
	/**
	 * 배치결과 목록을 조회한다.
	 * @return 리턴URL
	 *
	 * @param searchVO 목록조회조건VO
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@SuppressWarnings("unchecked")
	//@IncludedInfo(name = "배치결과관리", listUrl = "/batresult/list.do", order = 1121, gid = 80)
	@RequestMapping("/batresult/list.do")
	public String ListBatchOpert(@ModelAttribute("searchVO") BatResultVO searchVO, ModelMap model) throws Exception {
		searchVO.setPageUnit(propertyService.getInt("pageUnit"));
		searchVO.setPageSize(propertyService.getInt("pageSize"));
		
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<BatResultVO> resultList = (List<BatResultVO>) batResultService.selectBatchResultList(searchVO);
		int totCnt = batResultService.selectBatchResultListCnt(searchVO);

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", resultList);
		model.addAttribute("resultCnt", totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		return "com/sillasystem/bat/batchResultList";
	}
	
	/**
	 * 배치결과을 삭제한다.
	 * @return 리턴URL
	 *
	 * @param batchResult 삭제대상 배치결과model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batresult/delete.do")
	public String deleteBatchResult(BatResultVO batchResult, ModelMap model) throws Exception {
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}

		batResultService.deleteBatchResult(batchResult);

		return "forward:/batresult/list.do";
	}

	/**
	 * 배치결과정보을 상세조회한다.
	 * @return 리턴URL
	 *
	 * @param batchResult 조회대상 배치결과model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batresult/detail.do")
	public String selectBatchResult(@ModelAttribute("searchVO") BatResultVO batchResult, ModelMap model) throws Exception {
		//LOGGER.debug(" 조회조건 : {}", batchResult);
		BatResultVO result = batResultService.selectBatchResult(batchResult);
		model.addAttribute("resultInfo", result);
		//LOGGER.debug(" 결과값 : {}", result);

		return "com/sillasystem/bat/batchResultDetail";
	}
}
