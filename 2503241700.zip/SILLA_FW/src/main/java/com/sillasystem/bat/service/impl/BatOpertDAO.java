package com.sillasystem.bat.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.bat.vo.BatOpertVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

@Repository("batOpertDao")
public class BatOpertDAO extends EgovComAbstractDAO{
	public List<BatOpertVO> selectBatchOpertList(BatOpertVO searchVO) throws Exception {
 		return selectList("batOpertDao.selectBatchOpertList", searchVO);
	}
	
	public int selectBatchOpertListCnt(BatOpertVO searchVO) throws Exception {
		return (Integer) selectOne("batOpertDao.selectBatchOpertListCnt", searchVO);
	}
	
	/**
	 * 배치작업정보를 수정한다.
	 *
	 * @param batchOpert    수정대상 배치작업 VO
	 * @exception Exception Exception
	 */
	public void updateBatchOpert(BatOpertVO batchOpert) throws Exception {
		update("batOpertDao.updateBatchOpert", batchOpert);
	}
	
	/**
	 * 배치작업을 삭제한다.
	 *
	 * @param batchOpert    삭제할 배치작업 VO
	 * @exception Exception Exception
	 */
	public void deleteBatchOpert(BatOpertVO batchOpert) throws Exception {
		delete("batOpertDao.deleteBatchOpert", batchOpert);
	}

	/**
	 * 배치작업을 등록한다.
	 *
	 * @param batchOpert 저장할 배치작업 VO
	 * @exception Exception Exception
	 */
	public void insertBatchOpert(BatOpertVO batchOpert) throws Exception {
		insert("batOpertDao.insertBatchOpert", batchOpert);
	}
	
	/**
	 * 배치작업정보를 상세조회 한다.
	 * @return 배치작업정보
	 *
	 * @param batchOpert    조회할 KEY가 있는 배치작업 VO
	 * @exception Exception Exception
	 */
	public BatOpertVO selectBatchOpert(BatOpertVO batchOpert) throws Exception {
		return (BatOpertVO) selectOne("batOpertDao.selectBatchOpert", batchOpert);
	}


}
