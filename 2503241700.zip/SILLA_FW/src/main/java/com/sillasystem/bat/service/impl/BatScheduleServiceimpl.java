package com.sillasystem.bat.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sillasystem.bat.service.BatScheduleService;
import com.sillasystem.bat.vo.BatResultVO;
import com.sillasystem.bat.vo.BatScheduleVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
@Service("batScheduleService")
public class BatScheduleServiceimpl extends EgovAbstractServiceImpl implements BatScheduleService{
	/**
	 * 배치스케줄DAO
	 */
	@Resource(name = "batSchdulDao")
	private BatSchdulDao batSchdulDao;

	/**
	 * 배치결과DAO
	 */
	@Resource(name = "batResultDao")
	private BatResultDao batResultDao;

	/**
	 * 배치스케줄을 삭제한다.
	 * @param batchSchdul    삭제대상 배치스케줄model
	 * @exception Exception Exception
	 */
	@Override
	public void deleteBatchSchdul(BatScheduleVO batchSchdul) throws Exception {
		batSchdulDao.deleteBatchSchdul(batchSchdul);
	}

	/**
	 * 배치스케줄을 등록한다.
	 * @param batchSchdul    등록대상 배치스케줄model
	 * @exception Exception Exception
	 */
	@Override
	public void insertBatchSchdul(BatScheduleVO batchSchdul) throws Exception {
		batSchdulDao.insertBatchSchdul(batchSchdul);
	}

	/**
	 * 배치스케줄을 상세조회 한다.
	 * @return 배치스케줄정보
	 *
	 * @param batchSchdul 조회대상 배치스케줄model
	 * @exception Exception Exception
	 */
	@Override
	public BatScheduleVO selectBatchSchdul(BatScheduleVO batchSchdul) throws Exception {
		return batSchdulDao.selectBatchSchdul(batchSchdul);
	}

	/**
	 * 배치스케줄의 목록을 조회 한다.
	 * @return 배치스케줄목록
	 *
	 * @param searchVO 	조회정보가 담긴 VO
	 * @exception Exception Exception
	 */
	@Override
	public List<?> selectBatchSchdulList(BatScheduleVO searchVO) throws Exception {
		List<?> result = batSchdulDao.selectBatchSchdulList(searchVO);
		return result;
	}

	/**
	 * 배치스케줄 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 * @exception Exception Exception
	 */
	@Override
	public int selectBatchSchdulListCnt(BatScheduleVO searchVO) throws Exception {
		int cnt = batSchdulDao.selectBatchSchdulListCnt(searchVO);
		return cnt;
	}

	/**
	 * 배치스케줄정보를 수정한다.
	 *
	 * @param batchSchdul    수정대상 배치스케줄model
	 * @exception Exception Exception
	 */
	@Override
	public void updateBatchSchdul(BatScheduleVO batchSchdul) throws Exception {
		batSchdulDao.updateBatchSchdul(batchSchdul);
	}

	/**
	 * 배치결과를 등록한다.
	 * @param batchResult    등록대상 배치결과model
	 * @exception Exception Exception
	 */
	@Override
	public void insertBatchResult(BatResultVO batchResult) throws Exception {
		batResultDao.insertBatchResult(batchResult);
	}

	/**
	 * 배치결과정보를 수정한다.
	 *
	 * @param batchResult    수정대상 배치결과model
	 * @exception Exception Exception
	 */
	@Override
	public void updateBatchResult(BatResultVO batchResult) throws Exception {
		batResultDao.updateBatchResult(batchResult);
	}
}
