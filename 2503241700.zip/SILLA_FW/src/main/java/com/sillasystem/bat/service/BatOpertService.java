package com.sillasystem.bat.service;

import java.util.List;

import com.sillasystem.bat.vo.BatOpertVO;

public interface BatOpertService {
	/**
	 * 배치작업 목록을 조회한다.
	 * @return 배치작업목록
	 *
	 * @param searchVO    조회조건VO
	 * @exception Exception Exception
	 */
	public List<BatOpertVO> selectBatchOpertList(BatOpertVO searchVO) throws Exception;
	/**
	 * 배치작업 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 * @exception Exception Exception
	 */
	public int selectBatchOpertListCnt(BatOpertVO searchVO) throws Exception;
	
	/**
	 * 배치작업을  삭제한다.
	 *
	 * @param batchOpert    삭제대상 배치작업model
	 * @exception Exception Exception
	 */
	public void deleteBatchOpert(BatOpertVO batchOpert) throws Exception;

	/**
	 * 배치작업을 등록한다.
	 *
	 * @param batchOpert    등록대상 배치작업model
	 * @exception Exception Exception
	 */
	public void insertBatchOpert(BatOpertVO batchOpert) throws Exception;

	/**
	 * 배치작업을  상세조회 한다.
	 * @return 배치작업정보
	 *
	 * @param batchOpert    조회대상 배치작업model
	 * @exception Exception Exception
	 */
	public BatOpertVO selectBatchOpert(BatOpertVO batchOpert) throws Exception;


	
	/**
	 * 배치작업을 수정한다.
	 *
	 * @param batchOpert    수정대상 배치작업model
	 * @exception Exception Exception
	 */
	public void updateBatchOpert(BatOpertVO batchOpert) throws Exception;
	
	
	
	
}
