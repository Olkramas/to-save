package com.sillasystem.bbsArticle.service.impl;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository("bbsArticleDAO")
public class BbsArticleDAO extends EgovComAbstractDAO {

    public List<EgovMap> selectBbsArticleList(Map<String,Object> paramMap) throws Exception{
        return (List<EgovMap>) list("bbsArticleDAO.selectBbsArticleList", paramMap);
    }

    public int selectBbsArticleListCnt (Map<String,Object> paramMap) throws Exception {
        return (Integer)selectOne("bbsArticleDAO.selectBbsArticleListCnt", paramMap);
    }

    public EgovMap selectBbsArticleView (Map<String,Object> paramMap) throws Exception {
        return selectOne("bbsArticleDAO.selectBbsArticleView", paramMap);
    }

    public List<EgovMap> selectBbsArticleFileList (Map<String,Object> paramMap) throws Exception {
        return (List<EgovMap>) list("bbsArticleDAO.selectBbsArticleFileList",paramMap);
    }

    public void updateReadCnt (Map<String,Object> paramMap) throws Exception {
        update("bbsArticleDAO.updateReadCnt", paramMap);
    }

    public void insertBbsArticle (Map<String,Object> paramMap) throws Exception {
        insert("bbsArticleDAO.insertBbsArticle", paramMap);
    }

    public void updateBbsArticle (Map<String,Object> paramMap) throws Exception {
        update("bbsArticleDAO.updateBbsArticle", paramMap);
    }

    public void deleteBbsArticle (Map<String,Object> paramMap) throws Exception {
        update("bbsArticleDAO.deleteBbsArticle", paramMap);
    }

    public void updateBbsArticleBeforeAnswerInsert (Map<String,Object> paramMap) throws Exception {
        update("bbsArticleDAO.updateBbsArticleBeforeAnswerInsert", paramMap);
    }

}
