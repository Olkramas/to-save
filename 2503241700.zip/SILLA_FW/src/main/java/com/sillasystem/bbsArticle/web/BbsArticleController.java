package com.sillasystem.bbsArticle.web;

import com.sillasystem.bbsArticle.service.BbsArticleService;
import com.sillasystem.bbsManage.service.BbsManageService;
import com.sillasystem.common.SillaFileUtil;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.util.*;

@Controller
public class BbsArticleController {

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** bbsManageService **/
    @Resource(name = "bbsManageService")
    protected BbsManageService bbsManageService;

    /** bbsArticleService **/
    @Resource(name = "bbsArticleService")
    protected BbsArticleService bbsArticleService;

    @Resource(name = "egovFileIdGnrService")
    private EgovIdGnrService egovFileIdGnrService;

    /** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

    @Resource(name="sillaFileUtil")
    SillaFileUtil sillaFileUtil;


    /**
     * 게시글 리스트
     * @param paramMap
     * @param request
     * @param response
     * @param session
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/bbsArticle/list.do")
    public String bbsArticleList(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            ModelMap map
    ) throws Exception {

        if(paramMap.containsKey("pageIndex") == false || StringUtils.isEmpty(String.valueOf(paramMap.get("pageIndex"))) == true){
            paramMap.put("pageIndex", "1");
        }

        PaginationInfo paginationInfo = new PaginationInfo();

        paginationInfo.setCurrentPageNo(Integer.parseInt(String.valueOf(paramMap.get("pageIndex"))));
        paginationInfo.setRecordCountPerPage(propertiesService.getInt("pageUnit"));
        paginationInfo.setPageSize(propertiesService.getInt("pageSize"));

        paramMap.put("firstIndex", paginationInfo.getFirstRecordIndex());
        paramMap.put("lastIndex", paginationInfo.getLastRecordIndex());
        paramMap.put("recordCountPerPage",paginationInfo.getRecordCountPerPage());

        //게시판 설정 가져오기
        map.addAttribute("bbsMastView", bbsManageService.selectBbsMastView(paramMap));

        //게시글 리스트
        Map<String,Object> modelMap = bbsArticleService.selectBbsArticleList(paramMap);

        int totCnt = Integer.parseInt((String)modelMap.get("resultCnt"));
        paginationInfo.setTotalRecordCount(totCnt);


        map.addAttribute("bbsArticleList", modelMap.get("resultList"));
        map.addAttribute("resultCnt", totCnt);
        map.addAttribute("paginationInfo",paginationInfo);
        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/bbsArticle/"+paramMap.get("bbsType")+"/list";
    }

    /**
     * 게시글 등록 / 수정 폼
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/bbsArticle/bbsArticleRegForm.do")
    public String bbsArticleRegForm(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {

        //게시판 타입
        map.addAttribute("bbsMastView",bbsManageService.selectBbsMastView(paramMap));
        //게시판 카테고리
        map.addAttribute("bbscategoryList", bbsManageService.selectBbsCategoryList(paramMap));

        //수정
        if (paramMap.containsKey("seq")){

            //상세조회
            Map<String,Object> bbsArticleVO = bbsArticleService.selectBbsArticleView(paramMap);
            map.addAttribute("bbsArticleVO", bbsArticleVO);

            //첨부파일조회
            List<FileVO> fileList = sillaFileUtil.getFileList(String.valueOf(bbsArticleVO.get("atchFileId")));
            map.addAttribute("fileList", fileList);

        }

        //파라미터
        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/bbsArticle/"+paramMap.get("bbsType")+"/regForm";
    }

    /**
     * 게시글 뷰
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/bbsArticle/view.do")
    public String bbsArticleView(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {

        //상세조회
        Map<String,Object> bbsArticleVO = bbsArticleService.selectBbsArticleView(paramMap);
        map.addAttribute("bbsArticleVO", bbsArticleVO);

        //첨부파일조회
        List<FileVO> fileList = sillaFileUtil.getFileList(String.valueOf(bbsArticleVO.get("atchFileId")));
        map.addAttribute("fileList", fileList);

        //파라미터
        map.addAttribute("paramMap",paramMap);

        return "com/sillasystem/bbsArticle/"+paramMap.get("bbsType")+"/view";
    }

    /**
     * 게시글 등록 실행
     * @param request
     * @param response
     * @param modelMap
     * @return
     */
    @RequestMapping(value="/bbsArticle/bbsArticleRegAjax.do", method= RequestMethod.POST)
    public ModelAndView bbsArticleReg(
            final MultipartHttpServletRequest multiRequest
            , @RequestParam Map<String,Object> paramMap
            , HttpServletResponse response
            , ModelMap modelMap
            , HttpServletRequest request
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");

        //완료 또는 실패후 메시지
        Map<String,Object> resultMap = new HashMap<>();

        //위반단어검사
        ModelAndView modelAndView = offenseWordsCheck(paramMap);
        if (modelAndView != null){return modelAndView;}

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());

        //첨부파일
        String uploadPath = propertiesService.getString("Globals.fileStorePath") + "/bbs/";
        String retFileIda = sillaFileUtil.uploadFile(multiRequest, uploadPath, null);

        //첨부파일 성공이후 atchFileId return;
        paramMap.put("atchFileId", retFileIda);

        //게시글 등록
        bbsArticleService.insertBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.insert"));


        return mv;
    }

    /**
     * 게시글 수정 실행
     * @param multiRequest
     * @param response
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsArticle/bbsArticleModAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsArticleMod(
            final MultipartHttpServletRequest multiRequest
            , @RequestParam Map<String,Object> paramMap
            , HttpServletResponse response
            , ModelMap modelMap
            , HttpServletRequest request
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        //완료 또는 실패후 메시지
        Map<String,Object> resultMap = new HashMap<>();

        //위반단어검사
        ModelAndView modelAndView = offenseWordsCheck(paramMap);
        if (modelAndView != null){return modelAndView;}

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());

        //첨부파일
        String atchFileId = String.valueOf(paramMap.get("atchFileId"));
        String uploadPath = propertiesService.getString("Globals.fileStorePath") + "/bbs/";
        String retFileIda = sillaFileUtil.uploadFile(multiRequest, uploadPath, atchFileId);

        //첨부파일 성공이후 atchFileId return;
        paramMap.put("atchFileId", retFileIda);

        //게시글 수정
        bbsArticleService.updateBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.insert"));

        return mv;
    }


    /**
     * 첨부파일에 대한 목록 정보를 취득한다.
     * @param files
     * @param KeyStr
     * @param bbsSeq
     * @param storePath
     * @return
     * @throws Exception
     */
    public List<Map<String,Object>> bbsArticleParseFileInf(
            Map<String, MultipartFile> files,
            String KeyStr,
            int bbsSeq,
            String storePath
    ) throws Exception {


        return null;
    }

    /**
     * 파일 다운로드
     * @param requestedFile
     * @param originalFile
     * @param response
     * @param request
     * @throws Exception
     */
    @RequestMapping(value = "/bbsArticle/downloadFile.do")
    @ResponseBody
    public void downloadFile(
            @RequestParam(value = "requestedFile") String requestedFile,
            @RequestParam(value = "originalFile") String originalFile,
            HttpServletResponse response,
            HttpServletRequest request) throws Exception {


    }

    /**
     * 게시글 파일 삭제
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsArticle/bbsArticleDeleteFileAjax.do")
    public ModelAndView bbsArticleDeleteFileAjax(
            HttpSession session
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");


        return mv;
    }

    /**
     * 게시글 답변 등록 폼
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsArticle/bbsArticleAnswerRegForm.do")
    public String bbsArticleAnswerRegForm(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception{

        //게시판 타입
        map.addAttribute("bbsMastView",bbsManageService.selectBbsMastView(paramMap));
        //게시판 카테고리
        map.addAttribute("bbscategoryList", bbsManageService.selectBbsCategoryList(paramMap));

        //부모 게시물정보조회
        Map<String,Object> bbsArticleVO = bbsArticleService.selectBbsArticleView(paramMap);
        map.addAttribute("bbsArticleVO", bbsArticleVO);

        //검색파라미터
        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/bbsArticle/"+paramMap.get("bbsType")+"/answerRegForm";
    }

    /**
     * 게시글 삭제
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsArticle/delete.do", method=RequestMethod.POST)
    public ModelAndView bbsArticleDelete(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map,
            HttpSession session
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        //완료 또는 실패후 메시지
        Map<String,Object> resultMap = new HashMap<>();

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());

        //게시글 수정
        bbsArticleService.deleteBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.delete"));

        return mv;
    }

    /**
     * 게시글 DB 삭제
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsArticle/deleteBbsArticleDbAjax.do", method=RequestMethod.POST)
    public ModelAndView deleteArticleDbAjax(
            HttpSession session
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        return mv;
    }

    public ModelAndView offenseWordsCheck(Map<String,Object> paramMap) throws Exception {
        Map<String,Object> retMap = new HashMap<>();

        Map<String,Object> offenseWord =  bbsManageService.selectOffenseWordsMap();

        String checkWords[] = String.valueOf(offenseWord.get("offenseWord")).split(",");

        String title = paramMap.get("title") == null ? "" : String.valueOf(paramMap.get("title"));
        String content = paramMap.get("content") == null ? "" : String.valueOf(paramMap.get("content"));
        String reply = paramMap.get("reply") == null ? "" : String.valueOf(paramMap.get("reply"));

        for(int i=0; i<checkWords.length; i++){
            if(
                    title.indexOf(checkWords[i])>-1 || content.indexOf(checkWords[i])>-1 || reply.indexOf(checkWords[i])>-1
            ){
                retMap.put("result", "OFFENSE_WORD");
                retMap.put("failContent", checkWords[i]);
                return new ModelAndView("jsonView", retMap);
            }
        }

        return null;
    }

    @RequestMapping("/bbsArticle/photoUploadProcAjax.do")
    public String adminMainProc(HttpServletRequest request,HttpServletResponse response,MultipartHttpServletRequest mRequest) throws Exception{

        MultipartFile fileData = mRequest.getFile("Filedata");
        String callback = request.getParameter("callback");
        String callback_func = request.getParameter("callback_func");
        String file_result = "";

        String uploadPath = propertiesService.getString("Globals.smateEditorImgPath");


        if(fileData != null && fileData.getOriginalFilename() != null && !fileData.getOriginalFilename().equals("")){
            //파일이 존재하면
            final String original_name = fileData.getOriginalFilename();
            String ext = original_name.substring(original_name.lastIndexOf(".")+1);

            File file = new File(uploadPath);
            //디렉토리 존재하지 않을경우 디렉토리 생성
            if(!file.exists()) {
                file.mkdirs();
            }
            //서버에 업로드 할 파일명(한글문제로 인해 원본파일은 올리지 않는것이 좋음)
            String realname = UUID.randomUUID().toString() + "." + ext;
            ///////////////// 서버에 파일쓰기 /////////////////
            fileData.transferTo(new File(uploadPath+realname));
            file_result += "&bNewLine=true&sFileName="+original_name+"&sFileURL=/smartEditor/upload/"+realname;
        } else {
            file_result += "&errstr=error";
        }



        return "redirect:" + callback + "?callback_func="+callback_func+file_result;

    }

}
