package com.sillasystem.bbsArticle.service;

import egovframework.rte.psl.dataaccess.util.EgovMap;

import java.util.List;
import java.util.Map;

public interface BbsArticleService {

    public Map<String,Object> selectBbsArticleList (Map<String,Object> paramMap) throws Exception;

    public EgovMap selectBbsArticleView(Map<String,Object> paramMap) throws Exception;

    public void insertBbsArticle (Map<String,Object> paramMap) throws Exception;

    public void updateBbsArticle (Map<String,Object> paramMap) throws Exception;

    public void deleteBbsArticle (Map<String,Object> paramMap) throws Exception;

}
