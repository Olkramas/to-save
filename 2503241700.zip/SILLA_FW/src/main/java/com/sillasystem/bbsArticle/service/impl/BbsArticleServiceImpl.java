package com.sillasystem.bbsArticle.service.impl;

import com.sillasystem.bbsArticle.service.BbsArticleService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("bbsArticleService")
public class BbsArticleServiceImpl extends EgovAbstractServiceImpl implements BbsArticleService {

    @Resource(name = "bbsArticleDAO")
    private BbsArticleDAO bbsArticleDAO;

    @Override
    public Map<String, Object> selectBbsArticleList(Map<String,Object> paramMap) throws Exception {
        List<EgovMap> result = bbsArticleDAO.selectBbsArticleList(paramMap);
        int cnt = bbsArticleDAO.selectBbsArticleListCnt(paramMap);

        Map<String,Object> map = new HashMap<>();
        map.put("resultList",result);
        map.put("resultCnt",Integer.toString(cnt));
        return map;
    }

    @Override
    public EgovMap selectBbsArticleView(Map<String,Object> paramMap) throws Exception {
        //조회수 증가
        bbsArticleDAO.updateReadCnt(paramMap);

        return bbsArticleDAO.selectBbsArticleView(paramMap);
    }

    @Override
    public void insertBbsArticle(Map<String, Object> paramMap) throws Exception {

        //답변글일때
        if (paramMap.containsKey("ref")){
            //답변최신글을 아래로 보내기
            bbsArticleDAO.updateBbsArticleBeforeAnswerInsert(paramMap);

            int step = Integer.parseInt(String.valueOf(paramMap.get("step"))) +1;
            int bbsLevel = Integer.parseInt(String.valueOf(paramMap.get("bbsLevel"))) + 1;

            //ref, bbs_level, step 입력
            paramMap.put("bbsLevel", bbsLevel);
            paramMap.put("step", step);
        }
        bbsArticleDAO.insertBbsArticle(paramMap);
    }

    @Override
    public void updateBbsArticle(Map<String, Object> paramMap) throws Exception {
        bbsArticleDAO.updateBbsArticle(paramMap);
    }

    @Override
    public void deleteBbsArticle(Map<String, Object> paramMap) throws Exception {
        bbsArticleDAO.deleteBbsArticle(paramMap);
    }


}
