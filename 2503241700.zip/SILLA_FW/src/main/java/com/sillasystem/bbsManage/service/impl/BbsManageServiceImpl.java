package com.sillasystem.bbsManage.service.impl;

import com.sillasystem.bbsManage.service.BbsManageService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("bbsManageService")
public class BbsManageServiceImpl extends EgovAbstractServiceImpl implements BbsManageService {

    @Resource(name = "bbsManageDAO")
    private BbsManageDAO bbsManageDAO;

    @Override
    public Map<String, Object> bbsManageList(Map<String,Object> paramMap) throws  Exception{
        List<EgovMap> result = bbsManageDAO.selectbbsManageList(paramMap);
        int cnt = bbsManageDAO.bbsManageListCnt(paramMap);

        Map<String,Object> map = new HashMap<>();
        map.put("resultList", result);
        map.put("resultCnt", Integer.toString(cnt));

        return map;
    }

    @Override
    public EgovMap selectBbsMastView(Map<String,Object> paramMap) throws Exception {
        return bbsManageDAO.selectBbsMastView(paramMap);
    }

    @Override
    public List<EgovMap> selectBbsMastManagerList(Map<String,Object> paramMap) throws Exception {
        return bbsManageDAO.selectBbsMastManagerList(paramMap);
    }

    @Override
    public void insertBbsManage(Map<String,Object> paramMap) throws Exception {
        //bbsMast
        bbsManageDAO.insertBbsMast(paramMap);

        String[] regLevel = (String[]) paramMap.get("regLevel");
        //bbsManager
        if (regLevel.length > 0){

            for (String groupId : regLevel){
                if (groupId.length() > 0 && !groupId.equals("")){
                    paramMap.put("groupId", groupId);
                    bbsManageDAO.insertBbsManager(paramMap);
                }
            }
        }

    }

    @Override
    public void updateBbsManage(Map<String,Object> paramMap) throws Exception {
        //bbsMast
        bbsManageDAO.updateBbsMast(paramMap);

        String[] regLevel = (String[]) paramMap.get("regLevel");
        //bbsManager
        if (regLevel.length > 0){
            //없는거 삭제
            bbsManageDAO.deleteBbsManager(paramMap);

            for (String groupId : regLevel){
                if (groupId.length() > 0 && !groupId.equals("")){
                    paramMap.put("groupId", groupId);
                    bbsManageDAO.insertBbsManager(paramMap);
                }
            }
        }

    }

    @Override
    public int duplicateCheck(Map<String,Object> paramMap) throws Exception {
        return bbsManageDAO.duplicateCheck(paramMap);
    }

    @Override
    public void deleteBbsMast(Map<String,Object> paramMap) throws Exception {
        bbsManageDAO.deleteBbsMast(paramMap);
    }

    @Override
    public EgovMap selectOffenseWordsMap() throws Exception {
        return bbsManageDAO.selectOffenseWordsMap();
    }

    @Override
    public void updateOffenseWordsManage(Map<String, Object> paramMap) throws Exception {
        bbsManageDAO.updateOffenseWordsManage(paramMap);
    }

    @Override
    public EgovMap selectBbsCategoryDetail(Map<String, Object> paramMap) throws Exception {
        return bbsManageDAO.selectBbsCategoryDetail(paramMap);
    }

    @Override
    public List<EgovMap> selectBbsCategoryList(Map<String, Object> paramMap) throws Exception {
        return bbsManageDAO.selectBbsCategoryList(paramMap);
    }

    @Override
    public void mergeBbsCategory(Map<String, Object> paramMap) throws Exception {
        bbsManageDAO.mergeBbsCategory(paramMap);
    }

    @Override
    public void deleteBbsCategory(Map<String, Object> paramMap) throws Exception {
        bbsManageDAO.deleteBbsCategory(paramMap);
    }
}
