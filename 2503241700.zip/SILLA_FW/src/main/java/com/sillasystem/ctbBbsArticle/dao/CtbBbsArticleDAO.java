package com.sillasystem.ctbBbsArticle.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("ctbBbsArticleDAO")
public class CtbBbsArticleDAO extends EgovComAbstractDAO{
	
	//게시글 리스트
    public List<EgovMap> selectBbsArticleList(Map<String,Object> paramMap) throws Exception{
        return (List<EgovMap>) list("ctbBbsArticleDAO.selectBbsArticleList", paramMap);
    }

    //게시글 totalCnt
    public int selectBbsArticleListCnt (Map<String,Object> paramMap) throws Exception {
        return (Integer)selectOne("ctbBbsArticleDAO.selectBbsArticleListCnt", paramMap);
    }
    
    //게시글 등록
    public void insertBbsArticle (Map<String,Object> paramMap) throws Exception {
        insert("ctbBbsArticleDAO.insertBbsArticle", paramMap);
    }
    
    //답변글
    public void updateBbsArticleBeforeAnswerInsert (Map<String,Object> paramMap) throws Exception {
        update("ctbBbsArticleDAO.updateBbsArticleBeforeAnswerInsert", paramMap);
    }
    
    //조회수 증가
    public void updateReadCnt (Map<String,Object> paramMap) throws Exception {
    	System.out.println("조회수 증가 파라미터");
    	System.out.println(paramMap);
        update("ctbBbsArticleDAO.updateReadCnt", paramMap);
    }
    
    //게시글 단건 조회
    public EgovMap selectBbsArticleView (Map<String,Object> paramMap) throws Exception {
        return selectOne("ctbBbsArticleDAO.selectBbsArticleView", paramMap);
    }
    
    //게시글 수정
    public void updateBbsArticle (Map<String,Object> paramMap) throws Exception {
    	System.out.println("업데이트 파라미터");
    	System.out.println(paramMap);
        update("ctbBbsArticleDAO.updateBbsArticle", paramMap);
    }
    
    //게시글 삭제
    public void deleteBbsArticle (Map<String,Object> paramMap) throws Exception {
    	System.out.println("삭제 파라미터");
    	System.out.println(paramMap);
        update("ctbBbsArticleDAO.deleteBbsArticle", paramMap);
    }

}
