package com.sillasystem.ctbBbsArticle.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.sillasystem.bbsArticle.service.BbsArticleService;
import com.sillasystem.ctbBbsArticle.dao.CtbBbsArticleDAO;

import egovframework.com.cmm.util.ExcelUtil;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("ctbBbsArticleService")
public class CtbBbsArticleServiceImpl extends EgovAbstractServiceImpl implements BbsArticleService{
	
    @Resource(name = "ctbBbsArticleDAO")
    private CtbBbsArticleDAO bbsArticleDAO;
    
    //게시글 리스트 조회
	@Override
	public Map<String, Object> selectBbsArticleList(Map<String, Object> paramMap) throws Exception {
        List<EgovMap> result = bbsArticleDAO.selectBbsArticleList(paramMap);
        int cnt = bbsArticleDAO.selectBbsArticleListCnt(paramMap);

        Map<String,Object> map = new HashMap<>();
        map.put("resultList",result);
        map.put("resultCnt",Integer.toString(cnt));
        return map;
	}
	
	//게시글 단건조회
	@Override
	public EgovMap selectBbsArticleView(Map<String, Object> paramMap) throws Exception {
		//조회수 증가
        bbsArticleDAO.updateReadCnt(paramMap);

        return bbsArticleDAO.selectBbsArticleView(paramMap);
    }
	
	//게시글 등록
	@Override
	public void insertBbsArticle(Map<String, Object> paramMap) throws Exception {
        //답변글일때
        if (paramMap.containsKey("ref")){
            //답변최신글을 아래로 보내기
            bbsArticleDAO.updateBbsArticleBeforeAnswerInsert(paramMap);

            int step = Integer.parseInt(String.valueOf(paramMap.get("step"))) +1;
            int bbsLevel = Integer.parseInt(String.valueOf(paramMap.get("bbsLevel"))) + 1;

            //ref, bbs_level, step 입력
            paramMap.put("bbsLevel", bbsLevel);
            paramMap.put("step", step);
        }
        bbsArticleDAO.insertBbsArticle(paramMap);
	}
	
	//게시글 수정
	@Override
	public void updateBbsArticle(Map<String, Object> paramMap) throws Exception {
		bbsArticleDAO.updateBbsArticle(paramMap);
	}

	@Override
	public void deleteBbsArticle(Map<String, Object> paramMap) throws Exception {
		bbsArticleDAO.deleteBbsArticle(paramMap);
		
	}
	
	//액셀 파일 읽기
	public List<HashMap<Object, Object>> readExcel(HttpServletRequest request) throws Exception{
		
		//요청을 MultipartHttpServletRequest로 캐스팅
		MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
		
		//파일 정보
		CommonsMultipartFile file = (CommonsMultipartFile)multiRequest.getFile("excelFile");
		
		//엑셀정보
		ExcelUtil eu = new ExcelUtil();
	
		int sheetNum = 0;		//1번째 시트 읽음 
	
		int strartRowNum = 0;	//1번째 줄부터 읽음
	
		int startCelNum = 0; 	//1번째 열부터 읽음
	
		List<HashMap<Integer, String>> excelList = eu.excelReadSetValue(file, sheetNum, strartRowNum, startCelNum);
		
		List<HashMap<Object, Object>> sendData = new ArrayList<HashMap<Object, Object>>();
		
		for(int i=0; i<excelList.size(); i++) {
			HashMap<Object, Object> row = new HashMap<>();
			row.put("title", excelList.get(i).get(0));		//제목
			row.put("content", excelList.get(i).get(1));	//내용
			sendData.add(row);
		}
		
		return sendData;
	}
	
	//액셀 파일 읽기
	public void insertExcelBbsArticle(Map<String,Object> request) throws Exception{
		
		int boardListSize = (request.size() - 3) /2;	//기타 정보 제외한 나머지 한 객체의 개수(제목 + 내용);
		
		List<Map<String, Object>> boardList = new ArrayList<>();
		Map<String, Object> insertRow = new HashMap<>();
		
		for(int i=0; i<boardListSize; i++) {
			//제목
			String titleStr = "title" + i;
			insertRow.put("title", request.get(titleStr));	
			//내용
			String conTentStr = "content" + i;
			insertRow.put("content", request.get(conTentStr));
			//게시판 id
			insertRow.put("bbsId", request.get("bbsId"));
			
			insertRow.put("regId", request.get("userId"));	//등록자 id
			insertRow.put("updId", request.get("userId"));	//수정자 id
			
			boardList.add(insertRow);
			insertRow = new HashMap<>();
			
		}
		
		//다중 등록
		for(int i=0; i<boardList.size(); i++) {
			bbsArticleDAO.insertBbsArticle(boardList.get(i));
		}
		
	}
	

}
