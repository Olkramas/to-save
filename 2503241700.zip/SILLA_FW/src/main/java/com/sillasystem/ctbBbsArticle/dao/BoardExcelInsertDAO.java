package com.sillasystem.ctbBbsArticle.dao;

import lombok.Data;

@Data
public class BoardExcelInsertDAO {
	String title;
	String content;
	String bbsId;
	String regId;
	String updDt;
}
