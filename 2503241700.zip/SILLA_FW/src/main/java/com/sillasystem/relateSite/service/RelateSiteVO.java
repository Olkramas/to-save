/**
 * 
 * 관련사이트 관리 VO JPA 연동
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */

package com.sillasystem.relateSite.service;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="SILLA_RELATE_SITE")
public class RelateSiteVO implements Serializable {
	
	private static final long serialVersionUID = -1354966196512590554L;
	
	// 시퀀스
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SEQ" )
	private int seq;
	
	// 제목
	@Column(name="TITLE" )
	private String title;
			
	// 이미지명
	@Column(name="IMG_NAME" )
	private String imgName;
	
	// 원본 이미지명
	@Column(name="ORIGNL_FILE_NM" )
	private String orignlFileNm;
			
	// 이미지경로
	@Column(name="IMG_PATH" )
	private String imgPath;
				
	// 링크주소
	@Column(name="LINK_URL" )
	private String linkUrl;
			
	// 사용여부
	@Column(name="USE_YN" )
	private String useYn;
	
	// 삭제여부
	@Column(name="DEL_YN" )
	private String delYn;
	
	// 파일연동여부
	@Column(name="SYNC_YN" )
	private String syncYn;
	
	// 등록자
	@Column(name="REG_ID" )
	private String regId;
	
	// 등록일
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REG_DT" )
	private Date regDt;
	
	// 수정자
	@Column(name="UPD_ID" )
	private String updId;
	
	// 수정일
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPD_DT" )
	private Date updDt;
	
	// 페이징 관련
	@Transient
	private int pageIndex = 1;
	
	// 선택 삭제용
	@Transient
	private String chkDel;
	
	// 제목 검색어
	@Transient
	private String searchTxt;
	
	// 검색 시작일
	@Transient
	private String searchStartDt;
	
	
	// 검색 종료일
	@Transient
	private String searchEndDt;
	
	// 등록/수정 구분
	@Transient
	private String modGbn;

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	public String getOrignlFileNm() {
		return orignlFileNm;
	}

	public void setOrignlFileNm(String orignlFileNm) {
		this.orignlFileNm = orignlFileNm;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}

	public String getSyncYn() {
		return syncYn;
	}

	public void setSyncYn(String syncYn) {
		this.syncYn = syncYn;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public Date getRegDt() {
		return regDt;
	}

	public void setRegDt(Date regDt) {
		this.regDt = regDt;
	}

	public String getUpdId() {
		return updId;
	}

	public void setUpdId(String updId) {
		this.updId = updId;
	}

	public Date getUpdDt() {
		return updDt;
	}

	public void setUpdDt(Date updDt) {
		this.updDt = updDt;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public String getChkDel() {
		return chkDel;
	}

	public void setChkDel(String chkDel) {
		this.chkDel = chkDel;
	}

	public String getSearchTxt() {
		return searchTxt;
	}

	public void setSearchTxt(String searchTxt) {
		this.searchTxt = searchTxt;
	}

	public String getSearchStartDt() {
		return searchStartDt;
	}

	public void setSearchStartDt(String searchStartDt) {
		this.searchStartDt = searchStartDt;
	}

	public String getSearchEndDt() {
		return searchEndDt;
	}

	public void setSearchEndDt(String searchEndDt) {
		this.searchEndDt = searchEndDt;
	}

	public String getModGbn() {
		return modGbn;
	}

	public void setModGbn(String modGbn) {
		this.modGbn = modGbn;
	}
		
}
