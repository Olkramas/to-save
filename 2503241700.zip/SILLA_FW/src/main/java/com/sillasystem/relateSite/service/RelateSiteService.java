/**
 * 
 * 관련사이트 관리 Service
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.relateSite.service;

import org.springframework.data.domain.Page;

import com.sillasystem.banner.service.BannerVO;

public interface RelateSiteService {
	
	public Page<RelateSiteVO> getRelateSiteList(RelateSiteVO vo) throws Exception;
	
	public RelateSiteVO selectRelateSiteDetail(RelateSiteVO vo) throws Exception;
		
	public void insertRelateSite(RelateSiteVO vo) throws Exception;
	
	public void removeRelateSite(RelateSiteVO vo) throws Exception;
	
	public void removeChkRelateSite(RelateSiteVO vo) throws Exception;
	
}
