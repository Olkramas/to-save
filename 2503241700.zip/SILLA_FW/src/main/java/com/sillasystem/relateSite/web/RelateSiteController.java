/**
 * 
 * 관련사이트 관리 Controller
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.relateSite.web;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.sillasystem.banner.service.BannerService;
import com.sillasystem.banner.service.BannerVO;
import com.sillasystem.common.CommonUtil;
import com.sillasystem.relateSite.service.RelateSiteService;
import com.sillasystem.relateSite.service.RelateSiteVO;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class RelateSiteController {
	
	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;
	
	/** relateSiteService */
	@Resource(name = "relateSiteService")
	private RelateSiteService relateSiteService;
	
	@Resource(name = "egovFileIdGnrService")
  	private EgovIdGnrService egovFileIdGnrService;
	
	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;
	
	@Autowired
	private CommonUtil util;
	
	// 관련사이트 목록
	@RequestMapping("/relateSite/list.do")
    public String bannerList(@ModelAttribute("relateSiteVO") RelateSiteVO vo, ModelMap model) throws Exception{
		
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}		
				
		Page<RelateSiteVO> itemList = relateSiteService.getRelateSiteList(vo);		
		PaginationInfo pgInfo = util.getPaging(itemList);
		
		model.addAttribute("itemList", itemList);
		model.addAttribute("searchVO",vo);
		model.addAttribute("paginationInfo", pgInfo);
		
		return "com/sillasystem/relateSite/list";
		
    }
	
	// 관련사이트 등록
	@RequestMapping("/relateSite/regist.do")
	public String bannerRegist(@ModelAttribute("relateSiteVO") RelateSiteVO vo, ModelMap model) throws Exception{
		
		vo.setModGbn("R");
		
		model.addAttribute("bannerVO",vo);
		model.addAttribute("searchVO",vo);
		
		return "com/sillasystem/relateSite/regist";
		
	}
	
	// 관련사이트 수정
	@RequestMapping("/relateSite/modify.do")
	public String bannerModify(@ModelAttribute("relateSiteVO") RelateSiteVO vo, ModelMap model) throws Exception{
		
		
		RelateSiteVO retVo = relateSiteService.selectRelateSiteDetail(vo);
		retVo.setModGbn("U");
		
		model.addAttribute("relateSiteVO",retVo);
		model.addAttribute("searchVO",vo);
		
		return "com/sillasystem/relateSite/regist";
		
	}
	
	
	// 관련사이트 미리보기
	@RequestMapping("/relateSite/preViewPop.do")
	public String bannerPreView(@ModelAttribute("relateSiteVO") RelateSiteVO vo, ModelMap model) throws Exception{
		
		RelateSiteVO retVo = relateSiteService.selectRelateSiteDetail(vo);
		model.addAttribute("relateSiteVO",retVo);
		
		return "com/sillasystem/relateSite/preViewPop";
		
	}
	
	// 관련사이트 이미지 보기
	@SuppressWarnings("resource")
	@RequestMapping("/relateSite/getRelateSiteImage.do")
	public void getBannerImage(ModelMap model, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		int seq = Integer.parseInt(request.getParameter("seq"));
		
		RelateSiteVO vo = new RelateSiteVO();
		vo.setSeq(seq);
		
		RelateSiteVO retVo = relateSiteService.selectRelateSiteDetail(vo);
		if(retVo != null) {
			String filePath = retVo.getImgPath();
			String fileName = retVo.getImgName();
			
			File file = new File(filePath,fileName);			
			if(file.exists()) {
				FileInputStream fis = null; 
				
				new FileInputStream(file);

				BufferedInputStream in = null;
				ByteArrayOutputStream bStream = null;
				try{
					fis = new FileInputStream(file);
					in = new BufferedInputStream(fis);
					bStream = new ByteArrayOutputStream();
					int imgByte;
					while ((imgByte = in.read()) != -1) {
					    bStream.write(imgByte);
					}

					String type = "";
					
					int index = retVo.getOrignlFileNm().lastIndexOf(".");
				    String fileExt = retVo.getOrignlFileNm().substring(index + 1);
					if (fileExt != null && !"".equals(fileExt)) {
					    if ("jpg".equals(fileExt.toLowerCase())) {
						type = "image/jpeg";
					    } else {
						type = "image/" + fileExt.toLowerCase();
					    }
					    type = "image/" + fileExt.toLowerCase();

					} else {
					
					}

					response.setHeader("Content-Type", type);
					response.setContentLength(bStream.size());

					bStream.writeTo(response.getOutputStream());

					response.getOutputStream().flush();
					response.getOutputStream().close();


				}catch(Exception e){
					
				}finally{
					if (bStream != null) {
						try {
							bStream.close();
						} catch (Exception est) {
						
						}
					}
					if (in != null) {
						try {
							in.close();
						} catch (Exception ei) {
						
						}
					}
					if (fis != null) {
						try {
							fis.close();
						} catch (Exception efis) {
						
						}
					}
				}
			}else {				
				System.out.println("파일없음");
			}
			
		}
		
		
		
		
	}
	
	// 관련사이트 저장 처리(등록/수정)
	@RequestMapping("/relateSite/RelateSiteProcess.do")
	public String bannerProcess(@ModelAttribute("relateSiteVO") RelateSiteVO vo,final MultipartHttpServletRequest multiRequest, ModelMap model) throws Exception{
		
		// 파일 업로드 처리
		
		// 업로드할 폴더 가지고 오기
		String storePathString = propertiesService.getString("Globals.fileStorePath") + "/relateSite/";
		
		String oldFile = "";
		if(vo.getModGbn().equals("U")) {
			RelateSiteVO oldVo = relateSiteService.selectRelateSiteDetail(vo);
			if(oldVo != null) {
				oldFile = oldVo.getImgPath() + "/" + oldVo.getImgName();
				
				// JPA 때문에 기존 데이터 유지
				vo.setOrignlFileNm(oldVo.getOrignlFileNm());
				vo.setImgPath(oldVo.getImgPath());
				vo.setImgName(oldVo.getImgName());				
				vo.setRegId(oldVo.getRegId());
				vo.setRegDt(oldVo.getRegDt());
				
			}
		}
		
		
		// 파일 가지고 오기
		final Map<String, MultipartFile> files = multiRequest.getFileMap();		
		if (!files.isEmpty()) {
			
			// 업로드할 폴더 생성
			File saveFolder = new File(storePathString);
			
			if (!saveFolder.exists() || saveFolder.isFile()) {
			    saveFolder.mkdirs();
			}
			
			Iterator<Entry<String, MultipartFile>> itr = files.entrySet().iterator();
			MultipartFile file;
			String filePath = "";
			
			while (itr.hasNext()) {
				Entry<String, MultipartFile> entry = itr.next();
				
				file = entry.getValue();
			    String orginFileName = file.getOriginalFilename();
			    if(!orginFileName.equals("")){
			    	
			    	// 수정일때는 기존 파일 삭제
					if(!oldFile.equals("")) {
						File delFile = new File(oldFile);
						if(delFile.exists()) {							
							delFile.delete();
						}
					}
					
				    int index = orginFileName.lastIndexOf(".");
				    //String fileName = orginFileName.substring(0, index);
				    String fileExt = orginFileName.substring(index + 1);
				    //String newName = KeyStr + EgovStringUtil.getTimeStamp() + fileKey;
				    String newName = egovFileIdGnrService.getNextStringId();
				    long _size = file.getSize();
				    if(fileExt.equals("jsp") || fileExt.equals("js") || fileExt.equals("html") || fileExt.equals("htm")){
				    	System.out.println("업로드 불가능한 파일");
				    	return "redirect:/banner/list.do";
				    }
				    if (!"".equals(orginFileName)) {
						filePath = storePathString + File.separator + newName;
						file.transferTo(new File(filePath));
					}			    
				    vo.setImgName(newName); //실제 파일명
				    vo.setOrignlFileNm(orginFileName);	//원본 파일명
				    vo.setImgPath(storePathString);	//이미지 경로			    			    
			    }
			
			}
		}else {
			
		}
		
		vo.setDelYn("N");
		vo.setSyncYn("N");
		
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		if(vo.getModGbn().equals("R")){
			// 날짜
			vo.setRegDt(new Date());
			vo.setRegId(user.getId());
			model.addAttribute("MSG","정상적으로 등록되었습니다.");
		}else if(vo.getModGbn().equals("U")) {
			// 날짜
			vo.setUpdDt(new Date());
			vo.setUpdId(user.getId());
			model.addAttribute("MSG","정상적으로 수정되었습니다.");
				
			
		}
		
		// 등록/수정 자동으로 됨.
		relateSiteService.insertRelateSite(vo);
				
		model.addAttribute("URL","/relateSite/list.do");
		return "com/sillasystem/common/commonMsg";
		
	}

	
	// 관련사이트 삭제처리
	@RequestMapping(value="/relateSite/relateSiteDelAjax.do", method=RequestMethod.POST)
	public ModelAndView bannerDel(RelateSiteVO relateSiteVO, HttpServletRequest request,HttpServletResponse response, ModelMap map) throws Exception{
				
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		//배너 삭제				
		relateSiteVO.setUpdId(user.getId());
		relateSiteService.removeRelateSite(relateSiteVO);		
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("result", "SUCCESS");
		
		ModelAndView modelAndView = new ModelAndView("jsonView",resultMap);		
		return modelAndView;
		
	}
	
	// 선택 관련사이트 삭제처리
	@RequestMapping(value="/relateSite/chkDeleteRelateSiteAjax.do", method=RequestMethod.POST)
	public ModelAndView chkDeleteBanner(RelateSiteVO relateSiteVO, HttpServletRequest request,HttpServletResponse response, ModelMap map) throws Exception{
				
		String chkSeq = request.getParameter("checkedIdForDel");
		
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		//팝업 삭제
		relateSiteVO.setUpdId(user.getId());
		relateSiteVO.setChkDel(chkSeq);
		relateSiteService.removeChkRelateSite(relateSiteVO);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("result", "SUCCESS");
		
		ModelAndView modelAndView = new ModelAndView("jsonView",resultMap);		
		return modelAndView;
		
	}
}
