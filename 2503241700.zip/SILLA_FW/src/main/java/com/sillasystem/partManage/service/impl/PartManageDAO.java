package com.sillasystem.partManage.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.partManage.service.PartManage;
import com.sillasystem.partManage.service.PartManageVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

@Repository("partManageDAO")
public class PartManageDAO extends EgovComAbstractDAO{

	/**
	 * 등록된 롤 정보 조회
	 * @param roleManageVO RoleManageVO
	 * @return RoleManageVO
	 * @exception Exception
	 */
	public PartManageVO selectRole(PartManageVO roleManageVO) throws Exception {
		return (PartManageVO) selectOne("roleManageDAO.selectRole", roleManageVO);
	}

	/**
	 * 등록된 롤 정보 목록 조회
	 * @param roleManageVO RoleManageVO
	 * @return List<RoleManageVO>
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<PartManageVO> selectRoleList(PartManageVO roleManageVO) throws Exception {
		return (List<PartManageVO>) list("roleManageDAO.selectRoleList", roleManageVO);
	}

	/**
	 * 시스템 메뉴에 따른 접근권한, 데이터 입력, 수정, 삭제의 권한 롤을 등록
	 * @param roleManage RoleManage
	 * @exception Exception
	 */
	public void insertRole(PartManage roleManage) throws Exception {
		insert("roleManageDAO.insertRole", roleManage);
	}
	/**
	 * 시스템 메뉴에 따른 접근권한, 데이터 입력, 수정, 삭제의 권한 롤을 수정
	 * @param roleManage RoleManage
	 * @exception Exception
	 */
	public void updateRole(PartManage roleManage) throws Exception {
		update("roleManageDAO.updateRole", roleManage);
	}
	/**
	 * 불필요한 롤정보를 화면에 조회하여 데이터베이스에서 삭제
	 * @param roleManage RoleManage
	 * @exception Exception
	 */
	public void deleteRole(PartManage roleManage) throws Exception {
		delete("roleManageDAO.deleteRole", roleManage);
	}
	
    /**
	 * 롤목록 총 갯수를 조회한다.
	 * @param roleManageVO RoleManageVO
	 * @return int
	 * @exception Exception
	 */
    public int selectRoleListTotCnt(PartManageVO roleManageVO) throws Exception {
        return (Integer)selectOne("roleManageDAO.selectAuthorListTotCnt", roleManageVO);
    }	
    
	/**
	 * 등록된 모든 롤 정보 목록 조회
	 * @param roleManageVO RoleManageVO
	 * @return List<RoleManageVO>
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<PartManageVO> selectRoleAllList(PartManageVO roleManageVO) throws Exception {
		return (List<PartManageVO>) list("roleManageDAO.selectRoleAllList", roleManageVO);
	}
}
