/**
 * 
 * 성수기 관리 VO JPA 연동
 * 
 * @version v1.0
 * @since 2019. 05. 12
 * @author pyonkm
 *
 */


package com.sillasystem.schedule.service;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="SILLA_PEAKDAY")
public class PeakdayVO implements Serializable {

	private static final long serialVersionUID = 7793735467706583369L;
	
	// 시퀀스
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SEQ")
	private int seq;
	
	// 기준년도
	@Column(name="STD_YEAR" )
	private String stdYear;
	
	// 시작일
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	@Column(name="START_DT" )
	private Date startDt;
		
	// 종료일
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name="END_DT" )
	private Date endDt;
	
	// 휴일제목
	@Column(name="TITLE" )
	private String title;
	
	// 등록자
	@Column(name="REG_ID" )
	private String regId;
	
	// 등록일
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REG_DT" )
	private Date regDt;
	
	// 수정자
	@Column(name="UPD_ID" )
	private String updId;
	
	// 수정일
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPD_DT" )
	private Date updDt;
	
	// 조회년도 검색용
	@Transient
	private String searchYear;

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getStdYear() {
		return stdYear;
	}

	public void setStdYear(String stdYear) {
		this.stdYear = stdYear;
	}

	public Date getStartDt() {
		return startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public Date getRegDt() {
		return regDt;
	}

	public void setRegDt(Date regDt) {
		this.regDt = regDt;
	}

	public String getUpdId() {
		return updId;
	}

	public void setUpdId(String updId) {
		this.updId = updId;
	}

	public Date getUpdDt() {
		return updDt;
	}

	public void setUpdDt(Date updDt) {
		this.updDt = updDt;
	}

	public String getSearchYear() {
		return searchYear;
	}

	public void setSearchYear(String searchYear) {
		this.searchYear = searchYear;
	}
	

}
