/**
 * 
 * 일정 관리 Controller
 * 
 * @version v1.0
 * @since 2019. 05. 12
 * @author pyonkm
 *
 */
package com.sillasystem.schedule.web;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sillasystem.schedule.repository.PeakdaySearchSpec;
import com.sillasystem.schedule.service.CalenderVO;
import com.sillasystem.schedule.service.HolidayVO;
import com.sillasystem.schedule.service.PeakdayVO;
import com.sillasystem.schedule.service.ScheduleService;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;

@Controller
public class ScheduleController {
	
	/** relateSiteService */
	@Resource(name = "scheduleService")
	private ScheduleService scheduleService;
	
	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;
	
	// 일정 달력
	@RequestMapping("/schedule/calender.do")	
    public String peakCalenderList(@ModelAttribute("calenderVO") CalenderVO vo, ModelMap model) throws Exception{
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}   	
    	
    	// 현재 날짜 가지고 오기
    	Calendar cal = Calendar.getInstance();
		String nowYear = Integer.toString(cal.get(cal.YEAR));
		String nowMonth = Integer.toString(cal.get(cal.MONTH) + 1);
		String nowDay   = Integer.toString(cal.get(cal.DATE));
		
		if(Integer.parseInt(nowMonth) < 10){
			nowMonth = "0" + nowMonth;
		}
				
		String searchYear = nowYear;
		String searchMonth = nowMonth;
		
		if(vo.getSearchYear() != null){
			searchYear = vo.getSearchYear();
		}
		
		if(vo.getSearchMonth() != null){
			searchMonth = vo.getSearchMonth();
		}
		
		// 칼랜더에 날짜 셋팅
		cal.set(Integer.parseInt(searchYear), Integer.parseInt(searchMonth) - 1,1);
		
		// 첫날 요일 구하기
		String startPoint = Integer.toString(cal.get(cal.DAY_OF_WEEK));
		// 마지막날 구하기
		String lastDate = Integer.toString(cal.getActualMaximum(cal.DAY_OF_MONTH));
		
		// 마지막날 요일 구하기
		cal.set(cal.DATE, cal.getActualMaximum(cal.DAY_OF_MONTH));
		String lastPoint = Integer.toString(cal.get(cal.DAY_OF_WEEK));
		
				
		String startDate = searchYear + "-" + searchMonth + "-01";
		String endDate   = searchYear + "-" + searchMonth + "-" + lastDate;
		
		
		
		// 최대 년도 구하기    	
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
				
		// 성수기 가지고 오기
		List<PeakdayVO> peakList = scheduleService.getCalenderPeakdayList(startDate, endDate);
						
		// 휴일 가지고 오기
		List<HolidayVO> holiList = scheduleService.getCalenderHolidayList(startDate, endDate);
    	
    	
		model.addAttribute("maxYear", maxYear);
		model.addAttribute("searchYear", searchYear);
		model.addAttribute("searchMonth", searchMonth);
		model.addAttribute("nowYear", nowYear);
		model.addAttribute("nowMonth", nowMonth);		
		model.addAttribute("nowDay", nowDay);
		model.addAttribute("startPoint", startPoint);
		model.addAttribute("lastPoint", lastPoint);
		model.addAttribute("lastDate", lastDate);
    	model.addAttribute("maxYear",maxYear);
    	model.addAttribute("peakList",peakList);
    	model.addAttribute("holiList",holiList);
		return "com/sillasystem/schedule/calender";
		
	}
	
	// 일정 달력 공휴일 상세보기
	@RequestMapping("/schedule/calenderViewFormAjax.do")
	public String calenderViewForm(@ModelAttribute("holidayVO") HolidayVO vo, ModelMap model) throws Exception{
		
		
    	HolidayVO retVo = scheduleService.getHolidayDtl(vo);
    	model.addAttribute("retVo",retVo);    	
    	
		return "com/sillasystem/schedule/calenderViewFormAjax";
		
	}
	
	
	// 공휴일 설정
	@RequestMapping("/schedule/holiday.do")	
    public String holidayList(@ModelAttribute("holidayVO") HolidayVO vo, ModelMap model) throws Exception{
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}
    	
    	// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	if(vo.getSearchYear() == null || vo.getSearchYear().equals("")) {
    		String nowYear = Integer.toString(cal.get(cal.YEAR));
    		vo.setSearchYear(nowYear);
    	}
    	    	    	
    	// 데이터 가지고 오기
    	List<HolidayVO> list = scheduleService.getHolidayList(vo);
		
    	model.addAttribute("list",list);
    	model.addAttribute("searchYear",vo.getSearchYear());
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule/holiday";
				
	}
	
	// 공휴일 등록/수정 폼
	@RequestMapping("/schedule/holidayRegFormAjax.do")
	public String holidayRegForm(@ModelAttribute("holidayVO") HolidayVO vo, ModelMap model) throws Exception{
		
		// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String nowYear = Integer.toString(cal.get(cal.YEAR));
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	HolidayVO retVo = new HolidayVO();
    	// 시퀀스가 넘어오면 수정
    	if(vo.getSeq() > 0) {
    		retVo = scheduleService.getHolidayDtl(vo);    		
    	}else {    		
    		retVo.setStdYear(nowYear);
    	}
    	    	
    	model.addAttribute("retVo",retVo);    	
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule/holidayRegFormAjax";
	}
	
	// 공휴일 저장
	@RequestMapping("/schedule/holidayProcess.do")
	@ResponseBody
	public String holidayProcess(HolidayVO vo) throws Exception{
		String ret = "N";
		
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		if(vo.getSeq() > 0){
			// 수정
			HolidayVO retVo = scheduleService.getHolidayDtl(vo);
			vo.setRegId(retVo.getRegId());
			vo.setRegDt(retVo.getRegDt());
			vo.setUpdId(user.getId());
			vo.setUpdDt(new Date());
		}else{
			// 등록
			vo.setRegId(user.getId());
			vo.setRegDt(new Date());
		}		
		ret = scheduleService.saveHoliday(vo);
				
		return ret;
		
	}
	
	// 공휴일 삭제	
	@RequestMapping("/schedule/holidayRemoveProc.do")
	@ResponseBody
	public String holidayRemoveProcess(HolidayVO vo) throws Exception{
		String ret = "N";
		
		// DB 삭제 처리		
		scheduleService.removeHoliday(vo);
		ret = "Y";
		
		return ret;
	}
	
	
	
	// 성수기 설정
	@RequestMapping("/schedule/peakday.do")	
    public String peakdayList(@ModelAttribute("peakdayVO") PeakdayVO vo, ModelMap model) throws Exception{
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}
    	
    	// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	if(vo.getSearchYear() == null || vo.getSearchYear().equals("")) {
    		String nowYear = Integer.toString(cal.get(cal.YEAR));
    		vo.setSearchYear(nowYear);
    	}
    	    	    	
    	// 데이터 가지고 오기
    	List<PeakdayVO> list = scheduleService.getPeakdayList(vo);
		
    	model.addAttribute("list",list);
    	model.addAttribute("searchYear",vo.getSearchYear());
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule/peakday";
				
	}
	
	// 공휴일 등록/수정 폼
	@RequestMapping("/schedule/peakdayRegFormAjax.do")
	public String holidayRegForm(@ModelAttribute("peakdayVO") PeakdayVO vo, ModelMap model) throws Exception{
		
		// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String nowYear = Integer.toString(cal.get(cal.YEAR));
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	PeakdayVO retVo = new PeakdayVO();
    	// 시퀀스가 넘어오면 수정
    	if(vo.getSeq() > 0) {
    		retVo = scheduleService.getPeakdayDtl(vo);    		
    	}else {    		
    		retVo.setStdYear(nowYear);
    	}
    	    	
    	model.addAttribute("retVo",retVo);    	
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule/peakdayRegFormAjax";
	}
	
	// 공휴일 저장
	@RequestMapping("/schedule/peakdayProcess.do")
	@ResponseBody
	public String peakdayProcess(PeakdayVO vo) throws Exception{
		String ret = "N";
		
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		vo.setRegId(user.getId());
		vo.setRegDt(new Date());
		if(vo.getSeq() > 0) {
    		PeakdayVO retVo = scheduleService.getPeakdayDtl(vo);
    		vo.setRegId(retVo.getRegId());
    		vo.setRegDt(retVo.getRegDt());
    		vo.setUpdId(user.getId());
    		vo.setUpdDt(new Date());
    	}else {    		
    		vo.setRegId(user.getId());
    		vo.setRegDt(new Date());
    	}
						
		ret = scheduleService.savePeakday(vo);
				
		return ret;
		
	}
	
	// 공휴일 삭제	
	@RequestMapping("/schedule/peakdayRemoveProc.do")
	@ResponseBody
	public String peakdayRemoveProcess(PeakdayVO vo) throws Exception{
		String ret = "N";
		
		// DB 삭제 처리		
		scheduleService.removePeakday(vo);
		ret = "Y";
		
		return ret;
	}
	
	
	// 공공데이터 연계 공휴일 가지고 오기
	@RequestMapping("/schedule/holidayDataApiAjax.do")
	@ResponseBody
	public String holidayDataApiAjax(HolidayVO vo) throws Exception{
		String ret = "0";
		
		// 로그인 정보 가지고 오기		
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		vo.setRegId(user.getId());
		vo.setRegDt(new Date());
		
		// 공공데이터 연계 처리
		ret = scheduleService.getHolidayDataApi(vo);
		
		return ret;
	}
	
}
