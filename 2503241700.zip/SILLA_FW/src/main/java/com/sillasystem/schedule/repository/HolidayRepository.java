/**
 * 
 * 휴일 관리 JPA Repository
 * 
 * @version v1.0
 * @since 2019. 05. 12
 * @author pyonkm
 *
 */

package com.sillasystem.schedule.repository;

import java.util.List;

import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sillasystem.schedule.service.HolidayVO;

public interface HolidayRepository extends JpaRepository<HolidayVO, String> {
	
	@Query(value="	SELECT * FROM SILLA_HOLIDAY" + 
			     "   WHERE :startDt BETWEEN START_DT AND END_DT" + 
			     "      OR ( START_DT > :startDt AND END_DT < :endDt)" + 
			     "      OR (DATE_FORMAT(START_DT,'%Y') = DATE_FORMAT(:startDt,'%Y') AND DATE_FORMAT(START_DT,'%m') = DATE_FORMAT(:startDt,'%m'))" + 
			     "	    OR (DATE_FORMAT(END_DT,'%Y') = DATE_FORMAT(:startDt,'%Y') AND DATE_FORMAT(END_DT,'%m') = DATE_FORMAT(:startDt,'%m'))"
		  , nativeQuery = true)
	List<HolidayVO> selectCalenderHoliday(@Param("startDt")String startDt,@Param("endDt")String endDt) throws Exception;
	
	List<HolidayVO> findAll(Specification<Content> spec);
	
	int count(Specification<Content> spec);
	
	HolidayVO findOneBySeq(int seq);
	
}
