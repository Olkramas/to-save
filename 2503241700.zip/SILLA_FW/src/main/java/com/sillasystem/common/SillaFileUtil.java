package com.sillasystem.common;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.FileVO;

@Component("sillaFileUtil")
public class SillaFileUtil {
	
	@Resource(name="EgovFileMngService")
	EgovFileMngService fileMngService;
	
	@Resource(name="EgovFileMngUtil")
	EgovFileMngUtil fileUtil;
	
	//파일 업로드
	public String uploadFile(MultipartHttpServletRequest request,String uploadPath,String atchFileId) throws Exception{
		
		String retAtchFileId = "";
		final Map<String, MultipartFile> files = request.getFileMap();	//파일 받기
		
		try {
	 		if(!files.isEmpty()) { 			//파일이 없다면
	 			List<FileVO> result = null;
	 			if(atchFileId == null || atchFileId.equals("")) {
	 				System.out.println("등록모드");	 				
		 			result = fileUtil.parseFileInf(files, "FILE_", 0, "", uploadPath);	//파일 key 구하기
		 			retAtchFileId = fileMngService.insertFileInfs(result);	 	//파일 mst, dtls 테이블에 데이터 등록		
	 			}else {
	 				System.out.println("수정모드");
	 				FileVO fvo = new FileVO();
	 				fvo.setAtchFileId(atchFileId); // 최종 파일 순번을 획득하기 위하여 VO에 현재 첨부파일 ID를 세팅한다.
	 				int fileCnt = fileMngService.getMaxFileSN(fvo); // 해당 첨부파일 ID에 속하는 최종 파일 순번을 획득한다. 				
	 				result = fileUtil.parseFileInf(files, "FILE_", fileCnt, atchFileId, uploadPath);	
	 				fileMngService.updateFileInfs(result);
	 				retAtchFileId = atchFileId;
	 			}
	 			
	 			CommonUtil util = new CommonUtil();
	 			util.createThumbnailByFileVO(result);
	 		}
		}catch(Exception e) {
			e.printStackTrace();
		}
 		
		return retAtchFileId; 
	}
	
	
	public List<FileVO> getFileList(String atchFileId) throws Exception{
		List<FileVO> fileList = null;
		if(atchFileId != null && !atchFileId.equals("")) {
	    	FileVO fvo = new FileVO();
	    	fvo.setAtchFileId(atchFileId);
	    	fileList = fileMngService.selectFileInfs(fvo);
		}
		
		return fileList;
	}
}
