package com.sillasystem.member.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sillasystem.member.service.UserDefaultVO;
import com.sillasystem.member.service.UserManageVO;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.utl.sim.service.EgovFileScrty;

import com.sillasystem.member.service.EgovUserManageService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class MemberController {
	
	/** userManageService */
	@Resource(name = "userManageService")
	private EgovUserManageService userManageService;
	
	/** cmmUseService */
	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;
	
	// 회원 목록
	@RequestMapping("/member/list.do")
    public String memberList(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, ModelMap model) throws Exception{
		
		
		/** EgovPropertyService */
		userSearchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		userSearchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userSearchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(userSearchVO.getPageUnit());
		paginationInfo.setPageSize(userSearchVO.getPageSize());

		userSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		userSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		userSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> userList = userManageService.selectUserList(userSearchVO);
		model.addAttribute("resultList", userList);

		int totCnt = userManageService.selectUserListTotCnt(userSearchVO);		
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
				
		//사용자상태코드를 코드정보로부터 조회
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM013");
		List<?> emplyrSttusCode_result = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("emplyrSttusCode_result", emplyrSttusCode_result);//사용자상태코드목록
		
		model.addAttribute("userSearchVO", userSearchVO);
		
		
        return "com/sillasystem/member/list";
    }
	
	// 회원 등록폼
	@RequestMapping("/member/regist.do")
	public String memberRegist(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, @ModelAttribute("userManageVO") UserManageVO userManageVO, Model model) throws Exception{
		
		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//패스워드힌트목록을 코드정보로부터 조회
		vo.setCodeId("COM022");
		List<?> passwordHint_result = cmmUseService.selectCmmCodeDetail(vo);
		//성별구분코드를 코드정보로부터 조회
		vo.setCodeId("COM014");
		List<?> sexdstnCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//사용자상태코드를 코드정보로부터 조회
		vo.setCodeId("COM013");
		List<?> emplyrSttusCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//소속기관코드를 코드정보로부터 조회 - COM025
		vo.setCodeId("COM025");
		List<?> insttCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//조직정보를 조회 - ORGNZT_ID정보
		vo.setTableNm("COMTNORGNZTINFO");
		List<?> orgnztId_result = cmmUseService.selectOgrnztIdDetail(vo);
		//그룹정보를 조회 - GROUP_ID정보
		vo.setTableNm("COMTNORGNZTINFO");
		List<?> groupId_result = cmmUseService.selectGroupIdDetail(vo);
		
		List<UserManageVO> roleList = userManageService.selectAuthorInfo("Y");
		model.addAttribute("roleList", roleList);

		model.addAttribute("passwordHint_result", passwordHint_result); //패스워트힌트목록
		model.addAttribute("sexdstnCode_result", sexdstnCode_result); //성별구분코드목록
		model.addAttribute("emplyrSttusCode_result", emplyrSttusCode_result);//사용자상태코드목록
		model.addAttribute("insttCode_result", insttCode_result); //소속기관코드목록
		model.addAttribute("orgnztId_result", orgnztId_result); //조직정보 목록
		model.addAttribute("groupId_result", groupId_result); //그룹정보 목록		
		
		// 등록모드
		userManageVO.setModGbn("R");
		model.addAttribute("userManageVO", userManageVO);
		
		return "com/sillasystem/member/regist";
		
		
	}
	
	// 회원 수정폼
	@RequestMapping("/member/update.do")
	public String memberUpdate(@RequestParam("selectedId") String uniqId, @ModelAttribute("searchVO") UserDefaultVO userSearchVO, Model model) throws Exception{
		
		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//패스워드힌트목록을 코드정보로부터 조회
		vo.setCodeId("COM022");
		List<?> passwordHint_result = cmmUseService.selectCmmCodeDetail(vo);
		//성별구분코드를 코드정보로부터 조회
		vo.setCodeId("COM014");
		List<?> sexdstnCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//사용자상태코드를 코드정보로부터 조회
		vo.setCodeId("COM013");
		List<?> emplyrSttusCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//소속기관코드를 코드정보로부터 조회 - COM025
		vo.setCodeId("COM025");
		List<?> insttCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//조직정보를 조회 - ORGNZT_ID정보
		vo.setTableNm("COMTNORGNZTINFO");
		List<?> orgnztId_result = cmmUseService.selectOgrnztIdDetail(vo);
		//그룹정보를 조회 - GROUP_ID정보
		vo.setTableNm("COMTNORGNZTINFO");
		List<?> groupId_result = cmmUseService.selectGroupIdDetail(vo);

		model.addAttribute("passwordHint_result", passwordHint_result); //패스워트힌트목록
		model.addAttribute("sexdstnCode_result", sexdstnCode_result); //성별구분코드목록
		model.addAttribute("emplyrSttusCode_result", emplyrSttusCode_result);//사용자상태코드목록
		model.addAttribute("insttCode_result", insttCode_result); //소속기관코드목록
		model.addAttribute("orgnztId_result", orgnztId_result); //조직정보 목록
		model.addAttribute("groupId_result", groupId_result); //그룹정보 목록	
		
		UserManageVO userManageVO = new UserManageVO();
		userManageVO = userManageService.selectUser(uniqId);
		
		// 휴대폰번호 자르기
		String[] moblphonNo = userManageVO.getMoblphonNo().split("-");		
		userManageVO.setMoblphonNo1(moblphonNo[0]);
		userManageVO.setMoblphonNo2(moblphonNo[1]);
		userManageVO.setMoblphonNo3(moblphonNo[2]);
		
		// 이메일 자르기
		String[] emailAdres = userManageVO.getEmailAdres().split("@");
		userManageVO.setEmailAdres1(emailAdres[0]);
		userManageVO.setEmailAdres2(emailAdres[1]);
		
		// 수정모드
		userManageVO.setModGbn("U");
		
		List<UserManageVO> roleList = userManageService.selectAuthorInfo("Y");
		model.addAttribute("roleList", roleList);
				
		model.addAttribute("userSearchVO", userSearchVO);
		model.addAttribute("userManageVO", userManageVO);
		
		return "com/sillasystem/member/regist";
		
		
	}
	
	// 아이디 중복체크
	@RequestMapping(value = "/member/idDplctChkAjax.do")
	public ModelAndView checkIdDplctAjax(@RequestParam Map<String, Object> commandMap) throws Exception {

    	ModelAndView modelAndView = new ModelAndView();
    	modelAndView.setViewName("jsonView");

		String checkId = (String) commandMap.get("checkId");
		//checkId = new String(checkId.getBytes("ISO-8859-1"), "UTF-8");

		int usedCnt = userManageService.checkIdDplct(checkId);
		modelAndView.addObject("usedCnt", usedCnt);
		modelAndView.addObject("checkId", checkId);

		return modelAndView;
	}
	
	// 회원 등록/수정 처리
	@RequestMapping(value = "/member/MemberProcess.do")
	public String MemberProcess(@ModelAttribute("userManageVO") UserManageVO userManageVO, BindingResult bindingResult, Model model,RedirectAttributes ra) throws Exception {
		
		
		if ("".equals(userManageVO.getOrgnztId())) {//KISA 보안약점 조치 (2018-10-29, 윤창원)
			userManageVO.setOrgnztId(null);
		}
		if ("".equals(userManageVO.getGroupId())) {//KISA 보안약점 조치 (2018-10-29, 윤창원)
			userManageVO.setGroupId(null);
		}
		
		// 이메일 휴대폰번호 합치기
		String moblphonNo =  userManageVO.getMoblphonNo1() + "-" + userManageVO.getMoblphonNo2() + "-" + userManageVO.getMoblphonNo3();
		String emailAdres = userManageVO.getEmailAdres1() + "@" + userManageVO.getEmailAdres2();
		
		userManageVO.setMoblphonNo(moblphonNo);
		userManageVO.setEmailAdres(emailAdres);
		
		if(userManageVO.getModGbn().equals("R")){				
			userManageService.insertUser(userManageVO);
			
			//Exception 없이 진행시 등록성공메시지
			ra.addFlashAttribute("flash.msg", "success.common.insert");
		}else if(userManageVO.getModGbn().equals("U")) {
			userManageService.updateUser(userManageVO);
			
			//Exception 없이 진행시 수정성공메시지
			ra.addFlashAttribute("flash.msg", "success.common.update");			
		}
		
		return "redirect:/member/list.do";		
    
	}
	
	// 회원 비밀번호 변경 처리
	@RequestMapping(value = "/member/changePassword.do")
	public ModelAndView changePassword(HttpServletRequest request, @ModelAttribute("userManageVO") UserManageVO userManageVO, BindingResult bindingResult, Model model,RedirectAttributes ra) throws Exception {
		
		String newPassword2 = request.getParameter("passwordre");
		String oldPassword = userManageVO.getOldPassword();
		String newPassword = userManageVO.getPassword();
				
		boolean isCorrectPassword = false;
		String resultYn  = "";
		String resultMsg = "";
		UserManageVO resultVO = new UserManageVO();
		resultVO = userManageService.selectPassword(userManageVO);
		//패스워드 암호화				
		String encryptPass = EgovFileScrty.encryptPassword(oldPassword, userManageVO.getEmplyrId());		
		if (encryptPass.equals(resultVO.getPassword())) {
			if (newPassword.equals(newPassword2)) {
				isCorrectPassword = true;
			} else {
				isCorrectPassword = false;
				resultYn  = "N";
				resultMsg = "비밀번호가 잘못 입력되었습니다.";
			}
		} else {
			isCorrectPassword = false;
			resultYn  = "N";
			resultMsg = "기존 비밀번호가 일치하지 않습니다.";
		}

		if (isCorrectPassword) {
			userManageVO.setPassword(EgovFileScrty.encryptPassword(newPassword, userManageVO.getEmplyrId()));
			userManageService.updatePassword(userManageVO);
			model.addAttribute("userManageVO", userManageVO);
			resultYn  = "Y";
			resultMsg = "정상적으로 수정되었습니다.";
		}
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("jsonView");
		modelAndView.addObject("resultYn", resultYn);
		modelAndView.addObject("resultMsg", resultMsg);
		
		return modelAndView;		
    
	}
	
	// 로그인인증제한 해제 
	@RequestMapping(value = "/member/UnLockIncorrect.do")
	public ModelAndView UnLockIncorrect(@ModelAttribute("userManageVO") UserManageVO userManageVO, BindingResult bindingResult, Model model) throws Exception {
		
		userManageService.updateLockIncorrect(userManageVO);
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("jsonView");
		modelAndView.addObject("resultYn", "Y");
		modelAndView.addObject("resultMsg", "정상적으로 제한해제되었습니다.");
		
		return modelAndView;		
    
	}
	
	// 회원삭제
	@RequestMapping(value = "/member/deleteMember.do")
	public ModelAndView deleteMember(@RequestParam("checkedIdForDel") String checkedIdForDel, @ModelAttribute("searchVO") UserDefaultVO userSearchVO, Model model) throws Exception {
		
		userManageService.deleteUser(checkedIdForDel);
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("jsonView");
		modelAndView.addObject("resultYn", "Y");
		modelAndView.addObject("resultMsg", "정상적으로 삭제되었습니다.");
		
		return modelAndView;		
    
	}
}
