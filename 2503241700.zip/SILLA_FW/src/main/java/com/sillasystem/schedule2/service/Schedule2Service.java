package com.sillasystem.schedule2.service;

import java.util.List;


public interface Schedule2Service {
	
	//일정 상세보기
	public ScheduleVO getScheduleDtl(ScheduleVO vo) throws Exception;
	
	//일정 추가하기
	public String insertSchedule(ScheduleVO vo) throws Exception;
	
	//일정 수정하기
	public String updateSchedule(ScheduleVO vo) throws Exception;
	
	//일정 불러오기
	public List<ScheduleVO> getCalenderScheduleList(String startDt,String endDt) throws Exception;
	
	//일정관리
	public List<ScheduleVO> getScheduleList() throws Exception;
	
	public List<Peakday2VO> getCalenderPeakdayList(String startDt,String endDt) throws Exception;
	
	public List<Holiday2VO> getCalenderHolidayList(String startDt,String endDt) throws Exception;
	
	public List<Holiday2VO> getHolidayList(Holiday2VO vo) throws Exception;
	
	public Holiday2VO getHolidayDtl(Holiday2VO vo) throws Exception;
	
	public String saveHoliday(Holiday2VO vo) throws Exception;
	
	public void removeHoliday(Holiday2VO vo) throws Exception;
	
	public List<Peakday2VO> getPeakdayList(Peakday2VO vo) throws Exception;
	
	public Peakday2VO getPeakdayDtl(Peakday2VO vo) throws Exception;
	
	public String savePeakday(Peakday2VO vo) throws Exception;
	
	public void removePeakday(Peakday2VO vo) throws Exception;
	
	public String getHolidayDataApi(Holiday2VO vo) throws Exception;

	public void removeSchedule(ScheduleVO vo) throws Exception;
	
	
	
	
}
