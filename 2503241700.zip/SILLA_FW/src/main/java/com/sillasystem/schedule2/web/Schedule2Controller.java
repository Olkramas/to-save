/**
 * 
 * 일정 관리 Controller
 * 
 * @version v1.0
 * @since 2019. 05. 12
 * @author pyonkm
 *
 */
package com.sillasystem.schedule2.web;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sillasystem.schedule2.repository.Peakday2SearchSpec;
import com.sillasystem.schedule2.service.Calender2VO;
import com.sillasystem.schedule2.service.Holiday2VO;
import com.sillasystem.schedule2.service.Peakday2VO;
import com.sillasystem.schedule2.service.Schedule2Service;
import com.sillasystem.schedule2.service.ScheduleVO;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;

@Controller
public class Schedule2Controller {
	
	/** relateSiteService */
	@Resource(name = "schedule2Service")
	private Schedule2Service scheduleService;
	
	/** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;
	
    /** EgovIdGen */
    @Resource(name="sillaSchLogIdGnrService")
    private EgovIdGnrService egovFileIdGnrService;
    
	// 일정 달력
	@RequestMapping("/schedule2/calender.do")	
    public String peakCalenderList(@ModelAttribute("calenderVO") Calender2VO vo, ModelMap model) throws Exception{
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}   	
    	
    	// 현재 날짜 가지고 오기
    	Calendar cal = Calendar.getInstance();
		String nowYear = Integer.toString(cal.get(cal.YEAR));
		String nowMonth = Integer.toString(cal.get(cal.MONTH) + 1);
		String nowDay   = Integer.toString(cal.get(cal.DATE));
		
		if(Integer.parseInt(nowMonth) < 10){
			nowMonth = "0" + nowMonth;
		}
				
		String searchYear = nowYear;
		String searchMonth = nowMonth;
		
		if(vo.getSearchYear() != null){
			searchYear = vo.getSearchYear();
		}
		
		if(vo.getSearchMonth() != null){
			searchMonth = vo.getSearchMonth();
		}
		
		// 칼랜더에 날짜 셋팅
		cal.set(Integer.parseInt(searchYear), Integer.parseInt(searchMonth) - 1,1);
		
		// 첫날 요일 구하기
		String startPoint = Integer.toString(cal.get(cal.DAY_OF_WEEK));
		// 마지막날 구하기
		String lastDate = Integer.toString(cal.getActualMaximum(cal.DAY_OF_MONTH));
		
		// 마지막날 요일 구하기
		cal.set(cal.DATE, cal.getActualMaximum(cal.DAY_OF_MONTH));
		String lastPoint = Integer.toString(cal.get(cal.DAY_OF_WEEK));
		
				
		String startDate = searchYear + "-" + searchMonth + "-01";
		String endDate   = searchYear + "-" + searchMonth + "-" + lastDate;
		
		
		
		// 최대 년도 구하기    	
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
		System.out.println("pshpsh ::::: " + startDate + ", " + endDate);
		// 성수기 가지고 오기
		List<Peakday2VO> peakList = scheduleService.getCalenderPeakdayList(startDate, endDate);
		for (int i = 0; i < peakList.size(); i++) {
			System.out.println("pshpsh ::::: " + peakList.get(i));
		}
		// 휴일 가지고 오기
		List<Holiday2VO> holiList = scheduleService.getCalenderHolidayList(startDate, endDate);
    	
		// 일정 가지고 오기
		List<ScheduleVO> schList = scheduleService.getCalenderScheduleList(startDate, endDate);
		
		model.addAttribute("maxYear", maxYear);
		model.addAttribute("searchYear", searchYear);
		model.addAttribute("searchMonth", searchMonth);
		model.addAttribute("nowYear", nowYear);
		model.addAttribute("nowMonth", nowMonth);		
		model.addAttribute("nowDay", nowDay);
		model.addAttribute("startPoint", startPoint);
		model.addAttribute("lastPoint", lastPoint);
		model.addAttribute("lastDate", lastDate);
    	model.addAttribute("maxYear",maxYear);
    	model.addAttribute("peakList",peakList);
    	model.addAttribute("holiList",holiList);
    	model.addAttribute("schList",schList); //일정 가져오기
		return "com/sillasystem/schedule2/calender";
		
	}
	
	// 일정 달력 공휴일 상세보기
	@RequestMapping("/schedule2/calenderViewFormAjax.do")
	public String calenderViewForm(@ModelAttribute("holidayVO") Holiday2VO vo, ModelMap model) throws Exception{
		
		
    	Holiday2VO retVo = scheduleService.getHolidayDtl(vo);
    	model.addAttribute("retVo",retVo);    	
    	
		return "com/sillasystem/schedule2/calenderViewFormAjax";
		
	}
	// 일정추가/수정 폼(pshpsh)
	@RequestMapping("/schedule2/calenderInsertScheduleFormAjax.do")
	public String calenderInsertScheduleForm(@ModelAttribute("scheduleVO") ScheduleVO vo, ModelMap model) throws Exception{
		ScheduleVO retVo = new ScheduleVO();
		System.out.println("pshpsh1 :::: " + vo.getSchdulId());
    	// 시퀀스가 넘어오면 수정
//    	if(!(vo.getSchdulId() == null) || !(vo.getSchdulId().equals(""))) {
		if (vo.getSchdulId() == null) {
    		
    	} else {    		
//    		retVo.setStdYear(nowYear);
    		retVo = scheduleService.getScheduleDtl(vo);
    	}
    	
    	model.addAttribute("schVo",retVo);    	
//    	model.addAttribute("maxYear",maxYear);
    	
		return "com/sillasystem/schedule2/calenderInsertScheduleFormAjax";
		
	}
	
	// 공휴일 설정
	@RequestMapping("/schedule2/holiday.do")	
    public String holidayList(@ModelAttribute("holidayVO") Holiday2VO vo, ModelMap model) throws Exception{
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}
    	
    	// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	if(vo.getSearchYear() == null || vo.getSearchYear().equals("")) {
    		String nowYear = Integer.toString(cal.get(cal.YEAR));
    		vo.setSearchYear(nowYear);
    	}
    	    	    	
    	// 데이터 가지고 오기
    	List<Holiday2VO> list = scheduleService.getHolidayList(vo);
		
    	model.addAttribute("list",list);
    	model.addAttribute("searchYear",vo.getSearchYear());
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule2/holiday";
				
	}
	
	// 공휴일 등록/수정 폼
	@RequestMapping("/schedule2/holidayRegFormAjax.do")
	public String holidayRegForm(@ModelAttribute("holidayVO") Holiday2VO vo, ModelMap model) throws Exception{
		
		// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String nowYear = Integer.toString(cal.get(cal.YEAR));
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	Holiday2VO retVo = new Holiday2VO();
    	// 시퀀스가 넘어오면 수정
    	if(vo.getSeq() > 0) {
    		retVo = scheduleService.getHolidayDtl(vo);    		
    	}else {    		
    		retVo.setStdYear(nowYear);
    	}
    	    	
    	model.addAttribute("retVo",retVo);    	
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule2/holidayRegFormAjax";
	}
	
	// 공휴일 저장
	@RequestMapping("/schedule2/holidayProcess.do")
	@ResponseBody
	public String holidayProcess(Holiday2VO vo) throws Exception{
		String ret = "N";
		
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		if(vo.getSeq() > 0){
			// 수정
			Holiday2VO retVo = scheduleService.getHolidayDtl(vo);
			vo.setRegId(retVo.getRegId());
			vo.setRegDt(retVo.getRegDt());
			vo.setUpdId(user.getId());
			vo.setUpdDt(new Date());
		}else{
			// 등록
			vo.setRegId(user.getId());
			vo.setRegDt(new Date());
		}		
		ret = scheduleService.saveHoliday(vo);
				
		return ret;
		
	}
	
	// 공휴일 삭제	
	@RequestMapping("/schedule2/holidayRemoveProc.do")
	@ResponseBody
	public String holidayRemoveProcess(Holiday2VO vo) throws Exception{
		String ret = "N";
		
		// DB 삭제 처리		
		scheduleService.removeHoliday(vo);
		ret = "Y";
		
		return ret;
	}
	
	
	
	// 성수기 설정
	@RequestMapping("/schedule2/peakday.do")	
    public String peakdayList(@ModelAttribute("peakdayVO") Peakday2VO vo, ModelMap model) throws Exception{
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}
    	
    	// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	if(vo.getSearchYear() == null || vo.getSearchYear().equals("")) {
    		String nowYear = Integer.toString(cal.get(cal.YEAR));
    		vo.setSearchYear(nowYear);
    	}
    	    	    	
    	// 데이터 가지고 오기
    	List<Peakday2VO> list = scheduleService.getPeakdayList(vo);
		
    	model.addAttribute("list",list);
    	model.addAttribute("searchYear",vo.getSearchYear());
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule2/peakday";
				
	}
	
	// 공휴일 등록/수정 폼
	@RequestMapping("/schedule2/peakdayRegFormAjax.do")
	public String holidayRegForm(@ModelAttribute("peakdayVO") Peakday2VO vo, ModelMap model) throws Exception{
		
		// 최대 년도 구하기
    	Calendar cal = Calendar.getInstance();
    	String nowYear = Integer.toString(cal.get(cal.YEAR));
    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
    	
    	Peakday2VO retVo = new Peakday2VO();
    	// 시퀀스가 넘어오면 수정
    	if(vo.getSeq() > 0) {
    		retVo = scheduleService.getPeakdayDtl(vo);    		
    	}else {    		
    		retVo.setStdYear(nowYear);
    	}
    	    	
    	model.addAttribute("retVo",retVo);    	
    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule2/peakdayRegFormAjax";
	}
	
	// 공휴일 저장
	@RequestMapping("/schedule2/peakdayProcess.do")
	@ResponseBody
	public String peakdayProcess(Peakday2VO vo) throws Exception{
		String ret = "N";
		
		// 로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		vo.setRegId(user.getId());
		vo.setRegDt(new Date());
		if(vo.getSeq() > 0) {
    		Peakday2VO retVo = scheduleService.getPeakdayDtl(vo);
    		vo.setRegId(retVo.getRegId());
    		vo.setRegDt(retVo.getRegDt());
    		vo.setUpdId(user.getId());
    		vo.setUpdDt(new Date());
    	}else {    		
    		vo.setRegId(user.getId());
    		vo.setRegDt(new Date());
    	}
						
		ret = scheduleService.savePeakday(vo);
				
		return ret;
		
	}
	
	// 공휴일 삭제	
	@RequestMapping("/schedule2/peakdayRemoveProc.do")
	@ResponseBody
	public String peakdayRemoveProcess(Peakday2VO vo) throws Exception{
		String ret = "N";
		
		// DB 삭제 처리		
		scheduleService.removePeakday(vo);
		ret = "Y";
		
		return ret;
	}
	
	// 일정 삭제	
	@RequestMapping("/schedule2/scheduleRemoveProc.do")
	@ResponseBody
	public String scheduleRemoveProcess(ScheduleVO vo) throws Exception{
		String ret = "N";
		
		System.out.println("hello ::: " + vo.getSchdulId());
		// DB 삭제 처리		
		scheduleService.removeSchedule(vo);
		ret = "Y";
		
		return ret;
	}
	
	
	// 공공데이터 연계 공휴일 가지고 오기
	@RequestMapping("/schedule2/holidayDataApiAjax.do")
	@ResponseBody
	public String holidayDataApiAjax(Holiday2VO vo) throws Exception{
		String ret = "0";
		
		// 로그인 정보 가지고 오기		
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		vo.setRegId(user.getId());
		vo.setRegDt(new Date());
		
		// 공공데이터 연계 처리
		ret = scheduleService.getHolidayDataApi(vo);
		
		return ret;
	}
	
	// 일정관리
	@RequestMapping("/schedule2/schedule.do")	
    public String scheduleList(@ModelAttribute("scheduleVO") ScheduleVO vo, ModelMap model) throws Exception{
		
		// 0. Spring Security 사용자권한 처리
    	Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
    	if(!isAuthenticated) {
    		model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
    		return "com/sillasystem/login/login";
    	}
    	
    	// 최대 년도 구하기
//    	Calendar cal = Calendar.getInstance();
//    	String maxYear = Integer.toString(cal.get(cal.YEAR) + 1);
//    	
//    	if(vo.getSearchYear() == null || vo.getSearchYear().equals("")) {
//    		String nowYear = Integer.toString(cal.get(cal.YEAR));
//    		vo.setSearchYear(nowYear);
//    	}
    	    	    	
    	// 데이터 가지고 오기
    	List<ScheduleVO> list = scheduleService.getScheduleList();
		
    	model.addAttribute("list",list);
//    	model.addAttribute("searchYear",vo.getSearchYear());
//    	model.addAttribute("maxYear",maxYear);
		return "com/sillasystem/schedule2/schedule";
				
	}
	
	//일정 추가or수정하기(pshpsh)
	@RequestMapping("/schedule2/calenderInsertSchedule.do")
	@ResponseBody
	public String scheduleProcess(@ModelAttribute("scheduleVO") ScheduleVO vo) throws Exception {
		System.out.println("pshpsh1 ::::: " + vo.getSchdulId());
		String ret = "0";
		//로그인 정보 가지고 오기
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		if (vo.getSchdulId() == null || vo.getSchdulId().equals("")) { //값이 있다면 수정이므로 update
			vo.setSchdulId(egovFileIdGnrService.getNextStringId());
			System.out.println("pshpsh11 ::::: " + vo.getSchdulId());
			
			ret = scheduleService.insertSchedule(vo);
		} else { //값이 없다면 추가이므로 insert
			ret = scheduleService.updateSchedule(vo);
		}
		
		//스케줄 등록하기
		if (ret.equals("N")) {
			System.out.println("pshpsh ::::: db insert실패");
		}
		
		return "Y";
	}
}