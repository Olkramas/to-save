package com.sillasystem.schedule2.service.impl;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.sillasystem.schedule2.service.ScheduleDAO;
import com.sillasystem.schedule2.service.ScheduleVO;

@Repository("scheduleDAO")
public class ScheduleDAOImpl implements ScheduleDAO {
	
	@Inject
	private SqlSession sqlSession;
	
	@Override
	public int insertSchedule(ScheduleVO vo) {
		// TODO Auto-generated method stub
		return sqlSession.insert("scheduleDAO.insertSchedule", vo);
	}
	
	@Override
	public List<ScheduleVO> selectSchedule(HashMap<String, String> schMap) {
		// TODO Auto-generated method stub
		return sqlSession.selectList("scheduleDAO.selectSchedule", schMap);
	}

	@Override
	public List<ScheduleVO> selectScheduleList() {
		// TODO Auto-generated method stub
		List<ScheduleVO> list = sqlSession.selectList("scheduleDAO.selectScheduleList");
		return list;
	}

	@Override
	public ScheduleVO getScheduleDtl(ScheduleVO vo) {
		// TODO Auto-generated method stub
		ScheduleVO Schvo = sqlSession.selectOne("scheduleDAO.selectScheduleDetail", vo);
		return Schvo;
	}

	@Override
	public int updateSchedule(ScheduleVO vo) {
		// TODO Auto-generated method stub
		return sqlSession.update("scheduleDAO.updateSchedule", vo);
	}

	@Override
	public void deleteSchedule(ScheduleVO vo) {
		// TODO Auto-generated method stub
		sqlSession.delete("scheduleDAO.deleteSchedule", vo);
	}
}
