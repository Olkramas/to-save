/**
 * 
 * 관련사이트 관리 VO JPA 연동
 * 
 * @version v1.0
 * @since 2019. 05. 13
 * @author pyonkm
 *
 */


package com.sillasystem.schedule2.service;

import java.io.Serializable;

public class Calender2VO implements Serializable {
	
	private static final long serialVersionUID = -258427751470124895L;

	private String searchYear;
	
	private String searchMonth;

	public String getSearchYear() {
		return searchYear;
	}

	public void setSearchYear(String searchYear) {
		this.searchYear = searchYear;
	}

	public String getSearchMonth() {
		return searchMonth;
	}

	public void setSearchMonth(String searchMonth) {
		this.searchMonth = searchMonth;
	}
	
}
