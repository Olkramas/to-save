/**
 * 
 * 팝업관리 Service
 * 
 * @version v1.0
 * @since 2019. 05. 08
 * @author pyonkm
 *
 */
package com.sillasystem.popup.service;

import org.springframework.data.domain.Page;

public interface PopupService {
	
	public Page<PopupVO> getPopupList(PopupVO vo) throws Exception;
	
	
	public PopupVO selectPopupDetail(PopupVO vo) throws Exception;
	
	
	public void insertPopup(PopupVO vo) throws Exception;
	
	public void removePopup(PopupVO vo) throws Exception;
	
	public void removeChkPopup(PopupVO vo) throws Exception;
	
}
