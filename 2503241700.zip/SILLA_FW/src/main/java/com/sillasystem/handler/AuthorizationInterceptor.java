package com.sillasystem.handler;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.sym.mnu.mpm.service.EgovMenuManageService;
import egovframework.com.sym.mnu.mpm.service.MenuManageVO;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sillasystem.member.service.EgovUserManageService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.List;

/**
 * 페이지 오픈시 필요한 데이터 준비를 위한 Interceptor(권한체크, Contents 정보 조회, 메뉴 조회 등)
 */
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

	// 메뉴관리
	@Resource(name = "meunManageService")
	private EgovMenuManageService meunManageService;

	// 관리자 관리
	@Resource(name = "userManageService")
	private EgovUserManageService userManageService;

	/**
	 * 페이지 오픈시 필요한 데이터 준비
	 * 
	 * @param request
	 * @param response
	 * @param handler
	 * @return
	 * @throws Exception
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
    	
    	
		String reqURL = request.getRequestURI();
		

		if (!reqURL.startsWith("/login/")) {
			HttpSession session = request.getSession();

			String uniqId = "";
			/* Authenticated */
			Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
			if (isAuthenticated.booleanValue()) {
				LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
				uniqId = (user == null || user.getUniqId() == null) ? "" : user.getUniqId();
				request.setAttribute("adminName", user.getName());
			} else {
				// 로그인 안되어 로그인으로 팅굼
				ModelAndView modelAndView = new ModelAndView("redirect:/login/login.do");
				throw new ModelAndViewDefiningException(modelAndView);
			}

			// 권한 체크 시작
			String nowUrl = request.getRequestURI();
			int lastFldIndex = nowUrl.lastIndexOf("/");
			String nowFolder = nowUrl.substring(0, lastFldIndex + 1);

			// 권한체크 제외대상 설정
			List<String> excludeAuthUri = new ArrayList<String>();
			excludeAuthUri.add("/index.do");
			excludeAuthUri.add("/tree.do");
			excludeAuthUri.add("/regist.do");
			excludeAuthUri.add("/btn.do");
			excludeAuthUri.add("/jFileTest.do");
			excludeAuthUri.add("/jFileTestProc.do");
			excludeAuthUri.add("/knuResa/index.do");
			excludeAuthUri.add("/cmm/fms/FileDown.do");
			excludeAuthUri.add("/cmm/fms/imageView");
			excludeAuthUri.add("/cmm/fms/deleteFileInfs.do");

			boolean authCheck = true;

			// 권란체크 제외 대상은 체크안함
			for (String uriStr : excludeAuthUri) {
				if (nowUrl.startsWith(uriStr))
					authCheck = false;
			}

			if (authCheck) {
				MenuManageVO authChkVo = new MenuManageVO();
				authChkVo.setTmpUniqId(uniqId);
				authChkVo.setChkPath(nowFolder);
				ObjectMapper mapper = new ObjectMapper();
				String jsonString = mapper.writeValueAsString(authChkVo);
				int authChk = meunManageService.selectMenuAuth(authChkVo);
				System.out.println("authChk" + authChk);
				System.out.println(authChk);
				if (authChk == 0) {
					ModelAndView mv = new ModelAndView("/com/sillasystem/common/commonMsg");
					mv.addObject("MSG", "해당메뉴에 접근권한이 없습니다.");
					throw new ModelAndViewDefiningException(mv);
				}
			}
			// 권한 체크 끝

			// 권한명 가지고 오기
			String roleName = userManageService.selectUserRoleById(uniqId);
			request.setAttribute("roleName", roleName);
			// 권한명 가지고 오기 끝

			MenuManageVO vo = new MenuManageVO();
			vo.setTmpUniqId(uniqId);
			List<?> headMenuList = meunManageService.selectMainMenuHead(vo);
			request.setAttribute("headMenuList", headMenuList);


			// 메뉴 정보 가지고 오기
			String menuTitle = "";
			String menuPath = "<li><a href='#'><i class='glyphicon glyphicon-home'></i> Home</a></li>";

			String retStr = meunManageService.selectMenuPath(nowFolder);
			String[] spRetStr = retStr.split("/");
			
			for (int i = spRetStr.length - 1; i >= 0; i--) {
				if (i > 0) {
					menuPath += "<li><i class='glyphicon glyphicon-menu-right'></i><a href='#'>" + spRetStr[i]
							+ "</a></li>";
				} else {
					menuPath += "<li><i class='glyphicon glyphicon-menu-right'></i>" + spRetStr[i] + "</li>";
				}
				menuTitle = spRetStr[i];
			}

			request.setAttribute("menuTitle", menuTitle);
			request.setAttribute("menuPath", menuPath);
			// 메뉴 정보 가지고 오기 끝

			if (!reqURL.startsWith("/index.do")) {
				// MenuNo check 에러 처리
				int menuNo = 0;
				try {
					if (request.getParameter("currentMenuNo") != null) {
						menuNo = Integer.parseInt(request.getParameter("currentMenuNo"));
					} else {
						menuNo = Integer.parseInt(session.getAttribute("CURRENT_MENU_NO").toString());
					}

					vo.setTmpUniqId(uniqId);
					vo.setMenuNo(menuNo);

					session.setAttribute("CURRENT_MENU_NO", menuNo);

					EgovMap currentMenu = meunManageService.selectCurrentMenu(vo);
					request.setAttribute("currentMenu", currentMenu);

					menuNo = Integer.parseInt(currentMenu.get("topMenuId").toString());
				} catch (NumberFormatException ex) {
					menuNo = 0;
				} catch (NullPointerException ex) {
					menuNo = 0;
				}

				vo.setMenuNo(menuNo);
				List<?> leftMenuList = meunManageService.selectMainMenuLeft(vo);

				EgovMap topMenu = meunManageService.selectCurrentMenu(vo);
				request.setAttribute("topMenu", topMenu);
				request.setAttribute("leftMenuList", leftMenuList);

			}
		}
		return super.preHandle(request, response, handler);
	}
}
