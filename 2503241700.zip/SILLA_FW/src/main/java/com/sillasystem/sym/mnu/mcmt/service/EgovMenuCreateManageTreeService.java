package com.sillasystem.sym.mnu.mcmt.service;

import java.util.List;

import egovframework.com.cmm.ComDefaultVO;

public interface EgovMenuCreateManageTreeService {

	
	List<?> selectAuthorCode() throws Exception;
	
	List<?> selectMenuCreatManagTreeList(MenuCreateTreeVO vo) throws Exception;
	
	void insertMenuCreatTreeList(String selectedMenuNoForInsert, String selectedAuthorForInsert) throws Exception;
}
