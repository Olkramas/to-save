package com.sillasystem.sym.mnu.mcmt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sillasystem.sym.mnu.mcmt.service.EgovMenuCreateManageTreeService;
import com.sillasystem.sym.mnu.mcmt.service.MenuCreateTreeVO;


@Service("menuCreateManageTreeService")
public class EgovMenuCreateManageTreeServiceImpl implements EgovMenuCreateManageTreeService{


	@Resource(name="menuManageTreeDAO")
	private EgovMenuCreateManageTreeDAO menuManageTreeDAO;
	
	public List<?> selectAuthorCode() throws Exception {
		// TODO Auto-generated method stub
		return menuManageTreeDAO.selectAuthorCode();
	}

	
	public List<?> selectMenuCreatManagTreeList(MenuCreateTreeVO vo) throws Exception {
		// TODO Auto-generated method stub
		return menuManageTreeDAO.selectMenuCreatManagTreeList(vo);
	}


	public void insertMenuCreatTreeList(String selectedMenuNoForInsert, String selectedAuthorForInsert)
			throws Exception {
		// TODO Auto-generated method stub
		MenuCreateTreeVO menuCreateTreeVO = null;
		int AuthorCnt = 0;
		String[] insertMenuNo = selectedMenuNoForInsert.split(",");
		
		String insertAuthor = selectedAuthorForInsert;
		
		menuCreateTreeVO = new MenuCreateTreeVO();
		menuCreateTreeVO.setAuthorCode(insertAuthor);
		AuthorCnt = menuManageTreeDAO.selectMenuCreatCnt(menuCreateTreeVO);
		
		if(AuthorCnt>0) {
			menuManageTreeDAO.deleteMenuCreat(menuCreateTreeVO);
		}
		for(int i=0; i<insertMenuNo.length; i++) {
			menuCreateTreeVO.setAuthorCode(insertAuthor);
			menuCreateTreeVO.setMenuNo(Integer.parseInt(insertMenuNo[i]));
			menuManageTreeDAO.insertMenuCreat(menuCreateTreeVO);
		}
	}
	


}
