package com.sillasystem.main.controller;

import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.EgovFileMngService;
import egovframework.com.cmm.service.EgovFileMngUtil;
import egovframework.com.cmm.service.EgovProperties;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import egovframework.rte.fdl.property.EgovPropertyService;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sillasystem.common.CommonUtil;
import com.sillasystem.common.SillaFileUtil;


@Controller
public class MainController {
	
	@Resource(name="EgovFileMngService")
	EgovFileMngService fileMngService;
	
	@Resource(name="EgovFileMngUtil")
	EgovFileMngUtil fileUtil;
	
	@Resource(name="sillaFileUtil")
	SillaFileUtil sillaFileUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(MainController.class);
    
    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertyService;

    @RequestMapping("/index.do")
    public String index(ModelMap model) {
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        LOGGER.debug("User Id : {}", user == null ? "" : EgovStringUtil.isNullToString(user.getId()));
         return "com/sillasystem/index";
    }
    
    @RequestMapping("/list.do")
    public String list(ModelMap model) {        
         return "com/sillasystem/main";
    }
    
    @RequestMapping("/tree.do")
    public String tree(ModelMap model) {
        return "com/sillasystem/tree";
    }
    
    @RequestMapping("/regist.do")
    public String regist(ModelMap model) {
        return "com/sillasystem/regist";
    }
    
    @RequestMapping("/btn.do")
    public String btn(ModelMap model) {
        return "com/sillasystem/btn";
    }
    
    @RequestMapping("/jFileTest.do")
    public String jFileTest(HttpServletRequest request,ModelMap model) throws Exception{
    	
    	// 첨부파일 가지고 오기
    	String atchFileId = request.getParameter("atchFileId");
    	List<FileVO> fileList = sillaFileUtil.getFileList(atchFileId); 	
    	model.addAttribute("fileList",fileList);
    	
    	model.addAttribute("atchFileId", atchFileId);    	
        return "com/sillasystem/jFile";
    }
    
    // jfile upload test
 	@RequestMapping("/jFileTestProc.do")
 	@ResponseBody
 	public String jFileTestProc(MultipartHttpServletRequest request) throws Exception{
 		String ret = "Y";
 		String atchFileId = request.getParameter("atchFileId");

 		String uploadPath = propertyService.getString("Globals.fileStorePath") + "/test/";
 		 		
 		String retFileId = sillaFileUtil.uploadFile(request, uploadPath, atchFileId);
 		
 		/*
 		String retFileId = "";
 		final Map<String, MultipartFile> files = request.getFileMap(); 		
 		if(!files.isEmpty()) { 			
 			List<FileVO> result = null;
 			if(atchFileId == null || atchFileId.equals("")) {
 				System.out.println("등록모드");
	 			result = fileUtil.parseFileInf(files, "FILE_", 0, "", uploadPath);
	 			retFileId = fileMngService.insertFileInfs(result);	 			
 			}else {
 				System.out.println("수정모드");
 				FileVO fvo = new FileVO();
 				fvo.setAtchFileId(atchFileId); // 최종 파일 순번을 획득하기 위하여 VO에 현재 첨부파일 ID를 세팅한다.
 				int fileCnt = fileMngService.getMaxFileSN(fvo); // 해당 첨부파일 ID에 속하는 최종 파일 순번을 획득한다. 				
 				result = fileUtil.parseFileInf(files, "FILE_", fileCnt, atchFileId, uploadPath);	
 				fileMngService.updateFileInfs(result);
 				retFileId = atchFileId;
 			}
 			
 			CommonUtil util = new CommonUtil();
 			util.createThumbnailByFileVO(result);
 		}
 		*/
 		
 		
 		return retFileId;
 	}
    
    

}
