package com.sillasystem.menuManage.service.impl;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sillasystem.menuManage.dao.MenuManageDAO;
import com.sillasystem.menuManage.service.MenuManageService;
import com.sillasystem.menuManage.service.MenuManageVO;

@Service("newMenuManageService")
public class MenuManageServiceImpl implements MenuManageService {
	
	@Resource(name="newMenuManageDAO")
	private MenuManageDAO menuManageDAO;
	
	// 전체 메뉴 가지고 오기
	public List<?> selectMenuList(MenuManageVO vo) throws SQLException{
		return menuManageDAO.selectMenuList(vo);
	}
	
	// 메뉴 상세 가지고 오기
	public MenuManageVO selectMenuDetail(MenuManageVO vo) throws SQLException{
		return menuManageDAO.selectMenuDetail(vo);
	}
	
	// 등록용 메뉴 시퀀스 가지고 오기
	public String selectMenuSeq(MenuManageVO vo) throws SQLException{
		return menuManageDAO.selectMenuSeq(vo);
	}
	
	// 하위메뉴 갰수 가지고 오기
	public int selectChildrenMenuCnt(MenuManageVO vo) throws SQLException{
		return menuManageDAO.selectChildrenMenuCnt(vo);
	}
	
	// 권한 가지고 오기
	public List<?> selectAuthor(MenuManageVO vo) throws SQLException{
		return menuManageDAO.selectAuthor(vo);
	}
	
	// 메뉴 등록
	public void insertMenu(MenuManageVO vo) throws SQLException{
		menuManageDAO.insertMenu(vo);
	}
	
	// 메뉴 권한 등록
	public void insertMenuAuth(MenuManageVO vo) throws SQLException{
		menuManageDAO.insertMenuAuth(vo);
	}
	
	// 메뉴 수정
	public void updateMenu(MenuManageVO vo) throws SQLException{
		menuManageDAO.updateMenu(vo);
	}
	
	// 메뉴 삭제
	public void deleteMenu(MenuManageVO vo) throws SQLException{
		menuManageDAO.deleteMenu(vo);
	}
	
	// 메뉴 권한 삭제
	public void deleteMenuAuth(MenuManageVO vo) throws SQLException{
		menuManageDAO.deleteMenuAuth(vo);
	}

}
