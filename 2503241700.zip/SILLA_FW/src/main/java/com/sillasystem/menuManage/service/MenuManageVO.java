package com.sillasystem.menuManage.service;

import java.io.Serializable;

public class MenuManageVO implements Serializable {

	private static final long serialVersionUID = 8929153450087695338L;
	
	private String menuNm;				// 메뉴명
	private String progrmFileNm;		// 프로그램 파일명
	private String menuNo;				// 메뉴번호
	private String upperMenuNo;			// 상위 메뉴 번호
	private String upperMenuNm;			// 상위 메뉴 명
	private String menuOrdr;			// 메뉴슌서
	private String menuDc;				// 메뉴설명
	private String relateImagePath;		// 관계이미지경로
	private String relateImageNm;		// 관계이미지명
	private String menuViewYn;			// 메뉴 표시여부
	private String userType;			// 사용자유형
	private String mode;				// 등록/수정/삭제 모드
	
	// 권한 관련
	private String[] arrAuthorCode;		// 권란코드 등록용 배열
	private String authorCode;			// 권한코드
	
	
	public String getMenuNm() {
		return menuNm;
	}
	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}
	public String getProgrmFileNm() {
		return progrmFileNm;
	}
	public void setProgrmFileNm(String progrmFileNm) {
		this.progrmFileNm = progrmFileNm;
	}
	public String getMenuNo() {
		return menuNo;
	}
	public void setMenuNo(String menuNo) {
		this.menuNo = menuNo;
	}
	public String getUpperMenuNo() {
		return upperMenuNo;
	}
	public void setUpperMenuNo(String upperMenuNo) {
		this.upperMenuNo = upperMenuNo;
	}
	public String getUpperMenuNm() {
		return upperMenuNm;
	}
	public void setUpperMenuNm(String upperMenuNm) {
		this.upperMenuNm = upperMenuNm;
	}
	public String getMenuOrdr() {
		return menuOrdr;
	}
	public void setMenuOrdr(String menuOrdr) {
		this.menuOrdr = menuOrdr;
	}
	public String getMenuDc() {
		return menuDc;
	}
	public void setMenuDc(String menuDc) {
		this.menuDc = menuDc;
	}
	public String getRelateImagePath() {
		return relateImagePath;
	}
	public void setRelateImagePath(String relateImagePath) {
		this.relateImagePath = relateImagePath;
	}
	public String getRelateImageNm() {
		return relateImageNm;
	}
	public void setRelateImageNm(String relateImageNm) {
		this.relateImageNm = relateImageNm;
	}
	public String getMenuViewYn() {
		return menuViewYn;
	}
	public void setMenuViewYn(String menuViewYn) {
		this.menuViewYn = menuViewYn;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String[] getArrAuthorCode() {
		return arrAuthorCode;
	}
	public void setArrAuthorCode(String[] arrAuthorCode) {
		this.arrAuthorCode = arrAuthorCode;
	}
	public String getAuthorCode() {
		return authorCode;
	}
	public void setAuthorCode(String authorCode) {
		this.authorCode = authorCode;
	}
	
	
}
