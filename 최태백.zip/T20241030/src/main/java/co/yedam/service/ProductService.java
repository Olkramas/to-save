package co.yedam.service;

import java.util.List;

import co.yedam.vo.ProductVO;

public interface ProductService {
	//String cheeringMessage();
	//String hintMessage(String remainTimeString);
	
	//전체리스트
	List<ProductVO> productList();
	//상품 상세보기
	ProductVO Product(String prdName);
}
