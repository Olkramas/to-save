package co.yedam.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.yedam.common.Control;
import co.yedam.service.ProductService;
import co.yedam.service.ProductServiceImpl;
import co.yedam.vo.ProductVO;

public class ProductListControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//svc로 전체 리스트 가져오기
		ProductService svc = new ProductServiceImpl();
		
		List<ProductVO> list = svc.productList();
		
		//setAttribute로 반환된 리스트 넘기기
		req.setAttribute("productList", list);
		
		//.jsp페이지로 연결
		req.getRequestDispatcher("jsp/productList.tiles").forward(req, resp);
	}

}
