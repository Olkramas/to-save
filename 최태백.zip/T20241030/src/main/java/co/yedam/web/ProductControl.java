package co.yedam.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.yedam.common.Control;
import co.yedam.service.ProductService;
import co.yedam.service.ProductServiceImpl;
import co.yedam.vo.ProductVO;

public class ProductControl implements Control {

	@Override
	public void exec(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//서비스 객체
		ProductService svc = new ProductServiceImpl();
		
		//상품 리스트 페이지에서 넘긴 파라미터 변수에 저장
		String pno = req.getParameter("pno");
		
		//상품 상세 정보 가져오기
		ProductVO product = svc.Product(pno);
		
		//가져온 상세정보를 넘겨받기위해서 속성 설정
		req.setAttribute("product", product);
		
		//리스트 넘기기
		List<ProductVO> list = svc.productList();
		req.setAttribute("productList", list);
		
		//상세페이지로 이동
		req.getRequestDispatcher("jsp/productInfo.tiles").forward(req, resp);

	}

}
