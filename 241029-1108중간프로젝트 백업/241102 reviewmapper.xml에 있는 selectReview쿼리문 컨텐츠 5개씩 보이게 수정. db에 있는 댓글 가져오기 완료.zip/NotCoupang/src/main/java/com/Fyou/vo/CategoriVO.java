package com.Fyou.vo;

import lombok.Data;

@Data
public class CategoriVO {
	private int seqCate;
	private String Tcate;
	private String Bcate;
}
