package com.Fyou.vo;

import lombok.Data;

@Data
public class ImgVO {
	private int seqImg;
	private int goodsNum;
	private String imgUrl;
	
}
