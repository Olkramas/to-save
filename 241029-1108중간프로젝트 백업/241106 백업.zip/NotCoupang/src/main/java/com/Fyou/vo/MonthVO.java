package com.Fyou.vo;

import lombok.Data;

@Data
public class MonthVO {
	private int M01 = 0;
	private int M02 = 0;
	private int M03 = 0;
	private int M04 = 0;
	private int M05 = 0;
	private int M06 = 0;
	private int M07 = 0;
	private int M08 = 0;
	private int M09 = 0;
	private int M10 = 0;
	private int M11 = 0;
	private int M12 = 0;
}
