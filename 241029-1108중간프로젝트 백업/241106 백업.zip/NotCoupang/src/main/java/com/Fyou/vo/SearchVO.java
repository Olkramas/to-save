package com.Fyou.vo;

import lombok.Data;

@Data
public class SearchVO {
	private String tCate;
	private String bCate;
	private String keyword;
	private int page;

}
