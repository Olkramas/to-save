package com.Fyou.vo;

import lombok.Data;

@Data
public class SellerCateVO {
	private String goodsCatename;
	private int total;
}
