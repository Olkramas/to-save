// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

// Pie Chart Example
var ctx = document.getElementById("myPieChart");
var myPieChart = new Chart(ctx, {
  type: 'doughnut',
  data: {
    labels: pie_labels,
    datasets: [{
      data: pie_data,
      backgroundColor: ['#0109DA', '#D6C9ED', '#2353E3', '#5564DF', '#AEADEB', '#09315C', '#176899', '#EAE6E6', '#53929E', '#2A4756'],
      hoverBackgroundColor: ['#0109DA', '#D6C9ED', '#2353E3', '#5564DF', '#AEADEB', '#09315C', '#176899', '#EAE6E6', '#53929E', '#2A4756'],
      hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: false
    },
    cutoutPercentage: 0,
  },
});