package apptest;

import com.Fyou.service.ImgService;
import com.Fyou.service.ImgServiceImpl;

public class apptest {
	public static void main(String[] args) {
		
		ImgService svc = new ImgServiceImpl();
		
		
	}
}
