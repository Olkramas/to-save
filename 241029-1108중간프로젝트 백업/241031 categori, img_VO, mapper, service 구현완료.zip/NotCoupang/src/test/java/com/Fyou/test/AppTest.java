package com.Fyou.test;

import com.Fyou.service.CategoriService;
import com.Fyou.service.CategoriServiceImpl;

public class AppTest {
	public static void main(String[] args) {
		//CategoriService svc = new CategoriServiceImpl();
		
		
		
	}
}
