package egovframework.com.cmm.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.web.servlet.view.document.AbstractXlsxView;

import egovframework.rte.psl.dataaccess.util.EgovMap;

public class ExcelView extends AbstractXlsxView {

	/*
	 * Excel 엑셀 다운로드
	 *
	 * @param fileName String
	 * 
	 * @param title List
	 * 
	 * @param header List
	 * 
	 * @param column List
	 * 
	 * @param data List
	 * 
	 * @param startDt String
	 * 
	 * @param endDt String
	 *
	 **/
	@Override
	protected void buildExcelDocument(Map<String, Object> model, Workbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Sheet sheet = workbook.createSheet("sheet");
		Row row;
		Cell cell;
		int rowNum = 0;

		Date date = new Date(System.currentTimeMillis());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		String fDate = dateFormat.format(date);
		String fileName = (String) model.get("fileName") + "_" + fDate;	//파일명에 "_오늘날짜" 붙임

		fileName = new String(fileName.getBytes("utf-8"), "8859_1") + ".xlsx";
		response.addHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");

		// title style
		CellStyle titleStyle = workbook.createCellStyle();
		titleStyle.setBorderTop(BorderStyle.THIN);
		titleStyle.setBorderBottom(BorderStyle.THIN);
		titleStyle.setBorderLeft(BorderStyle.THIN);
		titleStyle.setBorderRight(BorderStyle.THIN);
		titleStyle.setFillForegroundColor(HSSFColorPredefined.GREY_25_PERCENT.getIndex());
		titleStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		titleStyle.setAlignment(HorizontalAlignment.CENTER);

		// dt style
		CellStyle dtStyle = workbook.createCellStyle();
		dtStyle.setBorderTop(BorderStyle.THIN);
		dtStyle.setBorderBottom(BorderStyle.THIN);
		dtStyle.setBorderLeft(BorderStyle.THIN);
		dtStyle.setBorderRight(BorderStyle.THIN);
		dtStyle.setAlignment(HorizontalAlignment.RIGHT);

		// header style
		CellStyle headStyle = workbook.createCellStyle();
		headStyle.setBorderTop(BorderStyle.THIN);
		headStyle.setBorderBottom(BorderStyle.THIN);
		headStyle.setBorderLeft(BorderStyle.THIN);
		headStyle.setBorderRight(BorderStyle.THIN);
		headStyle.setFillForegroundColor(HSSFColorPredefined.LEMON_CHIFFON.getIndex());
		headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headStyle.setAlignment(HorizontalAlignment.CENTER);

		// data style center
		CellStyle dataStyleCenter = workbook.createCellStyle();
		dataStyleCenter.setAlignment(HorizontalAlignment.CENTER);
		dataStyleCenter.setBorderTop(BorderStyle.THIN);
		dataStyleCenter.setBorderBottom(BorderStyle.THIN);
		dataStyleCenter.setBorderLeft(BorderStyle.THIN);
		dataStyleCenter.setBorderRight(BorderStyle.THIN);

		// data style left
		CellStyle dataStyleLeft = workbook.createCellStyle();
		dataStyleLeft.setAlignment(HorizontalAlignment.LEFT);
		dataStyleLeft.setBorderTop(BorderStyle.THIN);
		dataStyleLeft.setBorderBottom(BorderStyle.THIN);
		dataStyleLeft.setBorderLeft(BorderStyle.THIN);
		dataStyleLeft.setBorderRight(BorderStyle.THIN);

		// data style right
		CellStyle dataStyleRight = workbook.createCellStyle();
		dataStyleRight.setAlignment(HorizontalAlignment.RIGHT);
		dataStyleRight.setBorderTop(BorderStyle.THIN);
		dataStyleRight.setBorderBottom(BorderStyle.THIN);
		dataStyleRight.setBorderLeft(BorderStyle.THIN);
		dataStyleRight.setBorderRight(BorderStyle.THIN);

		List<String> header = (List<String>) model.get("header");

		// title 출력
		if (model.get("title") != null) {
			String title = (String) model.get("title");
			row = sheet.createRow(rowNum++);
			int colNum = 0;

			for (String h : header) {
				cell = row.createCell(colNum++);
				cell.setCellStyle(titleStyle);
				cell.setCellValue(title);

			}

			sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, header.size() - 1));

		}

		// dt 출력
		if (model.get("startDt") != null || model.get("endDt") != null) {
			row = sheet.createRow(rowNum++);
			int colNum = 0;

			String startDt = (String) model.get("startDt");
			String endDt = (String) model.get("endDt");
			String dt = "기간: " + startDt + " ~ " + endDt;

			for (String h : header) {
				cell = row.createCell(colNum++);
				cell.setCellStyle(dtStyle);
				cell.setCellValue(dt);
			}

			sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, header.size() - 1));

		}

		// header 출력
		if (header != null) {
			row = sheet.createRow(rowNum++);
			int colNum = 0;

			for (String h : header) {
				cell = row.createCell(colNum++);
				cell.setCellStyle(headStyle);
				cell.setCellValue(h);
			}

		}

		List<String> column = (List<String>) model.get("column");
		List<EgovMap> list = (List<EgovMap>) model.get("data");

		// data 출력
		if (list != null) {
			for (Map<String, Object> m : list) {
				row = sheet.createRow(rowNum++);
				int colNum = 0;
				for (String c : column) {
					cell = row.createCell(colNum++);
					Object field = m.get(c);
					if (field == null) {
						field = "";
					}

					if (field instanceof String) {
						cell.setCellValue((String) field);
						cell.setCellStyle(dataStyleCenter);
					} else if (field instanceof BigDecimal) {
						cell.setCellValue(((BigDecimal) field).doubleValue());
						cell.setCellStyle(dataStyleRight);
					} else if (field instanceof Date) {
						cell.setCellValue((Date) field);
						cell.setCellStyle(dataStyleCenter);
					} else {
						cell.setCellValue(field.toString());
						cell.setCellStyle(dataStyleLeft);
					}
					sheet.autoSizeColumn(colNum - 1);
					sheet.setColumnWidth(colNum, Math.min(255*256, sheet.getColumnWidth(colNum) + 1024));	
				}
			}
		} else {
			for (Map<String, Object> m : list) {
				row = sheet.createRow(rowNum++);
				Iterator<String> iter = m.keySet().iterator();
				int colNum = 0;

				while (iter.hasNext()) {
					cell = row.createCell(colNum++);
					Object field = m.get(iter.next());

					if (field instanceof String) {
						cell.setCellValue((String) field);
						cell.setCellStyle(dataStyleCenter);
					} else if (field instanceof BigDecimal) {
						cell.setCellValue(((BigDecimal) field).doubleValue());
						cell.setCellStyle(dataStyleRight);
					} else if (field instanceof Date) {
						cell.setCellValue((Date) field);
						cell.setCellStyle(dataStyleCenter);
					} else {
						cell.setCellValue(field.toString());
						cell.setCellStyle(dataStyleLeft);
					}
					sheet.autoSizeColumn(colNum - 1);
					sheet.setColumnWidth(colNum - 1, (sheet.getColumnWidth(colNum - 1)) + 1000);
				}
			}
		}

	}

}

