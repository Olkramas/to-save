package com.sillasystem.sym.mnu.mcmt.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.sym.mnu.mcmt.service.MenuCreateTreeVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

@Repository("menuManageTreeDAO")
public class EgovMenuCreateManageTreeDAO extends EgovComAbstractDAO{
	
	public List<?> selectAuthorCode() throws Exception{
		return selectList("menuManageTreeDAO.selectAuthorCode");
	}
	
	public List<?> selectMenuCreatManagTreeList(MenuCreateTreeVO vo) throws Exception{
		return selectList("menuManageTreeDAO.selectMenuCreatList_D", vo);
	}
	public int selectMenuCreatCnt(MenuCreateTreeVO vo) throws Exception{
		return (Integer)selectOne("menuManageTreeDAO.selectMenuCreatCnt_S",vo);
	}
	public void deleteMenuCreat(MenuCreateTreeVO vo) {
		delete("menuManageTreeDAO.deleteMenuCreat_S", vo);
	}
	public void insertMenuCreat(MenuCreateTreeVO vo) {
		insert("menuManageTreeDAO.insertMenuCreat_S", vo);
	}
}
