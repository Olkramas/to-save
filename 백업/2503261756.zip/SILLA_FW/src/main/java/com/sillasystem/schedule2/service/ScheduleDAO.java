package com.sillasystem.schedule2.service;

import java.util.HashMap;
import java.util.List;

public interface ScheduleDAO {
	//스케줄 등록
	public int insertSchedule(ScheduleVO vo);
	
	//스케줄 수정
	public int updateSchedule(ScheduleVO vo);
	
	//스케줄 리스트 불러오기
	public List<ScheduleVO> selectSchedule(HashMap<String, String> schMap);
	
	//스케줄 관리(수정, 삭제 등)
	public List<ScheduleVO> selectScheduleList();
	
	//스케줄 상세보기(or스케줄 수정폼)
	public ScheduleVO getScheduleDtl(ScheduleVO vo);
	
	//스케줄 삭제
	public void deleteSchedule(ScheduleVO vo);
}