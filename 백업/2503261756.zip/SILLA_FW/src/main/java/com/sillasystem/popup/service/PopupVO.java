/**
 * 
 * 팝업관리 VO JPA 연동
 * 
 * @version v1.0
 * @since 2019. 05. 08
 * @author pyonkm
 *
 */
package com.sillasystem.popup.service;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;



@Entity
@Table(name="SILLA_POPUP")
public class PopupVO implements Serializable {
	
	private static final long serialVersionUID = -5364439428393953896L;
	
	// 시퀀스
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SEQ" )
	private int seq;
	
	// 제목
	@Column(name="TITLE" )
	private String title;
	
	// 시작일
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	@Column(name="START_DT" )
	private Date startDt;
		
	// 종료일
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name="END_DT" )
	private Date endDt;
		
	// 가로사이즈
	@Column(name="WIDTH" )
	private int width;
	
	// 세로사이즈
	@Column(name="HEIGHT" )
	private int height;
	
	// 가로위치
	@Column(name="HORIZONTAL" )
	private int horizontal;
	
	// 세로위치
	@Column(name="VERTICAL" )
	private int vertical;
	
	// 레이어팝업여부
	@Column(name="LAYER_YN" )
	private String layerYn;
	
	// 대체텍스트
	@Column(name="IMG_TEXT" )
	private String imgText;
		
	// 링크주소
	@Column(name="LINK_URL" )
	private String linkUrl;
	
	// 링크타겟
	@Column(name="LINK_TARGET" )
	private String linkTarget;
	
	// 쿠키설정
	@Column(name="COOKIE_YN" )
	private String cookieYn;
	
	// 이미지명
	@Column(name="IMG_NAME" )
	private String imgName;
	
	// 원본 이미지명
	@Column(name="ORIGNL_FILE_NM" )
	private String orignlFileNm;
	
	// 이미지경로
	@Column(name="IMG_PATH" )
	private String imgPath;
	
	// 사용여부
	@Column(name="USE_YN" )
	private String useYn;
	
	// 삭제여부
	@Column(name="DEL_YN" )
	private String delYn;
	
	// 파일연동여부
	@Column(name="SYNC_YN" )
	private String syncYn;
	
	// 등록자
	@Column(name="REG_ID" )
	private String regId;
	
	// 등록일
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="REG_DT" )
	private Date regDt;
	
	// 수정자
	@Column(name="UPD_ID" )
	private String updId;
	
	// 수정일
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPD_DT" )
	private Date updDt;
	
	// 페이징 관련
	@Transient
	private int pageIndex = 1;
	
	// 선택 삭제용
	@Transient
	private String chkDel;
	
	// 제목 검색어
	@Transient
	private String searchTxt;
	
	// 검색 시작일
	@Transient
	private String searchStartDt;
	
	
	// 검색 종료일
	@Transient
	private String searchEndDt;
	
	// 등록/수정 구분
	@Transient
	private String modGbn;

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getStartDt() {
		return startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getHorizontal() {
		return horizontal;
	}

	public void setHorizontal(int horizontal) {
		this.horizontal = horizontal;
	}

	public int getVertical() {
		return vertical;
	}

	public void setVertical(int vertical) {
		this.vertical = vertical;
	}

	public String getLayerYn() {
		return layerYn;
	}

	public void setLayerYn(String layerYn) {
		this.layerYn = layerYn;
	}

	public String getImgText() {
		return imgText;
	}

	public void setImgText(String imgText) {
		this.imgText = imgText;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public String getLinkTarget() {
		return linkTarget;
	}

	public void setLinkTarget(String linkTarget) {
		this.linkTarget = linkTarget;
	}

	public String getCookieYn() {
		return cookieYn;
	}

	public void setCookieYn(String cookieYn) {
		this.cookieYn = cookieYn;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	public String getOrignlFileNm() {
		return orignlFileNm;
	}

	public void setOrignlFileNm(String orignlFileNm) {
		this.orignlFileNm = orignlFileNm;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}

	public String getSyncYn() {
		return syncYn;
	}

	public void setSyncYn(String syncYn) {
		this.syncYn = syncYn;
	}

	public String getRegId() {
		return regId;
	}

	public void setRegId(String regId) {
		this.regId = regId;
	}

	public Date getRegDt() {
		return regDt;
	}

	public void setRegDt(Date regDt) {
		this.regDt = regDt;
	}

	public String getUpdId() {
		return updId;
	}

	public void setUpdId(String updId) {
		this.updId = updId;
	}

	public Date getUpdDt() {
		return updDt;
	}

	public void setUpdDt(Date updDt) {
		this.updDt = updDt;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public String getModGbn() {
		return modGbn;
	}

	public void setModGbn(String modGbn) {
		this.modGbn = modGbn;
	}

	public String getChkDel() {
		return chkDel;
	}

	public void setChkDel(String chkDel) {
		this.chkDel = chkDel;
	}

	public String getSearchTxt() {
		return searchTxt;
	}

	public void setSearchTxt(String searchTxt) {
		this.searchTxt = searchTxt;
	}

	public String getSearchStartDt() {
		return searchStartDt;
	}

	public void setSearchStartDt(String searchStartDt) {
		this.searchStartDt = searchStartDt;
	}

	public String getSearchEndDt() {
		return searchEndDt;
	}

	public void setSearchEndDt(String searchEndDt) {
		this.searchEndDt = searchEndDt;
	}
		
}
