package com.sillasystem.roleGroup.service;

import java.util.List;


public class RoleGroupVO extends RoleGroup{
	private static final long serialVersionUID = 1L;

	List <RoleGroupVO> authorGroupList;

	/**
	 * authorGroupList attribute 를 리턴한다.
	 * @return List<AuthorGroupVO>
	 */
	public List<RoleGroupVO> getAuthorGroupList() {
		return authorGroupList;
	}
	/**
	 * authorGroupList attribute 값을 설정한다.
	 * @param authorGroupList List<AuthorGroupVO> 
	 */
	public void setAuthorGroupList(List<RoleGroupVO> authorGroupList) {
		this.authorGroupList = authorGroupList;
	}
}
