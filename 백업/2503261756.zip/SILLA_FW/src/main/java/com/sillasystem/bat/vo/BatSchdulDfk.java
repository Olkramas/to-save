package com.sillasystem.bat.vo;

import java.io.Serializable;

public class BatSchdulDfk implements Serializable{
	private static final long serialVersionUID = -4152071306992476556L;

	/**
	 * 배치스케줄ID
	 */
	private String batchSchdulId;

	/**
	 * 실행스케줄요일
	 */
	private String executSchdulDfkSe;

	/**
	 * 실행스케줄요일명
	 */
	private String executSchdulDfkSeNm;


	/**
	 * @return the batchSchdulId
	 */
	public String getBatchSchdulId() {
		return batchSchdulId;
	}
	/**
	 * @return the executSchdulDfkSe
	 */
	public String getExecutSchdulDfkSe() {
		return executSchdulDfkSe;
	}
	/**
	 * @param batchSchdulId the batchSchdulId to set
	 */
	public void setBatchSchdulId(String batchSchdulId) {
		this.batchSchdulId = batchSchdulId;
	}
	/**
	 * @param executSchdulDfkSe the executSchdulDfkSe to set
	 */
	public void setExecutSchdulDfkSe(String executSchdulDfkSe) {
		this.executSchdulDfkSe = executSchdulDfkSe;
	}
	/**
	 * @return the executSchdulDfkSeNm
	 */
	public String getExecutSchdulDfkSeNm() {
		return executSchdulDfkSeNm;
	}
	/**
	 * @param executSchdulDfkSeNm the executSchdulDfkSeNm to set
	 */
	public void setExecutSchdulDfkSeNm(String executSchdulDfkSeNm) {
		this.executSchdulDfkSeNm = executSchdulDfkSeNm;
	}
}
