/**
 * 
 * 배너 관리 JPA Repository
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.banner.repository;

import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.sillasystem.banner.service.BannerVO;


public interface BannerRepository extends JpaRepository<BannerVO, String> {
	
	Page<BannerVO> findAll(Specification<Content> spec, Pageable pageable);
	
	BannerVO findOneBySeq(int seq);

	@Transactional
	@Modifying
	@Query(value="UPDATE SILLA_BANNER SET DEL_YN='Y',UPD_DT=NOW(),UPD_ID= :updId WHERE SEQ= :seq", nativeQuery = true)
	void updateDelYn(@Param("seq")int seq,@Param("updId")String updId) throws Exception;
	
}
