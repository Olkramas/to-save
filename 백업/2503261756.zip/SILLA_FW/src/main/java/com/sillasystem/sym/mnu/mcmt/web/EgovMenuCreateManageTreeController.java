package com.sillasystem.sym.mnu.mcmt.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sillasystem.sym.mnu.mcmt.service.EgovMenuCreateManageTreeService;
import com.sillasystem.sym.mnu.mcmt.service.MenuCreateTreeVO;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.util.EgovUserDetailsHelper;


@Controller
public class EgovMenuCreateManageTreeController {
	
	@Resource(name="menuCreateManageTreeService")
	private EgovMenuCreateManageTreeService menuCreateManageTreeService;
	
	@Resource(name="egovMessageSource")
	EgovMessageSource egovMessageSource;

	@RequestMapping(value = "/sym/mnu/mcmt/EgovMenuCreatManageSelectTree.do")
	public String selectMenuCreatManageListTree(@ModelAttribute("searchVO") MenuCreateTreeVO searchVO, ModelMap model) throws Exception {
		String resultMsg = "";
		String resultMsgMenu = "";
		
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}
		
		List<?> list_menuManage = menuCreateManageTreeService.selectMenuCreatManagTreeList(searchVO);
		if(list_menuManage.size() ==0 )
			resultMsgMenu = egovMessageSource.getMessage("info.nodata.msg");
		model.addAttribute("list_menuManage",list_menuManage);
		
		List<?> list_authorCode = menuCreateManageTreeService.selectAuthorCode();
		if(list_authorCode.size()==0)
			resultMsg = egovMessageSource.getMessage("info.nodata.msg");
		model.addAttribute("list_authorCode",list_authorCode);
		model.addAttribute("resultMsg", resultMsg);
		model.addAttribute("resultMsgMenu",resultMsgMenu);
		model.addAttribute("searchVO", searchVO);
		
		return "com/sillasystem/sym/mnu/mcmt/EgovMenuCreatManageTree";
	}
	@RequestMapping(value="/sym/mnu/mcmt/EgovMenuCreatManageInsertTree.do")
	public String insertMenuCreatTree(@RequestParam("selectedMenuNoForInsert")String selectedMenuNoForInsert, @RequestParam("selectedAuthorForInsert")String selectedAuthorForInsert,
			@ModelAttribute("searchVO") MenuCreateTreeVO searchVO, ModelMap model) throws Exception{
		
		String resultMsg = "";
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}
		String[] insertMenuNo = selectedMenuNoForInsert.split(",");
		if(insertMenuNo == null || (insertMenuNo.length==0)) {
			resultMsg = egovMessageSource.getMessage("fail.common.insert");
		} else {
			menuCreateManageTreeService.insertMenuCreatTreeList(selectedMenuNoForInsert, selectedAuthorForInsert);
			resultMsg = egovMessageSource.getMessage("success.common.insert");
		}
		model.addAttribute("resultMsg", resultMsg);
		
		return "forward:/sym/mnu/mcmt/EgovMenuCreatManageSelectTree.do";
	}
}
