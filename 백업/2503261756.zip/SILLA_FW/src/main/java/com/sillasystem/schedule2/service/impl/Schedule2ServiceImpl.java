/**
 * 
 * 관련사이트 관리 Service Impl
 * 
 * @version v1.0
 * @since 2019. 05. 12
 * @author pyonkm
 *
 */

package com.sillasystem.schedule2.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.swing.text.AbstractDocument.Content;
import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.poi.xssf.model.MapInfo;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sillasystem.relateSite.repository.SearchSpec;
import com.sillasystem.schedule2.repository.Holiday2Repository;
import com.sillasystem.schedule2.repository.Holiday2SearchSpec;
import com.sillasystem.schedule2.repository.Peakday2Repository;
import com.sillasystem.schedule2.repository.Peakday2SearchSpec;
import com.sillasystem.schedule2.service.Holiday2VO;
import com.sillasystem.schedule2.service.Peakday2VO;
import com.sillasystem.schedule2.service.Schedule2Service;
import com.sillasystem.schedule2.service.ScheduleDAO;
import com.sillasystem.schedule2.service.ScheduleVO;

import egovframework.rte.fdl.property.EgovPropertyService;

@Service("schedule2Service")
public class Schedule2ServiceImpl implements Schedule2Service {
	
	@Resource(name="holiday2Repository")
	Holiday2Repository holidayRepository;
	
	@Resource(name="peakday2Repository")
	Peakday2Repository peakdayRepository;
	
	/** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertyService;
	
    @Resource(name="scheduleDAO")
    ScheduleDAO scheduleDAO;
	// 달력 성수기 목록 가지고 오기
	public List<Peakday2VO> getCalenderPeakdayList(String startDt,String endDt) throws Exception{		
				
		return peakdayRepository.selectCalenderPeakday(startDt, endDt);		
		
	}
	
	// 달력 휴일 목록 가지고 오기
	public List<Holiday2VO> getCalenderHolidayList(String startDt,String endDt) throws Exception{
		return holidayRepository.selectCalenderHoliday(startDt, endDt);
	}
	
	// 휴일 목록 가지고 오기
	public List<Holiday2VO> getHolidayList(Holiday2VO vo) throws Exception{
		
		String searchYear = vo.getSearchYear();
		Specifications<Content> spec = Specifications.where(Holiday2SearchSpec.stdYearEquals(searchYear));
		
		return holidayRepository.findAll(spec);
	}
	
	// 휴일 상세 데이터 가지고 오기
	public Holiday2VO getHolidayDtl(Holiday2VO vo) throws Exception{
		int seq = vo.getSeq();
		return holidayRepository.findOneBySeq(seq);
	}
	
	// 휴일 저장
	public String saveHoliday(Holiday2VO vo) throws Exception{
		
		String ret = "N";
		
		// 날짜 체크
		int seq = vo.getSeq();
		Date startDt = vo.getStartDt();
		Date endDt   = vo.getEndDt();
		
		// 수정시 해당 시퀀스 제외
		Specifications<Content> spec = Specifications.where(Holiday2SearchSpec.seqNotEqual(seq));
		
		// 시작일자
		spec = spec.and(Holiday2SearchSpec.startDtLess(endDt));
		
		// 종료일자
		spec = spec.and(Holiday2SearchSpec.endDtGreater(startDt));
		
		int dupCnt = holidayRepository.count(spec);
		
		if(dupCnt == 0) {
			ret = "Y";
		}
		
		
		// 날짜 체크 성공하면 저장
		if(ret.equals("Y")) {
			holidayRepository.saveAndFlush(vo);
		}
		return ret;
	}
	
	// 휴일 삭제
	public void removeHoliday(Holiday2VO vo) throws Exception{
		holidayRepository.delete(vo);
	}
	
	// 성수기 목록 가지고 오기
	public List<Peakday2VO> getPeakdayList(Peakday2VO vo) throws Exception{
		
		String searchYear = vo.getSearchYear();
		Specifications<Content> spec = Specifications.where(Peakday2SearchSpec.stdYearEquals(searchYear));
		
		return peakdayRepository.findAll(spec);
	}
	
	// 성수기 상세 데이터 가지고 오기
	public Peakday2VO getPeakdayDtl(Peakday2VO vo) throws Exception{
		int seq = vo.getSeq();
		return peakdayRepository.findOneBySeq(seq);
	}
	
	// 성수기 저장
	public String savePeakday(Peakday2VO vo) throws Exception{
		
		String ret = "N";
		
		// 날짜 체크
		int seq = vo.getSeq();
		Date startDt = vo.getStartDt();
		Date endDt   = vo.getEndDt();
		
		// 수정시 해당 시퀀스 제외
		Specifications<Content> spec = Specifications.where(Peakday2SearchSpec.seqNotEqual(seq));
		
		// 시작일자
		spec = spec.and(Peakday2SearchSpec.startDtLess(endDt));
		
		// 종료일자
		spec = spec.and(Peakday2SearchSpec.endDtGreater(startDt));
		
		int dupCnt = peakdayRepository.count(spec);
		
		if(dupCnt == 0) {
			ret = "Y";
		}
		
		
		// 날짜 체크 성공하면 저장
		if(ret.equals("Y")) {
			peakdayRepository.saveAndFlush(vo);
		}
		return ret;
	}
	
	// 성수기 삭제
	public void removePeakday(Peakday2VO vo) throws Exception{
		peakdayRepository.delete(vo);
	}
	
	// 공공데이터 불러오기 API
	public String getHolidayDataApi(Holiday2VO vo) throws Exception{
		
		
		String ret = "";		
		String serviceUrl = propertyService.getString("holidayDataUrl");
		String serviceKey = propertyService.getString("holidayDataKey");
		
		String solYear = vo.getSearchYear();		
		
		String restUrl = serviceUrl + "/getRestDeInfo?_type=json&numOfRows=50&solYear=" + solYear + "&serviceKey=" + serviceKey;
		//System.out.println(restUrl);
		
		URL url = new URL(restUrl);
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
        //System.out.println("Response code: " + conn.getResponseCode());
        
        BufferedReader rd;
        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();
        conn.disconnect();
        //System.out.println("-----------------------------------------------------------");
        //System.out.println(sb.toString());
        //System.out.println("-----------------------------------------------------------");
        
        String retJson = sb.toString();
        ObjectMapper om = new ObjectMapper();
        
        int registCnt = 0;
        
        Map<String, Object> map = om.readValue(retJson, new TypeReference<Map<String, Object>>()  {});
        Map<String, Object> resMap =  (Map<String,Object>)map.get("response");
        Map<String, Object> bodyMap =  (Map<String,Object>)resMap.get("body");
        
        if(!bodyMap.get("items").equals("")){
	        Map<String, Object> itemMap =  (Map<String,Object>)bodyMap.get("items");
	        List<Map<String, Object>> itemList = (List<Map<String, Object>>)itemMap.get("item"); 
	        
	        for(int i = 0;i < itemList.size();i++) {
	        	// {dateKind=01, dateName=설날, isHoliday=Y, locdate=20200125, seq=1}
	        	Map<String, Object> item =  (Map<String,Object>)itemList.get(i);
	        	
	        	
	        	String dateName  = item.get("dateName").toString();
	        	String locDate   = item.get("locdate").toString();
	        	String isHoliday = item.get("isHoliday").toString();
	        	
	        	System.out.println(locDate.substring(0,4) + "-" + locDate.substring(4,6) + "-" + locDate.substring(6,8));
	        	
	        	int searchYear = Integer.parseInt(locDate.substring(0,4));
				int searchMonth = Integer.parseInt(locDate.substring(4, 6)) - 1;
				int searchDay = Integer.parseInt(locDate.substring(6,8));
				Calendar cal = Calendar.getInstance();			
				cal.set(searchYear, searchMonth, searchDay, 0,0,0);
				cal.set(Calendar.MILLISECOND,0);			
				Date dt = cal.getTime();
	        	        	
	        	if(isHoliday.equals("Y")) {	 
	        		vo.setSeq(0);
		        	vo.setTitle(dateName);
		        	vo.setStdYear(solYear);
		        	vo.setStartDt(dt);
		        	vo.setEndDt(dt);
		        	String result = this.saveHoliday(vo);
		        	if(result.equals("Y")) {
		        		registCnt++;
		        	}
	        	}	 
	        }
        }
        
        ret = Integer.toString(registCnt);
		
		return ret;
	}
	
	@Override
	public ScheduleVO getScheduleDtl(ScheduleVO vo) throws Exception {
		// TODO Auto-generated method stub
		
		ScheduleVO Retvo = scheduleDAO.getScheduleDtl(vo);
		System.out.println("pshpsh ::::: " + Retvo.toString());
		return Retvo;
	}
	
	//일정 등록하기
	@Override
	public String insertSchedule(ScheduleVO vo) throws Exception {
		// TODO Auto-generated method stub
		String ret = "N";
		
		int value = scheduleDAO.insertSchedule(vo);
		if (value == 1) ret = "Y";
		return ret;
	}
	
	//일정 수정하기
	@Override
	public String updateSchedule(ScheduleVO vo) throws Exception {
		// TODO Auto-generated method stub
		String ret = "N";
		
		int value = scheduleDAO.updateSchedule(vo);
		if (value == 1) ret = "Y";
		return ret;
	}
	
	//일정 리스트 불러오기(달력)
	@Override
	public List<ScheduleVO> getCalenderScheduleList(String startDt, String endDt) throws Exception {
		// TODO Auto-generated method stub
		HashMap<String, String> schMap = new HashMap<>();
		schMap.put("startDt", startDt);
		schMap.put("endDt", endDt);
		return scheduleDAO.selectSchedule(schMap);
	}
	
	//일정관리 페이지(수정, 삭제)
	@Override
	public List<ScheduleVO> getScheduleList() throws Exception {
		// TODO Auto-generated method stub
		List<ScheduleVO> list = scheduleDAO.selectScheduleList();
		for (int i = 0; i < list.size(); i++) {
			System.out.println("pshpsh ::::: " + list.get(i));
		}
		return list;
	}

	@Override
	public void removeSchedule(ScheduleVO vo) throws Exception {
		// TODO Auto-generated method stub
		scheduleDAO.deleteSchedule(vo);
	}
}