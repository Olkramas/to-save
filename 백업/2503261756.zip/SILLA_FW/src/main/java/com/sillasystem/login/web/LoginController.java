package com.sillasystem.login.web;

import egovframework.com.cmm.EgovComponentChecker;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.config.EgovLoginConfig;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.uat.uia.service.EgovLoginService;
import egovframework.com.utl.sim.service.EgovFileScrty;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sillasystem.member.service.EgovUserManageService;
import com.sillasystem.member.service.UserManageVO;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.Map;

@Controller
public class LoginController {
   
	/** EgovLoginService */
    @Resource(name = "loginService")
    private EgovLoginService loginService;

    /** EgovMessageSource */
    @Resource(name = "egovMessageSource")
    private EgovMessageSource egovMessageSource;

    /** EgovLoginConfig */
    @Resource(name = "egovLoginConfig")
    private EgovLoginConfig egovLoginConfig;
    
    /** userManageService */
	@Resource(name = "userManageService")
	private EgovUserManageService userManageService;

    @RequestMapping(value = "/login/login.do", method = RequestMethod.GET)
    public String login(@ModelAttribute("loginVO") LoginVO loginVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) {

        if (EgovComponentChecker.hasComponent("mberManageService")) {
            model.addAttribute("useMemberManage", "true");
        }

        //권한체크시 에러 페이지 이동
        String auth_error =  request.getParameter("auth_error") == null ? "" : (String)request.getParameter("auth_error");
        if(auth_error != null && auth_error.equals("1")){
            return "com/sillasystem/error/accessDenied";
        }

        String message = (String)request.getParameter("message");
        if (message!=null) model.addAttribute("message", message);

        return "com/sillasystem/login/login";
    }
    
    //확인 해보고 안되면 바로 삭제하기 
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String testPage() {
    	return "com/sillasystem/login/testCheck";
    }

    @RequestMapping(value = "/login/login.do", method = RequestMethod.POST)
    public String actionLogin(@ModelAttribute("loginVO") LoginVO loginVO, HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
        // 1. 로그인인증제한 활성화시
        if( egovLoginConfig.isLock()){
            Map<?,?> mapLockUserInfo = (EgovMap)loginService.selectLoginIncorrect(loginVO);
            if(mapLockUserInfo != null){
                //2.1 로그인인증제한 처리
                String sLoginIncorrectCode = loginService.processLoginIncorrect(loginVO, mapLockUserInfo);
                if(!sLoginIncorrectCode.equals("E")){
                    if(sLoginIncorrectCode.equals("L")){
                        model.addAttribute("message", egovMessageSource.getMessageArgs("fail.common.loginIncorrect", new Object[] {egovLoginConfig.getLockCount(),request.getLocale()}));
                    }else if(sLoginIncorrectCode.equals("C")){
                        model.addAttribute("message", egovMessageSource.getMessage("fail.common.login",request.getLocale()));
                    }
                    return "com/sillasystem/login/login";
                }
            }else{
                model.addAttribute("message", egovMessageSource.getMessage("fail.common.login",request.getLocale()));
                return "com/sillasystem/login/login";
            }
        }

        // 2. 로그인 처리
        LoginVO resultVO = loginService.actionLogin(loginVO);

        // 3. 일반 로그인 처리
        if (resultVO != null && resultVO.getId() != null && !resultVO.getId().equals("")) {

            // 3-1. 로그인 정보를 세션에 저장
            request.getSession().setAttribute("loginVO", resultVO);
            // 2019.10.01 로그인 인증세션 추가
            request.getSession().setAttribute("accessUser", resultVO.getUserSe().concat(resultVO.getId()));

            return "redirect:/index.do";

        } else {
            model.addAttribute("message", egovMessageSource.getMessage("fail.common.login",request.getLocale()));
            return "com/sillasystem/login/login";
        }
    }
    
    
    /**
	 * 로그아웃 처리
	 * @param request
	 * @param response
	 * @param session
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/login/logout.do")
	public String logout(HttpServletRequest request,HttpServletResponse response,HttpSession session,ModelMap map) throws Exception{
		session.invalidate();
		return "redirect:/login/login.do";
	}
	
	/**
	 * 관리자 비번변경
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/login/changeAdminInfoPop.do")
	public String changeAdminInfo(HttpServletRequest request,HttpServletResponse response){
		
		return "login/changeAdminInfoPop";
		
	}
	
	/**
	 * 관리자 비번변경처리
	 * @param request
	 * @param response
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/login/changeAdminInfoProcAjax.do")
	@ResponseBody
	public String changeAdminInfoProcAjax(HttpServletRequest request,HttpServletResponse response) throws Exception{
		String ret = "";
		String oldPassword = request.getParameter("oldPassword");
		String newPassword = request.getParameter("newPassword");
		
		LoginVO vo = new LoginVO();
		vo.setPassword(oldPassword);
		
		LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		
		UserManageVO userVo = new UserManageVO();
		userVo.setUniqId(user.getUniqId());
		userVo.setEmplyrId(user.getId());
		System.out.println(userVo.getEmplyrId());
		UserManageVO resultVo = userManageService.selectPassword(userVo);
		String encryptPass = EgovFileScrty.encryptPassword(oldPassword, userVo.getEmplyrId());
		
		boolean isCorrectPassword = false;
		if (encryptPass.equals(resultVo.getPassword())) {			
			isCorrectPassword = true;
			ret  = "Y";
		} else {
			isCorrectPassword = false;
			ret  = "N";			
		}
		
		if (isCorrectPassword) {
			userVo.setPassword(EgovFileScrty.encryptPassword(newPassword, userVo.getEmplyrId()));
			System.out.println(userVo.getPassword());
			userManageService.updatePassword(userVo);
			ret = "Y";
		}		
		
		return ret;
		
	}
    
}
