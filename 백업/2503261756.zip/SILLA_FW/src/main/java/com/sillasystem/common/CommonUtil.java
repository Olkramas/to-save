package com.sillasystem.common;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import egovframework.com.cmm.service.FileVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import net.coobird.thumbnailator.Thumbnails;

@Component
public class CommonUtil {

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;
	
	// 페이징 클래스 변환
	public PaginationInfo getPaging(Page<?> page) {
				
		PaginationInfo paginationInfo = new PaginationInfo();
		
		paginationInfo.setCurrentPageNo(page.getNumber()+1);
		paginationInfo.setRecordCountPerPage(propertiesService.getInt("pageUnit"));
		paginationInfo.setPageSize(propertiesService.getInt("pageSize"));
		paginationInfo.setTotalRecordCount((int)page.getTotalElements());
		
		return paginationInfo;
	}
	
	public void createThumbnailByFileVO(List<FileVO> fileList) throws Exception{
		
		for(int i = 0;i < fileList.size();i++) {
			String filePath = fileList.get(i).getFileStreCours();
			String fileName = fileList.get(i).getStreFileNm();				
			createThumbnail(filePath,fileName);
		}
		
	}
	
	// 썸네일 변환
	public void createThumbnail(String filePath,String fileName) throws Exception{
		int index = fileName.lastIndexOf(".");        
        String fileExt = fileName.substring(index + 1).toUpperCase();
        
        // JPG , GIF만 썸네일 처리
		if(fileExt.equals("JPG") || fileExt.equals("GIF")) {
			String fileFullPath = filePath + fileName;
			String thumbFullPath = filePath + "T_" + fileName;		
			Thumbnails.of(new File(fileFullPath)).scale(0.5).toFile(new File(thumbFullPath));
		}
		
	}
}
