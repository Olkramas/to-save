/**
 * 
 * 팝업관리 Service Impl
 * 
 * @version v1.0
 * @since 2019. 05. 08
 * @author pyonkm
 *
 */
package com.sillasystem.popup.service.impl;



import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sillasystem.popup.repository.PopupRepository;
import com.sillasystem.popup.repository.SearchSpec;
import com.sillasystem.popup.service.PopupService;
import com.sillasystem.popup.service.PopupVO;


@Service("popupService")
public class PopupServiceImpl implements PopupService {
	
	@Resource(name="popupRepository")
	PopupRepository popupRepository;
	
	// 팝업 리스트
	public Page<PopupVO> getPopupList(PopupVO vo) throws Exception{
		
		// 페이징 셋팅
		int pageNum = vo.getPageIndex() - 1;
		PageRequest page = new PageRequest(pageNum , 10, new Sort(Direction.DESC,"seq"));
	
		// 삭제한거는 안나오게 필터링
		Specifications<Content> spec = Specifications.where(SearchSpec.delYnEquals("N"));
		
		// 제목 검색
		if(vo.getSearchTxt() != null && !vo.getSearchTxt().equals("")) {
			spec = spec.and(SearchSpec.titleLike(vo.getSearchTxt()));
		}
				
		// 시작날짜 검색
		if(vo.getSearchStartDt() != null && !vo.getSearchStartDt().equals("")) {
			// String > Date 변환						
			String[] tmpStr = vo.getSearchStartDt().split("-");
			int searchYear = Integer.parseInt(tmpStr[0]);
			int searchMonth = Integer.parseInt(tmpStr[1]) - 1;
			int searchDay = Integer.parseInt(tmpStr[2]);
			Calendar cal = Calendar.getInstance();			
			cal.set(searchYear, searchMonth, searchDay, 0,0,0);
			cal.set(Calendar.MILLISECOND,0);			
			Date dt = cal.getTime();
			
			// 검색 조건 추가
			spec = spec.and(SearchSpec.regDtGreater(dt));
		}
		
		// 종료날짜 검색
		if(vo.getSearchEndDt() != null && !vo.getSearchEndDt().equals("")) {			
			// String > Date 변환						
			String[] tmpStr = vo.getSearchEndDt().split("-");
			int searchYear = Integer.parseInt(tmpStr[0]);
			int searchMonth = Integer.parseInt(tmpStr[1]) - 1;
			int searchDay = Integer.parseInt(tmpStr[2]);
			Calendar cal = Calendar.getInstance();			
			cal.set(searchYear, searchMonth, searchDay, 23,59,59);
			cal.set(Calendar.MILLISECOND,0);			
			Date dt = cal.getTime();
			
			// 검색조건 추가
			spec = spec.and(SearchSpec.regDtLess(dt));
		}
		
		
		// JPA 호출
		Page<PopupVO> itemList = (Page<PopupVO>) popupRepository.findAll(spec,page);
		return itemList;
		
	}
	
	// 팝업 상세보기
	public PopupVO selectPopupDetail(PopupVO vo) throws Exception{
		return popupRepository.findOneBySeq(vo.getSeq());
	}
	
	// 팝업 등록/수정
	public void insertPopup(PopupVO vo) throws Exception{		
		popupRepository.saveAndFlush(vo);
	}
	
	
	// 팝업 삭제
	public void removePopup(PopupVO vo) throws Exception{
		
		int seq = vo.getSeq();
		String updId = vo.getUpdId();		
		popupRepository.updateDelYn(seq,updId);
		
	}
	
	// 팝업 선택 삭제
	public void removeChkPopup(PopupVO vo) throws Exception{
		
		String[] chkSeq = vo.getChkDel().split(",");
		String updId = vo.getUpdId();		
		for(int i = 0;i < chkSeq.length;i++) {
			int seq = Integer.parseInt(chkSeq[i]);
			System.out.println(seq);
			popupRepository.updateDelYn(seq,updId);			
		}
		
	}
}
