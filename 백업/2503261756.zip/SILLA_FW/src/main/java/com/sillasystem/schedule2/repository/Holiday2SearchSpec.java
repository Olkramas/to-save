/**
 * 
 * 휴일 관리 JPA 검색 SPEC
 * 
 * @version v1.0
 * @since 2019. 05. 12
 * @author pyonkm
 *
 */
package com.sillasystem.schedule2.repository;

import java.util.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.jpa.domain.Specification;

public class Holiday2SearchSpec {
	
	// 연도 검색
	public static Specification<Content> stdYearEquals(String keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("stdYear"),keyword);
            		}
		};
	}
	
	// 중복 체크용 자기 시퀀스 제외
	public static Specification<Content> seqNotEqual(int keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.notEqual(root.get("seq"),keyword);
            }
		};
	}
	
	// 시작날짜 보다 크다
	public static Specification<Content> startDtGreater(Date keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.greaterThanOrEqualTo(root.get("startDt"),keyword);
            }
		};
	}
	
	// 시작날짜 보다 작다
	public static Specification<Content> startDtLess(Date keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.lessThanOrEqualTo(root.get("startDt"),keyword);
            }
		};
	}
	
	// 종료날짜 보다 크다
	public static Specification<Content> endDtGreater(Date keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.greaterThanOrEqualTo(root.get("endDt"),keyword);
            }
		};
	}
	
	// 종료날짜 보다 작다
	public static Specification<Content> endDtLess(Date keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.lessThanOrEqualTo(root.get("endDt"),keyword);
            }
		};
	}
	
}
