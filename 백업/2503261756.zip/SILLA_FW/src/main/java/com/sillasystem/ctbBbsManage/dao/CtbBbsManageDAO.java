package com.sillasystem.ctbBbsManage.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("ctbBbsManageDAO")
public class CtbBbsManageDAO extends EgovComAbstractDAO {
	
	//ctbBbsManageDAO = 매퍼의 namespace 
	//.이후가 매퍼의 id
	
	//게시판 목록
    public List<EgovMap> selectbbsManageList (Map<String,Object> paramMap) throws Exception{
        return (List<EgovMap>) list("ctbBbsManageDAO.selectbbsManageList", paramMap);
    }
    
    //게시판 totalcnt
    public int bbsManageListCnt (Map<String,Object> paramMap) throws Exception {
        return (Integer)selectOne("ctbBbsManageDAO.bbsManageListCnt", paramMap);
    }
    
    //게시판 등록
    public void insertBbsMast (Map<String,Object> paramMap){
        insert("ctbBbsManageDAO.insertBbsMast",paramMap);
    }
    
    //게시판 관리자 등록
    public void insertBbsManager (Map<String,Object> paramMap){
        insert("ctbBbsManageDAO.insertBbsManager",paramMap);
    }
    
    //게시판 id 중복 체크
    public int duplicateCheck (Map<String,Object> paramMap){
        return (Integer) selectOne("ctbBbsManageDAO.duplicateCheck", paramMap);
    }
    
    //게시판 수정
    public void updateBbsMast (Map<String,Object> paramMap){
        update("ctbBbsManageDAO.updateBbsMast", paramMap);
    }

    public void deleteBbsManager (Map<String,Object> paramMap){
        delete("ctbBbsManageDAO.deleteBbsManager", paramMap);
    }
    
    //게시판 정보 select
    public EgovMap selectBbsMastView(Map<String,Object> paramMap){
        return selectOne("ctbBbsManageDAO.selectBbsMastView", paramMap);
    }
    
    public List<EgovMap> selectBbsMastManagerList(Map<String,Object> paramMap){
        return (List<EgovMap>)list("ctbBbsManageDAO.selectBbsMastManagerList", paramMap);
    }
    
    //게시판 삭제
    public void deleteBbsMast (Map<String,Object> paramMap){
        update("ctbBbsManageDAO.deleteBbsMast", paramMap);
    }
    
    //공격적인 단어 db에서 select
    public EgovMap selectOffenseWordsMap () {
        return selectOne("bbsManageDAO.selectOffenseWordsMap");
    }
    
    //권한체크
    public EgovMap selectBbsAuth(Map<String,Object> paramMap) throws Exception{
    	return selectOne("ctbBbsManageDAO.selectBbsAuth",paramMap);
    }
}
