package com.sillasystem.menuManage.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.menuManage.service.MenuManageVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;

@Repository("newMenuManageDAO")
public class MenuManageDAO  extends EgovComAbstractDAO {
	
	public List<?> selectMenuList(MenuManageVO vo) throws SQLException{
		return selectList("menuManageDAO.selectMenuList",vo);
	}
	
	public MenuManageVO selectMenuDetail(MenuManageVO vo) throws SQLException{
		return (MenuManageVO)selectOne("menuManageDAO.selectMenuDetail",vo);
	}
	
	public String selectMenuSeq(MenuManageVO vo) throws SQLException{
		return (String)selectOne("menuManageDAO.selectMenuSeq",vo);
	}
		
	public int selectChildrenMenuCnt(MenuManageVO vo) throws SQLException{
		return (Integer)selectOne("menuManageDAO.selectChildrenMenuCnt",vo);
	}
	
	public List<?> selectAuthor(MenuManageVO vo) throws SQLException{
		return selectList("menuManageDAO.selectAuthor",vo);
	}
	
	public void insertMenu(MenuManageVO vo) throws SQLException{
		insert("menuManageDAO.insertMenu",vo);
	}
	
	public void insertMenuAuth(MenuManageVO vo) throws SQLException{
		insert("menuManageDAO.insertMenuAuth",vo);
	}
	
	public void updateMenu(MenuManageVO vo) throws SQLException{
		update("menuManageDAO.updateMenu",vo);
	}
	
	public void deleteMenu(MenuManageVO vo) throws SQLException{
		delete("menuManageDAO.deleteMenu",vo);
	}
	
	public void deleteMenuAuth(MenuManageVO vo) throws SQLException{
		delete("menuManageDAO.deleteMenuAuth",vo);
	}

}
