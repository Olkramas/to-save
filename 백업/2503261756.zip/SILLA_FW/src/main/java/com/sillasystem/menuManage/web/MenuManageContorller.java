package com.sillasystem.menuManage.web;

import java.util.List;

import javax.annotation.Resource;

import egovframework.com.cmm.util.EgovDoubleSubmitHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sillasystem.menuManage.service.MenuManageService;
import com.sillasystem.menuManage.service.MenuManageVO;

import egovframework.com.cmm.ComDefaultVO;
import egovframework.com.sym.prm.service.EgovProgrmManageService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


@Controller
public class MenuManageContorller {
	
	/** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
	// 신규 메뉴 관리
	@Resource(name = "newMenuManageService")
    private MenuManageService menuManageService;
	
	/** 프로그램 관리 */
	@Resource(name = "progrmManageService")
    private EgovProgrmManageService progrmManageService;
	
	@RequestMapping(value = "/menuManage/menuList.do")
	public String menuList(@ModelAttribute("searchVO") MenuManageVO searchVO, ModelMap model) throws Exception {
		
		return "com/sillasystem/menuManage/menuList";
	}
	
	@RequestMapping(value = "/menuManage/getmenuDataAjax.do")
	public ModelAndView getmenuData(@ModelAttribute("searchVO") MenuManageVO searchVO, ModelMap model) throws Exception {
		List<?> menuList = menuManageService.selectMenuList(searchVO);
		
		ModelAndView mav = new ModelAndView("jsonView");
    	mav.addObject("menuList", menuList);
    	return mav;
		
		
	}
	
	@RequestMapping(value = "/menuManage/menuFormAjax.do")
	public String menuForm(@ModelAttribute("searchVO") MenuManageVO searchVO, ModelMap model) throws Exception {
		String mode = "REG";
		
		if(searchVO.getMenuNo() != null && !searchVO.getMenuNo().equals("")) {
			MenuManageVO retVo = menuManageService.selectMenuDetail(searchVO);
			model.addAttribute("result",retVo);
			mode = "MOD";
		}
		
		List<?> authorList = menuManageService.selectAuthor(searchVO);
		
		model.addAttribute("authorList",authorList);
		model.addAttribute("mode",mode);
		System.out.println("작동");
		System.out.println(authorList);
		System.out.println(mode);
		
		return "com/sillasystem/menuManage/menuFormAjax";
	}
	
	@RequestMapping(value = "/menuManage/selectProgramListAjax.do")
	public String selectProgramList(@ModelAttribute("searchVO") ComDefaultVO searchVO, ModelMap model) throws Exception {
		
		// 내역 조회
    	searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	searchVO.setPageSize(propertiesService.getInt("pageSize"));

    	/** pageing */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

        List<?> list_progrmmanage = progrmManageService.selectProgrmList(searchVO);
        model.addAttribute("resultList", list_progrmmanage);

        int totCnt = progrmManageService.selectProgrmListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
        model.addAttribute("paginationInfo", paginationInfo);
		
			
		return "com/sillasystem/menuManage/selectProgramListAjax";
	}
	
	
	@RequestMapping(value = "/menuManage/selectMenuAjax.do")
	public String selectMenu(ModelMap model) throws Exception {
					
		return "com/sillasystem/menuManage/selectMenuAjax";
	}
	
	@ResponseBody
	@RequestMapping(value = "/menuManage/menuProcessAjax.do")
	public String menuProcess(MenuManageVO vo,ModelMap model) throws Exception {
		
		String retStr = "";
		String mode = vo.getMode();
				
		if(mode.equals("REG")){
			// 등록 모드			

			//중복서브밋 방지
			if (EgovDoubleSubmitHelper.checkAndSaveToken()) {
				// 메뉴 번호 따기
				String menuNo = menuManageService.selectMenuSeq(vo);
				vo.setMenuNo(menuNo);

				// 메뉴 등록
				menuManageService.insertMenu(vo);

				// 메뉴 접근권한 등록
				if(vo.getArrAuthorCode() != null) {
					String[] arrAuthorCode = vo.getArrAuthorCode();
					for(int i = 0;i < arrAuthorCode.length;i++) {
						vo.setAuthorCode(arrAuthorCode[i]);
						menuManageService.insertMenuAuth(vo);
					}
				}

			}

			retStr = "Y";

		}else if(mode.equals("MOD")) {
			// 수정모드

			//중복서브밋 방지
			if (EgovDoubleSubmitHelper.checkAndSaveToken()) {
				// 메뉴 수정
				menuManageService.updateMenu(vo);

				// 기존 메뉴 접근 권한 삭제
				menuManageService.deleteMenuAuth(vo);

				// 메뉴 접근 권한 등록
				if(vo.getArrAuthorCode() != null) {
					String[] arrAuthorCode = vo.getArrAuthorCode();
					for(int i = 0;i < arrAuthorCode.length;i++) {
						vo.setAuthorCode(arrAuthorCode[i]);
						menuManageService.insertMenuAuth(vo);
					}
				}

			}

			retStr = "Y";

		}else if(mode.equals("DEL")) {
			// 삭제모드			
			
			// 삭제전 하위메뉴 체크해서 있으면 삭제 안됨
			int subCnt = menuManageService.selectChildrenMenuCnt(vo);
			if(subCnt > 0) {
				retStr = "SUB";
			}else {
				
				// 메뉴 접근 권한 삭제
				menuManageService.deleteMenuAuth(vo);
				// 메뉴 삭제
				menuManageService.deleteMenu(vo);
				retStr = "Y";
			}			
		}
		
		
		return retStr;
	}
		
}
