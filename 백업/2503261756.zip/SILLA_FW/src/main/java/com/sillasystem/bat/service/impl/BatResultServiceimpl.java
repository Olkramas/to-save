package com.sillasystem.bat.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sillasystem.bat.service.BatResultService;
import com.sillasystem.bat.vo.BatResultVO;

import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("batResultService")
public class BatResultServiceimpl extends EgovAbstractServiceImpl implements BatResultService{
	/**
	 * 배치결과DAO
	 */
	@Resource(name = "batResultDao")
	private BatResultDao dao;

	/**
	 * 배치결과을 삭제한다.
	 * @param batchResult    삭제대상 배치결과model
	 * @exception Exception Exception
	 */
	@Override
	public void deleteBatchResult(BatResultVO batchResult) throws Exception {
		dao.deleteBatchResult(batchResult);
	}

	/**
	 * 배치결과을 상세조회 한다.
	 * @return 배치결과정보
	 *
	 * @param batchResult 조회대상 배치결과model
	 * @exception Exception Exception
	 */
	@Override
	public BatResultVO selectBatchResult(BatResultVO batchResult) throws Exception {
		return dao.selectBatchResult(batchResult);
	}

	/**
	 * 배치결과의 목록을 조회 한다.
	 * @return 배치결과목록
	 *
	 * @param searchVO 	조회정보가 담긴 VO
	 * @exception Exception Exception
	 */
	@Override
	public List<?> selectBatchResultList(BatResultVO searchVO) throws Exception {
		List<?> result = dao.selectBatchResultList(searchVO);
		return result;
	}

	/**
	 * 배치스케줄 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 * @exception Exception Exception
	 */
	@Override
	public int selectBatchResultListCnt(BatResultVO searchVO) throws Exception {
		int cnt = dao.selectBatchResultListCnt(searchVO);
		return cnt;
	}
}
