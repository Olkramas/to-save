package com.sillasystem.bat.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sillasystem.bat.vo.BatSchdulDfk;
import com.sillasystem.bat.vo.BatScheduleVO;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
@Repository("batSchdulDao")
public class BatSchdulDao extends EgovComAbstractDAO{
	/**
	 * 배치스케줄을 삭제한다.
	 *
	 * @param batchSchdul    삭제할 배치스케줄 VO
	 * @exception Exception Exception
	 */
	public void deleteBatchSchdul(BatScheduleVO batchSchdul)
	  throws Exception{
		// slave 테이블 삭제
		delete("batSchdulDao.deleteBatchSchdulDfk", batchSchdul.getBatchSchdulId());
		// master 테이블 삭제
		delete("batSchdulDao.deleteBatchSchdul", batchSchdul);
	}

	/**
	 * 배치스케줄을 등록한다.
	 *
	 * @param batchSchdul 저장할 배치스케줄 VO
	 * @exception Exception Exception
	 */
	public void insertBatchSchdul(BatScheduleVO batchSchdul)
	  throws Exception{
		// master 테이블 인서트
		insert("batSchdulDao.insertBatchSchdul", batchSchdul);
		// slave 테이블 인서트
		if (batchSchdul.getExecutSchdulDfkSes() != null && batchSchdul.getExecutSchdulDfkSes().length != 0) {
			String batchSchdulId = batchSchdul.getBatchSchdulId();
			String [] dfkSes = batchSchdul.getExecutSchdulDfkSes();
			for (int i = 0; i < dfkSes.length; i++) {
				BatSchdulDfk batchSchdulDfk = new BatSchdulDfk();
				batchSchdulDfk.setBatchSchdulId(batchSchdulId);
				batchSchdulDfk.setExecutSchdulDfkSe(dfkSes[i]);
				insert("batSchdulDao.insertBatchSchdulDfk", batchSchdulDfk);
			}
		}
	}

	/**
	 * 배치스케줄정보를 상세조회 한다.
	 * @return 배치스케줄정보
	 *
	 * @param batchSchdul    조회할 KEY가 있는 배치스케줄 VO
	 * @exception Exception Exception
	 */
	@SuppressWarnings("unchecked")
	public BatScheduleVO selectBatchSchdul(BatScheduleVO batchSchdul)
	  throws Exception{
		BatScheduleVO result = (BatScheduleVO)selectOne("batSchdulDao.selectBatchSchdul", batchSchdul);
		// 스케줄요일정보를 가져온다.
		List<BatSchdulDfk> dfkSeList = selectList("batSchdulDao.selectBatchSchdulDfkList", result.getBatchSchdulId());
		String [] dfkSes = new String [dfkSeList.size()];
		for (int j = 0; j < dfkSeList.size(); j++) {
			dfkSes[j] = dfkSeList.get(j).getExecutSchdulDfkSe();
		}
		result.setExecutSchdulDfkSes(dfkSes);
		// 화면표시용 실행스케줄 속성을 만든다.
		result.makeExecutSchdul(dfkSeList);

		return result ;
	}

	/**
	 * 배치스케줄정보목록을  조회한다.
	 * @return 배치스케줄목록
	 *
	 * @param searchVO    조회조건이 저장된 VO
	 * @exception Exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<?> selectBatchSchdulList(BatScheduleVO searchVO)
	  throws Exception{
		List<?> resultList = selectList("batSchdulDao.selectBatchSchdulList", searchVO);

		for (int i = 0; i < resultList.size(); i++) {
			BatScheduleVO result = (BatScheduleVO) resultList.get(i);
			// 스케줄요일정보를 가져온다.
			List<BatSchdulDfk> dfkSeList = selectList("batSchdulDao.selectBatchSchdulDfkList", result.getBatchSchdulId());
			String [] dfkSes = new String [dfkSeList.size()];
			for (int j = 0; j < dfkSeList.size(); j++) {
				dfkSes[j] = dfkSeList.get(j).getExecutSchdulDfkSe();
			}
			result.setExecutSchdulDfkSes(dfkSes);
			// 화면표시용 실행스케줄 속성을 만든다.
			result.makeExecutSchdul(dfkSeList);
		}
		return resultList;
	}

	/**
	 * 배치스케줄 목록 전체 건수를(을) 조회한다.
	 * @return 목록건수
	 *
	 * @param searchVO    조회할 정보가 담긴 VO
	 * @exception Exception Exception
	 */
	public int selectBatchSchdulListCnt(BatScheduleVO searchVO)
	  throws Exception{
		return (Integer)selectOne("batSchdulDao.selectBatchSchdulListCnt", searchVO);
	}

	/**
	 * 배치스케줄정보를 수정한다.
	 *
	 * @param batchSchdul    수정대상 배치스케줄 VO
	 * @exception Exception Exception
	 */
	public void updateBatchSchdul(BatScheduleVO batchSchdul)
	  throws Exception{
		update("batSchdulDao.updateBatchSchdul", batchSchdul);
		// slave 테이블 삭제
		delete("batSchdulDao.deleteBatchSchdulDfk", batchSchdul.getBatchSchdulId());
		// slave 테이블 인서트
		if (batchSchdul.getExecutSchdulDfkSes() != null && batchSchdul.getExecutSchdulDfkSes().length != 0) {
			String batchSchdulId = batchSchdul.getBatchSchdulId();
			String [] dfkSes = batchSchdul.getExecutSchdulDfkSes();
			for (int i = 0; i < dfkSes.length; i++) {
				BatSchdulDfk batchSchdulDfk = new BatSchdulDfk();
				batchSchdulDfk.setBatchSchdulId(batchSchdulId);
				batchSchdulDfk.setExecutSchdulDfkSe(dfkSes[i]);
				insert("batSchdulDao.insertBatchSchdulDfk", batchSchdulDfk);
			}
		}
	}

}
