package com.sillasystem.menuManage.service;

import java.sql.SQLException;
import java.util.List;

public interface MenuManageService {
	
	public List<?> selectMenuList(MenuManageVO vo) throws SQLException;
		
	public MenuManageVO selectMenuDetail(MenuManageVO vo) throws SQLException;
	
	public int selectChildrenMenuCnt(MenuManageVO vo) throws SQLException;
	
	public String selectMenuSeq(MenuManageVO vo) throws SQLException;
	
	public List<?> selectAuthor(MenuManageVO vo) throws SQLException;
	
	public void insertMenu(MenuManageVO vo) throws SQLException;
	
	public void insertMenuAuth(MenuManageVO vo) throws SQLException;
	
	public void updateMenu(MenuManageVO vo) throws SQLException;
	
	public void deleteMenu(MenuManageVO vo) throws SQLException;
	
	public void deleteMenuAuth(MenuManageVO vo) throws SQLException;
	
}
