/**
 * 
 * 관련사이트 관리 Service Impl
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.relateSite.service.impl;

import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;

import com.sillasystem.relateSite.repository.RelateSiteRepository;
import com.sillasystem.relateSite.repository.SearchSpec;
import com.sillasystem.relateSite.service.RelateSiteService;
import com.sillasystem.relateSite.service.RelateSiteVO;

@Service("relateSiteService")
public class RelateSiteServiceImpl implements RelateSiteService {
	

	@Resource(name="relateSiteRepository")
	RelateSiteRepository relateSiteRepository;
	
	// 관련사이트 리스트
	public Page<RelateSiteVO> getRelateSiteList(RelateSiteVO vo) throws Exception{
		
		// 페이징 셋팅
		int pageNum = vo.getPageIndex() - 1;
		PageRequest page = new PageRequest(pageNum , 10, new Sort(Direction.DESC,"seq"));
	
		// 삭제한거는 안나오게 필터링
		Specifications<Content> spec = Specifications.where(SearchSpec.delYnEquals("N"));
		
		// 제목 검색
		if(vo.getSearchTxt() != null && !vo.getSearchTxt().equals("")) {
			spec = spec.and(SearchSpec.titleLike(vo.getSearchTxt()));
		}
				
		// 시작날짜 검색
		if(vo.getSearchStartDt() != null && !vo.getSearchStartDt().equals("")) {
			// String > Date 변환						
			String[] tmpStr = vo.getSearchStartDt().split("-");
			int searchYear = Integer.parseInt(tmpStr[0]);
			int searchMonth = Integer.parseInt(tmpStr[1]) - 1;
			int searchDay = Integer.parseInt(tmpStr[2]);
			Calendar cal = Calendar.getInstance();			
			cal.set(searchYear, searchMonth, searchDay, 0,0,0);
			cal.set(Calendar.MILLISECOND,0);			
			Date dt = cal.getTime();
			
			// 검색 조건 추가
			spec = spec.and(SearchSpec.regDtGreater(dt));
		}
		
		// 종료날짜 검색
		if(vo.getSearchEndDt() != null && !vo.getSearchEndDt().equals("")) {			
			// String > Date 변환						
			String[] tmpStr = vo.getSearchEndDt().split("-");
			int searchYear = Integer.parseInt(tmpStr[0]);
			int searchMonth = Integer.parseInt(tmpStr[1]) - 1;
			int searchDay = Integer.parseInt(tmpStr[2]);
			Calendar cal = Calendar.getInstance();			
			cal.set(searchYear, searchMonth, searchDay, 23,59,59);
			cal.set(Calendar.MILLISECOND,0);			
			Date dt = cal.getTime();
			
			// 검색조건 추가
			spec = spec.and(SearchSpec.regDtLess(dt));
		}
		
		
		// JPA 호출
		Page<RelateSiteVO> itemList = (Page<RelateSiteVO>) relateSiteRepository.findAll(spec,page);
		return itemList;
		
	}
	
	// 관련사이트 상세보기
	public RelateSiteVO selectRelateSiteDetail(RelateSiteVO vo) throws Exception{
		return relateSiteRepository.findOneBySeq(vo.getSeq());
	}
	
	// 관련사이트 등록/수정
	public void insertRelateSite(RelateSiteVO vo) throws Exception{		
		relateSiteRepository.saveAndFlush(vo);
	}
	
	
	// 관련사이트 삭제
	public void removeRelateSite(RelateSiteVO vo) throws Exception{
		
		int seq = vo.getSeq();
		String updId = vo.getUpdId();		
		relateSiteRepository.updateDelYn(seq,updId);
		
	}
	
	// 관련사이트 선택 삭제
	public void removeChkRelateSite(RelateSiteVO vo) throws Exception{
		
		String[] chkSeq = vo.getChkDel().split(",");
		String updId = vo.getUpdId();		
		for(int i = 0;i < chkSeq.length;i++) {
			int seq = Integer.parseInt(chkSeq[i]);			
			relateSiteRepository.updateDelYn(seq,updId);			
		}
		
	}
	
}
