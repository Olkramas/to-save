package com.sillasystem.partManage.service;

import java.util.List;



public class PartManageVO extends PartManage{
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 롤 목록
	 */	
	List <PartManageVO> roleManageList;
	/**
	 * 삭제대상 목록
	 */		
    String[] delYn;

	/**
	 * roleManageList attribute 를 리턴한다.
	 * @return List<RoleManageVO>
	 */
	public List<PartManageVO> getRoleManageList() {
		return roleManageList;
	}
	/**
	 * roleManageList attribute 값을 설정한다.
	 * @param roleManageList List<RoleManageVO> 
	 */
	public void setRoleManageList(List<PartManageVO> roleManageList) {
		this.roleManageList = roleManageList;
	}
	/**
	 * delYn attribute 를 리턴한다.
	 * @return String[]
	 */
	public String[] getDelYn() {
		return delYn;
	}
	/**
	 * delYn attribute 값을 설정한다.
	 * @param delYn String[] 
	 */
	public void setDelYn(String[] delYn) {
		this.delYn = delYn;
	}

}
