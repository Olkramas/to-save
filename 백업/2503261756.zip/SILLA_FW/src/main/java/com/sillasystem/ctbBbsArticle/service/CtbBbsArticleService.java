package com.sillasystem.ctbBbsArticle.service;

import java.util.Map;

public interface CtbBbsArticleService {

	Map<String, Object> selectBbsArticleList(Map<String, Object> paramMap);

}
