package com.sillasystem.schedule.service;

import java.util.List;


public interface ScheduleService {
	
	
	public List<PeakdayVO> getCalenderPeakdayList(String startDt,String endDt) throws Exception;
	
	public List<HolidayVO> getCalenderHolidayList(String startDt,String endDt) throws Exception;
	
	public List<HolidayVO> getHolidayList(HolidayVO vo) throws Exception;
	
	public HolidayVO getHolidayDtl(HolidayVO vo) throws Exception;
	
	public String saveHoliday(HolidayVO vo) throws Exception;
	
	public void removeHoliday(HolidayVO vo) throws Exception;
	
	public List<PeakdayVO> getPeakdayList(PeakdayVO vo) throws Exception;
	
	public PeakdayVO getPeakdayDtl(PeakdayVO vo) throws Exception;
	
	public String savePeakday(PeakdayVO vo) throws Exception;
	
	public void removePeakday(PeakdayVO vo) throws Exception;
	
	public String getHolidayDataApi(HolidayVO vo) throws Exception;
	
	
	
}
