package com.sillasystem.compMember.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.sillasystem.compMember.service.EgovEntrprsManageService;
import com.sillasystem.compMember.service.EntrprsManageVO;
import com.sillasystem.compMember.service.UserDefaultVO;
import com.sillasystem.member.service.UserManageVO;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.utl.sim.service.EgovFileScrty;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class CompMemberController {
	
	/** entrprsManageService */
	@Resource(name = "entrprsManageService")
	private EgovEntrprsManageService entrprsManageService;

	/** cmmUseService */
	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;
	
	// 기업 회원 목록
	@RequestMapping("/compMember/list.do")
    public String conpMemberList(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, ModelMap model) throws Exception{
		
		
		/** EgovPropertyService */
		userSearchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		userSearchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(userSearchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(userSearchVO.getPageUnit());
		paginationInfo.setPageSize(userSearchVO.getPageSize());

		userSearchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		userSearchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		userSearchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> userList = entrprsManageService.selectEntrprsMberList(userSearchVO);
		model.addAttribute("resultList", userList);

		int totCnt = entrprsManageService.selectEntrprsMberListTotCnt(userSearchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
				
		//사용자상태코드를 코드정보로부터 조회
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		vo.setCodeId("COM013");
		List<?> emplyrSttusCode_result = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("emplyrSttusCode_result", emplyrSttusCode_result);//사용자상태코드목록
		
		model.addAttribute("userSearchVO", userSearchVO);
		
		
        return "com/sillasystem/compMember/list";
    }
	
	// 기업 회원 등록
	@RequestMapping("/compMember/regist.do")
    public String conpMemberRegist(@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, @ModelAttribute("entrprsManageVO") EntrprsManageVO entrprsManageVO, Model model) throws Exception{
		
		
		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//패스워드힌트목록을 코드정보로부터 조회
		vo.setCodeId("COM022");
		List<?> passwordHint_result = cmmUseService.selectCmmCodeDetail(vo);
		//성별구분코드를 코드정보로부터 조회
		vo.setCodeId("COM014");
		List<?> sexdstnCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//사용자상태코드를 코드정보로부터 조회
		vo.setCodeId("COM013");
		List<?> entrprsMberSttus_result = cmmUseService.selectCmmCodeDetail(vo);
		//그룹정보를 조회 - GROUP_ID정보
		vo.setTableNm("COMTNORGNZTINFO");
		List<?> groupId_result = cmmUseService.selectGroupIdDetail(vo);
		//기업구분코드를 코드정보로부터 조회 - COM026
		vo.setCodeId("COM026");
		List<?> entrprsSeCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//업종코드를 코드정보로부터 조회 - COM027
		vo.setCodeId("COM027");
		List<?> indutyCode_result = cmmUseService.selectCmmCodeDetail(vo);
		
		entrprsManageVO.setModGbn("R");
		model.addAttribute("entrprsManageVO", entrprsManageVO);

		model.addAttribute("passwordHint_result", passwordHint_result); //패스워트힌트목록
		model.addAttribute("sexdstnCode_result", sexdstnCode_result); //성별구분코드목록
		model.addAttribute("entrprsMberSttus_result", entrprsMberSttus_result);//사용자상태코드목록
		model.addAttribute("groupId_result", groupId_result); //그룹정보 목록
		model.addAttribute("entrprsSeCode_result", entrprsSeCode_result); //기업구분코드 목록
		model.addAttribute("indutyCode_result", indutyCode_result); //업종코드목록
		
		
        return "com/sillasystem/compMember/regist";
    }
	
	// 기업회원 수정
	@RequestMapping("/compMember/update.do")
    public String conpMemberUpdate(@RequestParam("selectedId") String entrprsmberId,@ModelAttribute("userSearchVO") UserDefaultVO userSearchVO, @ModelAttribute("entrprsManageVO") EntrprsManageVO entrprsManageVO, Model model) throws Exception{
		
		
		ComDefaultCodeVO vo = new ComDefaultCodeVO();

		//패스워드힌트목록을 코드정보로부터 조회
		vo.setCodeId("COM022");
		List<?> passwordHint_result = cmmUseService.selectCmmCodeDetail(vo);
		//성별구분코드를 코드정보로부터 조회
		vo.setCodeId("COM014");
		List<?> sexdstnCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//사용자상태코드를 코드정보로부터 조회
		vo.setCodeId("COM013");
		List<?> entrprsMberSttus_result = cmmUseService.selectCmmCodeDetail(vo);
		//그룹정보를 조회 - GROUP_ID정보
		vo.setTableNm("COMTNORGNZTINFO");
		List<?> groupId_result = cmmUseService.selectGroupIdDetail(vo);
		//기업구분코드를 코드정보로부터 조회 - COM026
		vo.setCodeId("COM026");
		List<?> entrprsSeCode_result = cmmUseService.selectCmmCodeDetail(vo);
		//업종코드를 코드정보로부터 조회 - COM027
		vo.setCodeId("COM027");
		List<?> indutyCode_result = cmmUseService.selectCmmCodeDetail(vo);
		
		EntrprsManageVO retVo = new EntrprsManageVO();
		
		retVo = entrprsManageService.selectEntrprsmber(entrprsmberId);		
		model.addAttribute("userSearchVO", userSearchVO);
		
		
		// 이메일 자르기
		String[] emailAdres = retVo.getApplcntEmailAdres().split("@");
		retVo.setApplcntEmailAdres1(emailAdres[0]);
		retVo.setApplcntEmailAdres2(emailAdres[1]);
		
		retVo.setModGbn("U");
		model.addAttribute("entrprsManageVO", retVo);

		model.addAttribute("passwordHint_result", passwordHint_result); //패스워트힌트목록
		model.addAttribute("sexdstnCode_result", sexdstnCode_result); //성별구분코드목록
		model.addAttribute("entrprsMberSttus_result", entrprsMberSttus_result);//사용자상태코드목록
		model.addAttribute("groupId_result", groupId_result); //그룹정보 목록
		model.addAttribute("entrprsSeCode_result", entrprsSeCode_result); //기업구분코드 목록
		model.addAttribute("indutyCode_result", indutyCode_result); //업종코드목록
		
		
        return "com/sillasystem/compMember/regist";
    }
	
	// 기업회원 등록/수정 처리
	@RequestMapping(value = "/compMember/CompMemberProcess.do")
	public String CompMemberProcess(@ModelAttribute("entrprsManageVO") EntrprsManageVO entrprsManageVO, BindingResult bindingResult, Model model,RedirectAttributes ra) throws Exception {
		
		if ("".equals(entrprsManageVO.getGroupId())) {//KISA 보안약점 조치 (2018-10-29, 윤창원)
			entrprsManageVO.setGroupId(null);
		}
		
		// 이메일 합치기		
		String applcntEmailAdres = entrprsManageVO.getApplcntEmailAdres1() + "@" + entrprsManageVO.getApplcntEmailAdres2();
		
		entrprsManageVO.setApplcntEmailAdres(applcntEmailAdres);
		
		if(entrprsManageVO.getModGbn().equals("R")){
			System.out.println("등록간다.");
			entrprsManageService.insertEntrprsmber(entrprsManageVO);
			
			//Exception 없이 진행시 등록성공메시지
			ra.addFlashAttribute("flash.msg", "success.common.insert");
		}else if(entrprsManageVO.getModGbn().equals("U")) {
			//userManageService.updateUser(userManageVO);
			System.out.println("수정합니데이");
			entrprsManageService.updateEntrprsmber(entrprsManageVO);
			//Exception 없이 진행시 수정성공메시지
			ra.addFlashAttribute("flash.msg", "success.common.update");			
		}
		
		return "redirect:/compMember/list.do";		
    
	}
	
	// 회원 비밀번호 변경 처리
	@RequestMapping(value = "/compMember/changePassword.do")
	public ModelAndView changePassword(HttpServletRequest request, @ModelAttribute("userManageVO") EntrprsManageVO entrprsManageVO, BindingResult bindingResult, Model model,RedirectAttributes ra) throws Exception {
		
		String newPassword2 = request.getParameter("passwordre");
		String oldPassword = entrprsManageVO.getOldPassword();
		String newPassword = entrprsManageVO.getEntrprsMberPassword();
				
		boolean isCorrectPassword = false;
		String resultYn  = "";
		String resultMsg = "";
		EntrprsManageVO resultVO = new EntrprsManageVO();
		resultVO = entrprsManageService.selectPassword(entrprsManageVO);
		//패스워드 암호화				
		String encryptPass = EgovFileScrty.encryptPassword(oldPassword, entrprsManageVO.getEntrprsmberId());		
		if (encryptPass.equals(resultVO.getEntrprsMberPassword())) {						
			if (newPassword.equals(newPassword2)) {				
				isCorrectPassword = true;
			} else {				
				isCorrectPassword = false;
				resultYn  = "N";
				resultMsg = "비밀번호가 잘못 입력되었습니다.";
			}
		} else {			
			isCorrectPassword = false;
			resultYn  = "N";
			resultMsg = "기존 비밀번호가 일치하지 않습니다.";
		}
		
		if (isCorrectPassword) {			
			entrprsManageVO.setEntrprsMberPassword(EgovFileScrty.encryptPassword(newPassword, entrprsManageVO.getEntrprsmberId()));
			System.out.println(">>>" + entrprsManageVO.getEntrprsMberPassword());
			entrprsManageService.updatePassword(entrprsManageVO);
			model.addAttribute("entrprsManageVO", entrprsManageVO);
			resultYn  = "Y";
			resultMsg = "정상적으로 수정되었습니다.";
		}
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("jsonView");
		modelAndView.addObject("resultYn", resultYn);
		modelAndView.addObject("resultMsg", resultMsg);
		
		return modelAndView;		
    
	}
	
	// 로그인인증제한 해제 
	@RequestMapping(value = "/compMember/UnLockIncorrect.do")
	public ModelAndView CompUnLockIncorrect(@ModelAttribute("userManageVO") EntrprsManageVO entrprsManageVO, BindingResult bindingResult, Model model) throws Exception {
		
		entrprsManageService.updateLockIncorrect(entrprsManageVO);
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("jsonView");
		modelAndView.addObject("resultYn", "Y");
		modelAndView.addObject("resultMsg", "정상적으로 제한해제되었습니다.");
		
		return modelAndView;		
    
	}
	
	// 회원삭제
	@RequestMapping(value = "/compMember/deleteMember.do")
	public ModelAndView compDeleteMember(@RequestParam("checkedIdForDel") String checkedIdForDel, Model model) throws Exception {
		
		entrprsManageService.deleteEntrprsmber(checkedIdForDel);
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("jsonView");
		modelAndView.addObject("resultYn", "Y");
		modelAndView.addObject("resultMsg", "정상적으로 삭제되었습니다.");
		
		return modelAndView;		
    
	}
	
}
