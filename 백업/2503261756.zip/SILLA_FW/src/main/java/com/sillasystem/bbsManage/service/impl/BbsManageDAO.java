package com.sillasystem.bbsManage.service.impl;

import egovframework.com.cmm.service.impl.EgovComAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository("bbsManageDAO")
public class BbsManageDAO extends EgovComAbstractDAO {

    public List<EgovMap> selectbbsManageList (Map<String,Object> paramMap) throws Exception{
        return (List<EgovMap>) list("bbsManageDAO.selectbbsManageList", paramMap);
    }

    public int bbsManageListCnt (Map<String,Object> paramMap) throws Exception {
        return (Integer)selectOne("bbsManageDAO.bbsManageListCnt", paramMap);
    }

    public EgovMap selectBbsMastView(Map<String,Object> paramMap){
        return selectOne("bbsManageDAO.selectBbsMastView", paramMap);
    }

    public List<EgovMap> selectBbsMastManagerList(Map<String,Object> paramMap){
        return (List<EgovMap>)list("bbsManageDAO.selectBbsMastManagerList", paramMap);
    }

    public void insertBbsMast (Map<String,Object> paramMap){
        insert("bbsManageDAO.insertBbsMast",paramMap);
    }

    public void updateBbsMast (Map<String,Object> paramMap){
        update("bbsManageDAO.updateBbsMast", paramMap);
    }

    public void deleteBbsMast (Map<String,Object> paramMap){
        update("bbsManageDAO.deleteBbsMast", paramMap);
    }

    public void insertBbsManager (Map<String,Object> paramMap){
        insert("bbsManageDAO.insertBbsManager",paramMap);
    }

    public void deleteBbsManager (Map<String,Object> paramMap){
        delete("bbsManageDAO.deleteBbsManager", paramMap);
    }

    public int duplicateCheck (Map<String,Object> paramMap){
        return (Integer) selectOne("bbsManageDAO.duplicateCheck", paramMap);
    }

    public EgovMap selectOffenseWordsMap () {
        return selectOne("bbsManageDAO.selectOffenseWordsMap");
    }

    public void updateOffenseWordsManage (Map<String,Object> paramMap) {
        update("bbsManageDAO.updateOffenseWordsManage", paramMap);
    }

    public EgovMap selectBbsCategoryDetail (Map<String,Object> paramMap) {
        return selectOne("bbsManageDAO.selectBbsCategoryDetail",paramMap);
    }

    public List<EgovMap> selectBbsCategoryList (Map<String,Object> paramMap) {
        return (List<EgovMap>) list("bbsManageDAO.selectBbsCategoryList",paramMap);
    }

    public void mergeBbsCategory (Map<String,Object> paramMap){
        update("bbsManageDAO.mergeBbsCategory", paramMap);
    }

    public void deleteBbsCategory (Map<String,Object> paramMap){
        delete("bbsManageDAO.deleteBbsCategory", paramMap);
    }
}
