/**
 * 
 * 관련사이트 관리 JPA 검색 SPEC
 * 
 * @version v1.0
 * @since 2019. 05. 11
 * @author pyonkm
 *
 */
package com.sillasystem.relateSite.repository;

import java.util.Date;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.swing.text.AbstractDocument.Content;

import org.springframework.data.jpa.domain.Specification;

public class SearchSpec {
	// 삭제여부 체크
	public static Specification<Content> delYnEquals(String keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("delYn"),keyword);
            		}
		};
	}
	
	// 제목 LIKE 검색
	public static Specification<Content> titleLike(String keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.like(root.get("title"), "%" + keyword + "%");
            }
		};
	}
	
	// 등록 시작일 검색
	public static Specification<Content> regDtGreater(Date keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.greaterThanOrEqualTo(root.get("regDt"),keyword);
            }
		};
	}
	
	// 등록 종료일 검색
	public static Specification<Content> regDtLess(Date keyword){
		return new Specification<Content>() {
			@Override
            public Predicate toPredicate(Root<Content> root,
            		CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.lessThanOrEqualTo(root.get("regDt"),keyword);
            }
		};
	}
}
