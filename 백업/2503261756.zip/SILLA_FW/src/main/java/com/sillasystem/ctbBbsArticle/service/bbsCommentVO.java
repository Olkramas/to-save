package com.sillasystem.ctbBbsArticle.service;

import java.io.Serializable;

import lombok.Data;

@Data
public class bbsCommentVO implements Serializable {
	
	private static final long serialVersionUID = -5089277634600047382L;
	
	private String commentId;	// 댓글 인덱스
	private String bbsArticleId;// 게시판 인덱스
	private String bbsId;		// 게시판 아이디
	private String bbsComment;	// 댓글 
	private String pass;		// 비밀번호
	private String regIp;		// 등록자IP
	private String delYn;		// 삭제여부
	private String regId;		// 등록자 아이디
	private String regDt;		// 등록일
	private String updId;		// 수정자 아이디
	private String updDt;		// 수정일
	private String regName;		// 등록자명
	private int recordCountPerPage;
	private int firstIndex;
	
	public String getCommentId() {
		return commentId;
	}
	public void setCommentId(String commentId) {
		this.commentId = commentId;
	}
	public String getBbsArticleId() {
		return bbsArticleId;
	}
	public void setBbsArticleId(String bbsArticleId) {
		this.bbsArticleId = bbsArticleId;
	}
	public String getBbsId() {
		return bbsId;
	}
	public void setBbsId(String bbsId) {
		this.bbsId = bbsId;
	}
	public String getBbsComment() {
		return bbsComment;
	}
	public void setBbsComment(String bbsComment) {
		this.bbsComment = bbsComment;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getRegIp() {
		return regIp;
	}
	public void setRegIp(String regIp) {
		this.regIp = regIp;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegId() {
		return regId;
	}
	public void setRegId(String regId) {
		this.regId = regId;
	}
	public String getRegDt() {
		return regDt;
	}
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
	public String getUpdId() {
		return updId;
	}
	public void setUpdId(String updId) {
		this.updId = updId;
	}
	public String getUpdDt() {
		return updDt;
	}
	public void setUpdDt(String updDt) {
		this.updDt = updDt;
	}
	public String getRegName() {
		return regName;
	}
	public void setRegName(String regName) {
		this.regName = regName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getRecordCountPerPage() {
		return recordCountPerPage;
	}
	public void setRecordCountPerPage(int recordCountPerPage) {
		this.recordCountPerPage = recordCountPerPage;
	}
	public int getFirstIndex() {
		return firstIndex;
	}
	public void setFirstIndex(int firstIndex) {
		this.firstIndex = firstIndex;
	}
	@Override
	public String toString() {
		return "bbsCommentVO [commentId=" + commentId + ", bbsArticleId=" + bbsArticleId + ", bbsId=" + bbsId
				+ ", bbsComment=" + bbsComment + ", pass=" + pass + ", regIp=" + regIp + ", delYn=" + delYn + ", regId="
				+ regId + ", regDt=" + regDt + ", updId=" + updId + ", updDt=" + updDt + ", regName=" + regName
				+ ", recordCountPerPage=" + recordCountPerPage + ", firstIndex=" + firstIndex + "]";
	}
	
}
