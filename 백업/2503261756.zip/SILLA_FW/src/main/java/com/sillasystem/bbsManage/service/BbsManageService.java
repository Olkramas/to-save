package com.sillasystem.bbsManage.service;

import egovframework.rte.psl.dataaccess.util.EgovMap;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

public interface BbsManageService {


    public Map<String, Object> bbsManageList(Map<String,Object> paramMap) throws  Exception;

    public EgovMap selectBbsMastView(Map<String,Object> paramMap) throws Exception;

    public List<EgovMap> selectBbsMastManagerList(Map<String,Object> paramMap) throws Exception;

    public void insertBbsManage (Map<String,Object> paramMap) throws Exception;

    public void updateBbsManage (Map<String,Object> paramMap) throws Exception;

    public int duplicateCheck (Map<String,Object> paramMap) throws Exception;

    public void deleteBbsMast (Map<String,Object> paramMap) throws Exception;

    public EgovMap selectOffenseWordsMap () throws Exception;

    public void updateOffenseWordsManage (Map<String,Object> paramMap) throws Exception;

    public EgovMap selectBbsCategoryDetail (Map<String,Object> paramMap) throws Exception;

    public List<EgovMap> selectBbsCategoryList (Map<String,Object> paramMap) throws Exception;

    public void mergeBbsCategory (Map<String,Object> paramMap) throws Exception;

    public void deleteBbsCategory (Map<String,Object> paramMap) throws Exception;
}
