package com.sillasystem.bat.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springmodules.validation.commons.DefaultBeanValidator;

import com.sillasystem.bat.service.BatOpertService;
import com.sillasystem.bat.validation.BatOpertValidator;
import com.sillasystem.bat.vo.BatOpertVO;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
@Controller
public class BatOpertController {
	

	/** egovBatchOpertService */
	
	/* Property 서비스 */
	@Resource(name = "propertiesService")
	private EgovPropertyService propertyService;
	
	@Resource(name = "batOpertService")
	private BatOpertService batOpertService;

	/** EgovMessageSource */
	@Resource(name = "egovMessageSource")
	EgovMessageSource egovMessageSource;
	
	@Autowired
	private DefaultBeanValidator beanValidator;
	
	/* batchOpert bean validator */
	@Resource(name = "batOpertValidator")
	private BatOpertValidator batchOpertValidator;
	
	/** ID Generation */
	@Resource(name = "egovBatchOpertIdGnrService")
	private EgovIdGnrService idgenService;
	
	/**
	 * 배치작업을  리스트 보여준다
	 * @return 리턴URL
	 *
	 * @param batchOpert 삭제대상 배치작업model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@IncludedInfo(name = "배치작업관리", listUrl = "/batopert/list.do", order = 1120, gid = 80)
	@RequestMapping(value = {"/batopert/list.do","/batopert/Pop.do"})
	public String ListBatchOpert(
			@ModelAttribute("searchVO") BatOpertVO searchVO, ModelMap model , @RequestParam(value = "popupAt", required = false) String popupAt) throws Exception {
		searchVO.setPageUnit(propertyService.getInt("pageUnit"));
		searchVO.setPageSize(propertyService.getInt("pageSize"));
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		List<BatOpertVO> resultList = batOpertService.selectBatchOpertList(searchVO);
		int totCnt = batOpertService.selectBatchOpertListCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("resultList", resultList);
		model.addAttribute("resultCnt", totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		
		if ("Y".equals(popupAt)) {
			// Popup 화면이면
			System.out.println("*************************");
			return "com/sillasystem/bat/batchOpertPop";
		} else {
			// 메인화면 호출이면
			return "com/sillasystem/bat/batchOpertList";
		}
	}
	
	/**
	 * 배치작업을 등록한다.
	 * @return 리턴URL
	 *
	 * @param batchOpert 등록대상 배치작업model
	 * @param bindingResult	BindingResult
	 * @param model			ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batopert/add.do")
	public String insertBatchOpert(BatOpertVO batchOpert, BindingResult bindingResult, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}
		System.out.println("batchOpert == " + batchOpert.getBatchProgrm() + batchOpert.getBatchOpertNm());
		//로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
		beanValidator.validate(batchOpert, bindingResult);
		batchOpertValidator.validate(batchOpert, bindingResult);
		
		if (!bindingResult.hasErrors()) {
			System.out.println("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ");
			return "com/sillasystem/bat/batchOpertList";
		} else {
			batchOpert.setBatchOpertId(idgenService.getNextStringId());
			//아이디 설정
			batchOpert.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
			batchOpert.setFrstRegisterId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));

			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ");
			batOpertService.insertBatchOpert(batchOpert);
			//Exception 없이 진행시 등록성공메시지
			model.addAttribute("resultMsg", "success.common.insert");
		}
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		return "forward:/batopert/list.do";
	}
	
	/**
	 * 등록화면을 위한 배치작업정보을 조회한다.
	 * @return 리턴URL
	 *
	 * @param batchOpert 조회대상 배치작업model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batopert/insert.do")
	public String selectBatchOpertForRegist(@ModelAttribute("searchVO") BatOpertVO batchOpert, ModelMap model) throws Exception {
		model.addAttribute("batchOpert", batchOpert);

		return "com/sillasystem/bat/batchOpertRegist";
	}
	/** 
	 * 배치작업정보을 상세조회한다.
	 * @return 리턴URL
	 *
	 * @param batchOpert 조회대상 배치작업model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batopert/detail.do")
	public String selectBatchOpert(@ModelAttribute("searchVO") BatOpertVO batchOpert, ModelMap model) throws Exception {
		
		BatOpertVO result = batOpertService.selectBatchOpert(batchOpert);
		model.addAttribute("resultInfo", result);
		return "com/sillasystem/bat/batchOpertDetail";
	}
	
	/**
	 * 배치작업을 수정한다.
	 * @return 리턴URL
	 *
	 * @param batchOpert 수정대상 배치작업model
	 * @param bindingResult		BindingResult
	 * @param model				ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batopert/uptComplete.do")
	public String updateBatchOpert(BatOpertVO batchOpert, BindingResult bindingResult, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}
		//로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		beanValidator.validate(batchOpert, bindingResult);
		batchOpertValidator.validate(batchOpert, bindingResult);
		if (!bindingResult.hasErrors()) {
			model.addAttribute("batchOpert", batchOpert);
			return "com/sillasystem/bat/batchOpertUpdt";
		}

		// 정보 업데이트
		System.out.println("::::::::::::::::::::::::::::");
		batchOpert.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
		batOpertService.updateBatchOpert(batchOpert);

		return "forward:/batopert/list.do";

	}
	
	/**
	 * 배치작업 조회팝업을 실행한다.
	 * @return 리턴URL
	 *
	 * @param searchVO 목록조회조건VO
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
/*	@RequestMapping("/batopert/Pop.do")
	public String openPopupWindow(@ModelAttribute("searchVO") BatOpertVO searchVO, ModelMap model) throws Exception {
		return "com/sillasystem/bat/batchOpertPop";
	}*/
	
	/**
	 * 배치작업을 삭제한다.
	 * @return 리턴URL
	 *
	 * @param batchOpert 삭제대상 배치작업model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batopert/delete.do")
	public String deleteBatchOpert(BatOpertVO batchOpert, ModelMap model) throws Exception {
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}

		batOpertService.deleteBatchOpert(batchOpert);

		return "forward:/batopert/list.do";
	}
	
	/**
	 * 수정화면을 위한 배치작업정보을 조회한다.
	 * @return 리턴URL
	 *
	 * @param batchOpert 조회대상 배치작업model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batopert/update.do")
	public String selectBatchOpertForUpdate(@ModelAttribute("searchVO") BatOpertVO batchOpert, ModelMap model) throws Exception {
		BatOpertVO result = batOpertService.selectBatchOpert(batchOpert);
		model.addAttribute("batchOpert", result);
		return "com/sillasystem/bat/batchOpertUpdt";
	}
}
