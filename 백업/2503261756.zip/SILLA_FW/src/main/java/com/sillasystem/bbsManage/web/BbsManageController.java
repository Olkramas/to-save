package com.sillasystem.bbsManage.web;

import com.sillasystem.bbsManage.service.BbsManageService;
import com.sillasystem.member.service.EgovUserManageService;
import com.sillasystem.member.service.UserManageVO;
import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@Controller
public class BbsManageController {

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** bbsManageService **/
    @Resource(name = "bbsManageService")
    protected BbsManageService bbsManageService;

    /** cmmUseService */
    @Resource(name = "EgovCmmUseService")
    private EgovCmmUseService cmmUseService;

    /** userManageService */
    @Resource(name = "userManageService")
    private EgovUserManageService userManageService;

    /**
     * 게시판 관리 리스트
     * @param paramMap
     * @param request
     * @param response
     * @param session
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/bbsManage/list.do")
    public String bbsManageList(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            ModelMap map
    ) throws Exception {

        if (paramMap.containsKey("pageIndex") == false || StringUtils.isEmpty(String.valueOf(paramMap.get("pageIndex")) ) == true){
            paramMap.put("pageIndex","1");
        }

        PaginationInfo paginationInfo = new PaginationInfo();

        paginationInfo.setCurrentPageNo(Integer.parseInt(String.valueOf(paramMap.get("pageIndex"))));
        paginationInfo.setRecordCountPerPage(propertiesService.getInt("pageUnit"));
        paginationInfo.setPageSize(propertiesService.getInt("pageSize"));

        paramMap.put("firstIndex", paginationInfo.getFirstRecordIndex());
        paramMap.put("lastIndex", paginationInfo.getLastRecordIndex());
        paramMap.put("recordCountPerPage",paginationInfo.getRecordCountPerPage());

        Map<String, Object> modelMap = bbsManageService.bbsManageList(paramMap);

        int totCnt = Integer.parseInt((String)modelMap.get("resultCnt"));
        paginationInfo.setTotalRecordCount(totCnt);

        map.addAttribute("bbsMastList", modelMap.get("resultList"));
        map.addAttribute("resultCnt", modelMap.get("resultCnt"));
        map.addAttribute("paginationInfo", paginationInfo);
        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/bbsManage/list";
    }

    /**
     * 게시판 관리 등록 / 수정 폼
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/bbsManage/bbsManageRegForm.do")
    public String bbsManageRegForm(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {

        ComDefaultCodeVO vo = new ComDefaultCodeVO();

        //게시판 종류
        vo.setCodeId("SIL002");
        List<?> boardType = cmmUseService.selectCmmCodeDetail(vo);
        map.addAttribute("boardType",boardType);

        vo.setCodeId("SIL003");
        List<?> boardSkin = cmmUseService.selectCmmCodeDetail(vo);
        map.addAttribute("boardSkin",boardSkin);


        List<UserManageVO> memberAuthList = userManageService.selectAuthorInfo("Y");
        map.addAttribute("memberAuthList", memberAuthList);

        //수정폼
        if(paramMap.get("bbsId") != null && !String.valueOf(paramMap.get("bbsId")).equals("")){
            map.addAttribute("bbsMastView", bbsManageService.selectBbsMastView(paramMap));
            map.addAttribute("bbsMastManagerList", bbsManageService.selectBbsMastManagerList(paramMap));
            map.addAttribute("categoryList", bbsManageService.selectBbsCategoryList(paramMap));
        }

        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/bbsManage/regForm";
    }

    /**
     * 게시판 관리 등록 프로세스
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/bbsManage/bbsManageWriteAjax.do", method = RequestMethod.POST)
    public ModelAndView bbsManageWriteAjax(
            @RequestParam Map<String,Object> paramMap,
            @RequestParam(value = "regLevel", defaultValue = "") String[] regLevel
    ) throws Exception {
        ModelAndView mv = new ModelAndView("jsonView");

        paramMap.put("regLevel", regLevel);

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());

        bbsManageService.insertBbsManage(paramMap);

        return mv;
    }

    /**
     * 게시판 관리 수정 프로세스
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsManage/bbsManageUpdateAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsManageUpdateAjax(
            @RequestParam Map<String,Object> paramMap,
            @RequestParam(value = "regLevel", defaultValue = "") String[] regLevel
    ) throws Exception {
        ModelAndView mv = new ModelAndView("jsonView");

        paramMap.put("regLevel", regLevel);

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId",user.getId());
        paramMap.put("updId",user.getId());

        bbsManageService.updateBbsManage(paramMap);

        return mv;
    }

    /**
     * 중복체크
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsManage/duplicateCheckAjax.do", method=RequestMethod.POST)
    public ModelAndView duplicateCheckAjax(
            @RequestParam Map<String,Object> paramMap
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");

        mv.addObject("result", bbsManageService.duplicateCheck(paramMap));

        return mv;
    }

    /**
     * 위반단어 입력폼
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/offenseWordsManage/regForm.do")
    public ModelAndView offenseWordManage() throws Exception{
        ModelAndView mv = new ModelAndView("com/sillasystem/bbsManage/offenseWordsForm");

        mv.addObject("offenseMap",bbsManageService.selectOffenseWordsMap());

        return mv;
    }

    /**
     * 위반단어 수정 프로세스
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/offenseWordsManage/updateOffenseWordsManageAjax.do")
    public ModelAndView updateOffenseWordsManageAjax (
            @RequestParam Map<String,Object> paramMap
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");

        bbsManageService.updateOffenseWordsManage(paramMap);

        return mv;
    }

    /**
     * 게시판 카테고리 등록 및 수정 폼
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/bbsManage/bbsCategoryRegFormAjax.do")
    public String bbsCategoryRegForm(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception{

        map.addAttribute("paramMap", paramMap);
        if(paramMap.containsKey("categorySeq")){
            map.addAttribute("bbsCategoryDetail", bbsManageService.selectBbsCategoryDetail(paramMap));
        }

        return "com/sillasystem/bbsManage/bbsCategoryRegFormPop";
    }

    /**
     * 게시판 카테고리 등록
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsManage/bbsCategoryWriteAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsCategoryWriteAjax(
            @RequestParam Map<String,Object> paramMap,
            HttpSession session
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId",user.getId());
        paramMap.put("updId",user.getId());

        bbsManageService.mergeBbsCategory(paramMap);

        mv.addObject("categoryList", bbsManageService.selectBbsCategoryList(paramMap));

        return mv;
    }


    /**
     * 게시판 카테고리 삭제
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsManage/bbsCategoryDeleteAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsCategoryDeleteAjax(
            @RequestParam Map<String,Object> paramMap,
            HttpSession session
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        //삭제
        bbsManageService.deleteBbsCategory(paramMap);

        //리스트
        mv.addObject("categoryList", bbsManageService.selectBbsCategoryList(paramMap));

        return mv;
    }

    /**
     * 게시판 삭제
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsManage/bbsDeleteAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsDeleteAjax(
            @RequestParam Map<String,Object> paramMap
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId",user.getId());
        paramMap.put("updId",user.getId());

        //삭제처리 DEL_YN -> Y
        bbsManageService.deleteBbsMast(paramMap);

        return mv;
    }

    /**
     * 게시판 삭제 취소
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/bbsManage/bbsDeleteCancleAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsDeleteCancleAjax(
            HttpSession session
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        return mv;
    }
}
