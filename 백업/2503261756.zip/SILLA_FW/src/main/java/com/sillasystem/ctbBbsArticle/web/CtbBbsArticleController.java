package com.sillasystem.ctbBbsArticle.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.sillasystem.common.SillaFileUtil;
import com.sillasystem.ctbBbsArticle.service.bbsCommentVO;
import com.sillasystem.ctbBbsArticle.service.impl.CtbBbsArticleServiceImpl;
import com.sillasystem.ctbBbsManage.service.impl.CtbBbsManageServiceImpl;

import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.filter.HTMLTagFilterRequestWrapper;
import egovframework.com.cmm.service.FileVO;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.utl.sim.service.EgovClntInfo;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
public class CtbBbsArticleController {
	
	/** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** bbsManageService **/
    @Resource(name = "ctbBbsManageService")
    protected CtbBbsManageServiceImpl bbsManageService;

    /** bbsArticleService **/
    @Resource(name = "ctbBbsArticleService")
    protected CtbBbsArticleServiceImpl bbsArticleService;

    @Resource(name = "egovFileIdGnrService")
    private EgovIdGnrService egovFileIdGnrService;

    /** EgovMessageSource */
    @Resource(name="egovMessageSource")
    EgovMessageSource egovMessageSource;

    @Resource(name="sillaFileUtil")
    SillaFileUtil sillaFileUtil;
    
    /**
     * 게시글 리스트
     * @param paramMap
     * @param request
     * @param response
     * @param session
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBbsArticle/list.do")
    public String bbsArticleList(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session,
            ModelMap map
    ) throws Exception {
    	
    	//페이지 관련 설정
        if(paramMap.containsKey("pageIndex") == false || StringUtils.isEmpty(String.valueOf(paramMap.get("pageIndex"))) == true){
            paramMap.put("pageIndex", "1");
        }
        //첫 요청일 때 pageIndex가 없어서 1페이지로 만듦
        
        PaginationInfo paginationInfo = new PaginationInfo();

        EgovMap bbsMstInfo = bbsManageService.selectBbsMastView(paramMap);

        //게시판 설정, 정보
        map.addAttribute("bbsMastView", bbsMstInfo);
        
        //페이지에 게시글 몇개 들어오는지 저장하는 변수
        int pageUnit = (int) bbsMstInfo.get("listCount");
        
        paginationInfo.setCurrentPageNo(Integer.parseInt(String.valueOf(paramMap.get("pageIndex"))));//현재 페이지 정보 == pageIndex
        paginationInfo.setRecordCountPerPage(pageUnit);//한 페이지 당 게시글 개수 설정

        paginationInfo.setPageSize(propertiesService.getInt("pageSize"));//페이지 개수
        
        paramMap.put("firstIndex", paginationInfo.getFirstRecordIndex());//페이징 첫 숫자
        paramMap.put("lastIndex", paginationInfo.getLastRecordIndex());//페이지 마지막 숫자
        paramMap.put("recordCountPerPage",paginationInfo.getRecordCountPerPage());	//한 페이지 당 게시글 개수
        
        //게시글 리스트
        Map<String,Object> modelMap = bbsArticleService.selectBbsArticleList(paramMap);
        
        int totCnt = Integer.parseInt((String)modelMap.get("resultCnt"));	//게시글 총 개수
        paginationInfo.setTotalRecordCount(totCnt);	//페이징 객체에 담기
		
        map.addAttribute("bbsArticleList", modelMap.get("resultList"));
        map.addAttribute("resultCnt", totCnt);
        map.addAttribute("paginationInfo",paginationInfo);
        map.addAttribute("paramMap", paramMap);
        
        return "com/sillasystem/ctbBbsArticle/"+paramMap.get("bbsType")+"/list";
    }

    
    /**
     * 게시글 등록 / 수정  이동
     * @param paramMap
     * @param request
     * @param response
     * @param map 
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBbsArticle/ctbBbsArticleRegForm.do")
    public String bbsArticleRegForm(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {
    	
    	// 권한 가지고 오기
    	LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
    	HashMap<String, Object> authParam = new HashMap<String, Object>();
    	authParam.put("userId", user.getId());
    	authParam.put("bbsId", paramMap.get("bbsId"));         
    	map.addAttribute("auth",bbsManageService.selectBbsAuth(authParam));    	
    	// 권한 가지고 오기 끝
    	
        //게시판 정보
        map.addAttribute("bbsMastView",bbsManageService.selectBbsMastView(paramMap));
        
        //수정
        if (paramMap.containsKey("bbsArticleId")){
            //상세조회
            Map<String,Object> bbsArticleVO = bbsArticleService.selectBbsArticleView(paramMap);
            map.addAttribute("bbsArticleVO", bbsArticleVO);

            //첨부파일조회
            List<FileVO> fileList = sillaFileUtil.getFileList(String.valueOf(bbsArticleVO.get("atchFileId")));
            map.addAttribute("fileList", fileList);

        }

        //파라미터
        map.addAttribute("paramMap", paramMap);

        return "com/sillasystem/ctbBbsArticle/"+paramMap.get("bbsType")+"/regForm";
    }
    
    /**
     * 게시글 뷰
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBbsArticle/view.do")
    public String bbsArticleView(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {
        
        //상세조회
        Map<String,Object> bbsArticleVO = bbsArticleService.selectBbsArticleView(paramMap);
        map.addAttribute("bbsArticleVO", bbsArticleVO);
        
        EgovMap bbsMstInfo = bbsManageService.selectBbsMastView(paramMap);
        //게시판 설정, 정보
        map.addAttribute("bbsMastView", bbsMstInfo);
        
        //첨부파일조회
        List<FileVO> fileList = sillaFileUtil.getFileList(String.valueOf(bbsArticleVO.get("atchFileId")));
        map.addAttribute("fileList", fileList);
        
        //파라미터
        map.addAttribute("paramMap",paramMap);
        
        return "com/sillasystem/ctbBbsArticle/"+paramMap.get("bbsType")+"/view";
    }
    
    /**
     * 게시글 등록 실행
     * @param request
     * @param response
     * @param modelMap
     * @return
     */
    @RequestMapping(value="/ctbBbsArticle/ctbBbsArticleRegAjax.do", method= RequestMethod.POST)
    public ModelAndView bbsArticleReg(
            final MultipartHttpServletRequest multiRequest
            , @RequestParam Map<String,Object> paramMap
            , HttpServletResponse response
            , ModelMap modelMap
            , HttpServletRequest request
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");
        
        //html 코드가 escape된 문자열을 다시 html 코드로 변환
        String updateExcapeStr = paramMap.get("content").toString().replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"");
        
        //변환시킨 html코드를 db에 insert
        paramMap.put("content", updateExcapeStr);
        
        //위반단어검사
        ModelAndView modelAndView = offenseWordsCheck(paramMap);
        if (modelAndView != null){return modelAndView;}

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
        
        //db에 넣을 등록, 수정자 아이디
        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());
        
        //첨부파일, 업로드 경로 구하기
        String uploadPath = propertiesService.getString("Globals.fileStorePath") + "/bbs/";
        
        //첨부파일 업로드, db에 mst, dtls정보 insert
        String retFileIda = sillaFileUtil.uploadFile(multiRequest, uploadPath, null);
        
        //첨부파일 성공이후 atchFileId return;
        paramMap.put("atchFileId", retFileIda);        
        
        //게시글 등록
        bbsArticleService.insertBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.insert"));

        return mv;
    }
    
    //공격적인 단어 체크 함수
    public ModelAndView offenseWordsCheck(Map<String,Object> paramMap) throws Exception {
        Map<String,Object> retMap = new HashMap<>();
        
        //공격적인 단어 db에서 검색
        Map<String,Object> offenseWord =  bbsManageService.selectOffenseWordsMap();
        
        // ,로 구별된 공격적인 단어 문자열을 잘라서 배열로 만듦
        String checkWords[] = String.valueOf(offenseWord.get("offenseWord")).split(",");
        
        //제목
        String title = paramMap.get("title") == null ? "" : String.valueOf(paramMap.get("title"));
        //내용
        String content = paramMap.get("content") == null ? "" : String.valueOf(paramMap.get("content"));
        //댓글
        String reply = paramMap.get("reply") == null ? "" : String.valueOf(paramMap.get("reply"));
        
        //공격적인 단어 개수만큼 반복문실행
        for(int i=0; i<checkWords.length; i++){
        	
        	//조건에 걸리면 실패 정보를 담고 있는 Map 반환
            if(
                title.indexOf(checkWords[i])>-1 || content.indexOf(checkWords[i])>-1 || reply.indexOf(checkWords[i])>-1
            ){
                retMap.put("result", "OFFENSE_WORD");
                retMap.put("failContent", checkWords[i]);
                return new ModelAndView("jsonView", retMap);
            }
        }
        
        return null;
    }
    
    /**
     * 게시글 수정 실행
     * @param multiRequest
     * @param response
     * @param modelMap
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBbsArticle/ctbBbsArticleModAjax.do", method=RequestMethod.POST)
    public ModelAndView bbsArticleMod(
            final MultipartHttpServletRequest multiRequest
            , @RequestParam Map<String,Object> paramMap
            , HttpServletResponse response
            , ModelMap modelMap
            , HttpServletRequest request
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");
        
        //html 코드가 escape된 문자열을 다시 html 코드로 변환
        String updateExcapeStr = paramMap.get("content").toString().replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"");
        
        //변환시킨 html코드를 db에 insert
        paramMap.put("content", updateExcapeStr);
        
        //완료 또는 실패후 메시지
        Map<String,Object> resultMap = new HashMap<>();

        //위반단어검사
        ModelAndView modelAndView = offenseWordsCheck(paramMap);
        if (modelAndView != null){return modelAndView;}

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());
        
        
        //첨부파일
        String atchFileId = String.valueOf(paramMap.get("atchFileId"));
        String uploadPath = propertiesService.getString("Globals.fileStorePath") + "/bbs/";
        String retFileIda = sillaFileUtil.uploadFile(multiRequest, uploadPath, atchFileId);

        //첨부파일 성공이후 atchFileId return;
        paramMap.put("atchFileId", retFileIda);
        
        //게시글 수정
        bbsArticleService.updateBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.insert"));

        return mv;
    }
    
    /**
     * 게시글 삭제
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBbsArticle/delete.do", method=RequestMethod.POST)
    public ModelAndView bbsArticleDelete(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map,
            HttpSession session
    ) throws Exception{

        ModelAndView mv = new ModelAndView("jsonView");

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

        paramMap.put("regId", user.getId());
        paramMap.put("updId", user.getId());

        //게시글 수정
        bbsArticleService.deleteBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.delete"));

        return mv;
    }
    
    
    /**
     * 액셀파일 게시글 등록 이동
     * @param request
     * @param response
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBbsArticle/excel.do")
    public String bbsArticleExcel(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map
    ) throws Exception {
    	
    	//게시판 정보
        map.addAttribute("bbsMastView",bbsManageService.selectBbsMastView(paramMap));
        
        //파라미터
        map.addAttribute("paramMap", paramMap);
        
        //페이지 처음 이동할 때는 null이어야 함.
        map.addAttribute("exList", null);

        return "com/sillasystem/ctbBbsArticle/"+paramMap.get("bbsType")+"/exRegForm";
    }
    /**
     * 액셀파일 서버에서 읽고 뷰로 보내기
     * @param paramMap
     * @param request
     * @param response
     * @param map
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBbsArticle/excel.do", method=RequestMethod.POST)
    public String bbsArticleExcelRegist(
            @RequestParam Map<String,Object> paramMap,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap map,
            HttpSession session
    ) throws Exception{
    	
    	//System.out.println("request 클래스: " + request.getClass().getName());
    	
    	//원래의 요청으로 변환
    	HttpServletRequest originalRequest = (HttpServletRequest) request;
    	if (originalRequest instanceof HTMLTagFilterRequestWrapper) {
    	    originalRequest = (HttpServletRequest) ((HTMLTagFilterRequestWrapper) originalRequest).getRequest();
    	}
    	
    	//파라미터
        map.addAttribute("paramMap", paramMap);
        
    	try {
    		List<HashMap<Object, Object>> readInfo = bbsArticleService.readExcel(originalRequest);//리스트를 만들어서 뷰로 전달
    		map.addAttribute("exList", readInfo);
		} catch (Exception ex) {
			//액셀 파일 형식이 아닐 경우
			map.addAttribute("exList", null);
		}
        
    	return "com/sillasystem/ctbBbsArticle/"+paramMap.get("bbsType")+"/exRegForm";
    }
    
    /**
     * 게시글 액셀 등록 실행
     * @param request
     * @param response
     * @param modelMap
     * @return
     */
    @ResponseBody
    @RequestMapping(value="/ctbBbsArticle/ctbBbsArticleExcelRegAjax.do", method= RequestMethod.POST)
    public ModelAndView bbsArticleExcelReg(
    		  //@RequestParam(value="infoList[]")List<BoardExcelInsertDAO> boardList
    		  @RequestParam Map<String,Object> paramMap
            , HttpServletResponse response
            , ModelMap modelMap
            , HttpServletRequest request
    ) throws Exception{
        ModelAndView mv = new ModelAndView("jsonView");  
        
        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
        
        //db에 넣을 등록, 수정자 아이디
        paramMap.put("userId", user.getId());
        
        bbsArticleService.insertExcelBbsArticle(paramMap);

        //완료 메세지
        mv.addObject("retMsg", egovMessageSource.getMessage("success.common.insert"));

        return mv;
    }
    
    /**
     * 액셀 다운로드
     * @param paramMap
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBbsArticle/ctbExport.do")
    public ModelAndView BbsListexportExcel(
            @RequestParam Map<String,Object> paramMap
    ) throws Exception {
        //게시글 리스트
    	List<EgovMap> list = bbsArticleService.selectSearchList(paramMap);
        
    	// 엑셀다운로드
		String[] headerList = { "제목", "내용", "작성자", "작성일", "수정자", "수정일" };	//헤더 정의
		List<String> header = new ArrayList<>(Arrays.asList(headerList));	//배열을 리스트로 변환
    	
		String[] columnList = { "title", "content", "regId", "regDt", "updId", "updDt" };	// DB컬럼 액셀 파일 내 출력 순서
		List<String> column = new ArrayList<>(Arrays.asList(columnList));
		
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("title", "게시물 리스트");	//액셀 파일 내부 1행에 출력할 문자열
		map.put("header", header);
		map.put("column", column);
		map.put("fileName", "게시물 검색결과");	//파일명
		map.put("data", list);
		
		return new ModelAndView("excelView", map);
    }
    
    /**
     * 댓글 조회
     * @param paramMap
     * @param response
     * @param session
     * @param map
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/ctbBbsArticle/commentAjax.do")
    public String bbsComment(@RequestParam Map<String,Object> paramMap,
    		                 HttpServletRequest request,HttpServletResponse response,
    		                 HttpSession session,
    		                 ModelMap map) throws Exception {
        if(paramMap.containsKey("pageIndexComment") == false || StringUtils.isEmpty(String.valueOf(paramMap.get("pageIndexComment"))) == true){
            paramMap.put("pageIndexComment", "1");
        }
        
        PaginationInfo paginationInfo = new PaginationInfo();

        //페이지에 게시글 몇 개 들어오는지 저장하는 변수
        int pageUnit = 10;
        
        paginationInfo.setCurrentPageNo(Integer.parseInt(String.valueOf(paramMap.get("pageIndexComment"))));//현재 페이지 정보 == pageIndex
        paginationInfo.setRecordCountPerPage(pageUnit);//한 페이지 당 게시글 개수 설정

    	// 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
        
    	// 댓글 가지고 오기
        bbsCommentVO comVo = new bbsCommentVO();
        comVo.setBbsId(paramMap.get("bbsId").toString());
        comVo.setBbsArticleId(paramMap.get("bbsArticleId").toString());
        comVo.setRegId(user.getId());
        comVo.setRecordCountPerPage(pageUnit);
        comVo.setFirstIndex(paginationInfo.getFirstRecordIndex());
        
        List<EgovMap> commentList = bbsArticleService.selectBbsComment(comVo);
        
        int totalRecordCnt = bbsArticleService.selectBbsCommentCnt(comVo);
        paginationInfo.setTotalRecordCount(totalRecordCnt);
        paginationInfo.setPageSize(10);//페이지 개수
        
        String userId = user.getId();
        String userNm = user.getName();
        
        for(int i = 0;i < commentList.size();i++) {
        	EgovMap commentMap = commentList.get(i);
        	String bbsComment = commentMap.get("bbsComment").toString().replaceAll("<br />","\r\n");
        	commentMap.put("bbsCommentNh", bbsComment);
        	commentList.set(i, commentMap);        	
        }

        paramMap.put("firstIndex", paginationInfo.getFirstRecordIndex());//페이징 첫 숫자
        paramMap.put("lastIndex", paginationInfo.getLastRecordIndex());//페이지 마지막 숫자
        paramMap.put("recordCountPerPage",paginationInfo.getRecordCountPerPage());	//한 페이지 당 게시글 개수
        
        map.addAttribute("totalRecordCount", totalRecordCnt );
        map.addAttribute("paginationInfo",paginationInfo);
        map.addAttribute("commentList",commentList);
        map.addAttribute("userId",userId);
        map.addAttribute("userNm",userNm);
        map.addAttribute("paramMap",paramMap);
        
        return "com/sillasystem/ctbBbsArticle/commentAjax";
    }
    
    /**
     * 댓글 등록
     * @param vo
     * @param request
     * @param response
     * @param map
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBbsArticle/regComment.do", method=RequestMethod.POST)
    public ModelAndView regComment(bbsCommentVO vo,
    							   HttpServletRequest request,
    							   HttpServletResponse response,
    							   ModelMap map,
    							   HttpSession session) throws Exception{
    	
    	
    	
        ModelAndView mv = new ModelAndView("jsonView");

        // 로그인 정보 가지고 오기
        LoginVO user = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();
        
        vo.setRegId(user.getId());
        vo.setRegName(user.getName());
        
        // 아이피 가지고 오기
        String regIp = EgovClntInfo.getClntIP((HttpServletRequest) request);
        vo.setRegIp(regIp);
        
        String bbsComment = vo.getBbsComment().replaceAll("\r\n","<br />");        
        vo.setBbsComment(bbsComment);
        
        //댓글 등록
        bbsArticleService.insertBbsComment(vo);

        //완료 메세지
        mv.addObject("retMsg", "Y");

        return mv;
    }
    
    /**
     * 댓글 삭제
     * @param vo
     * @param request
     * @param response
     * @param map
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/ctbBbsArticle/delComment.do", method=RequestMethod.POST)
    public ModelAndView delComment(bbsCommentVO vo,
    							   HttpServletRequest request,
    							   HttpServletResponse response,
    							   ModelMap map,
    							   HttpSession session) throws Exception{
    	
    	//댓글 삭제
        bbsArticleService.deleteBbsComment(Integer.parseInt(vo.getCommentId()));
    	
    	ModelAndView mv = new ModelAndView("jsonView");
    	//완료 메세지
        mv.addObject("delMsg", "Y");
    	return mv;
    	
    }
}
