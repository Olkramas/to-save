package com.sillasystem.bat.web;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springmodules.validation.commons.DefaultBeanValidator;

import com.sillasystem.bat.service.BatScheduleService;
import com.sillasystem.bat.service.BatScheduler;
import com.sillasystem.bat.vo.BatScheduleVO;

import egovframework.com.cmm.ComDefaultCodeVO;
import egovframework.com.cmm.EgovMessageSource;
import egovframework.com.cmm.LoginVO;
import egovframework.com.cmm.annotation.IncludedInfo;
import egovframework.com.cmm.service.CmmnDetailCode;
import egovframework.com.cmm.service.EgovCmmUseService;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.com.utl.fcc.service.EgovStringUtil;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class BatScheduleController {
	
	/** egovBatchSchdulService */
	@Resource(name = "batScheduleService")
	private BatScheduleService batScheduleService;

	/* Property 서비스 */
	@Resource(name = "propertiesService")
	private EgovPropertyService propertyService;

	/* 메세지 서비스 */
	@Resource(name = "egovMessageSource")
	private EgovMessageSource egovMessageSource;

	/* common  validator */
	@Autowired
	private DefaultBeanValidator beanValidator;

	/** ID Generation */
	@Resource(name = "egovBatchSchdulIdGnrService")
	private EgovIdGnrService idgenService;

	/** cmmUseService */
	@Resource(name = "EgovCmmUseService")
	private EgovCmmUseService cmmUseService;

	/** 배치스케줄러 서비스 */
	@Resource(name = "batScheduler")
	private BatScheduler batScheduler;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BatScheduleController.class);


	/**
	 * 배치스케줄을 삭제한다.
	 * @return 리턴URL
	 *
	 * @param batchSchdul 삭제대상 배치스케줄model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batschdule/delete.do")
	public String deleteBatchSchdul(BatScheduleVO batchSchdul, ModelMap model) throws Exception {
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}

		// 배치스케줄러에 스케줄정보반영
		batScheduler.deleteBatchSchdul(batchSchdul);

		batScheduleService.deleteBatchSchdul(batchSchdul);

		return "forward:/batschdule/list.do";
	}

	/**
	 * 배치스케줄을 등록한다.
	 * @return 리턴URL
	 *
	 * @param batchSchdul 등록대상 배치스케줄model
	 * @param bindingResult	BindingResult
	 * @param model			ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batschdule/add.do")
	public String insertBatchSchdul(BatScheduleVO batchSchdul, BindingResult bindingResult, ModelMap model) throws Exception {
		LOGGER.debug(" 인서트 대상정보 : {}", batchSchdul);

		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}

		//로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		beanValidator.validate(batchSchdul, bindingResult);
		if (bindingResult.hasErrors()) {
			referenceData(model);
			return "com/sillasystem/bat/batchSchduleRegist";
		} else {
			batchSchdul.setBatchSchdulId(idgenService.getNextStringId());
			//아이디 설정
			batchSchdul.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
			batchSchdul.setFrstRegisterId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));

			batScheduleService.insertBatchSchdul(batchSchdul);

			// 배치스케줄러에 스케줄정보반영
			BatScheduleVO target = batScheduleService.selectBatchSchdul(batchSchdul);
			batScheduler.insertBatchSchdul(target);

			//Exception 없이 진행시 등록성공메시지
			model.addAttribute("resultMsg", "success.common.insert");
		}
		return "forward:/batschdule/list.do";
	}

	/**
	 * 배치스케줄정보을 상세조회한다.
	 * @return 리턴URL
	 *
	 * @param batchSchdul 조회대상 배치스케줄model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batschdule/detail.do")
	public String selectBatchSchdul(@ModelAttribute("searchVO") BatScheduleVO batchSchdul, ModelMap model) throws Exception {
		LOGGER.debug(" 조회조건 : {}", batchSchdul);
		BatScheduleVO result = batScheduleService.selectBatchSchdul(batchSchdul);
		model.addAttribute("resultInfo", result);
		LOGGER.debug(" 결과값 : {}", result);

		return "com/sillasystem/bat/batchSchduleDetail";
	}

	/**
	 * 등록화면을 위한 배치스케줄정보을 조회한다.
	 * @return 리턴URL
	 *
	 * @param batchSchdul 조회대상 배치스케줄model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batschdule/insert.do")
	public String selectBatchSchdulForRegist(@ModelAttribute("searchVO") BatScheduleVO batchSchdul, ModelMap model) throws Exception {
		referenceData(model);

		model.addAttribute("batchSchdul", batchSchdul);

		return "com/sillasystem/bat/batchSchduleRegist";
	}

	/**
	 * 수정화면을 위한 배치스케줄정보을 조회한다.
	 * @return 리턴URL
	 *
	 * @param batchSchdul 조회대상 배치스케줄model
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batschdule/update.do")
	public String selectBatchSchdulForUpdate(@ModelAttribute("searchVO") BatScheduleVO batchSchdul, ModelMap model) throws Exception {
		referenceData(model);

		LOGGER.debug(" 조회조건 : {}", batchSchdul);
		BatScheduleVO result = batScheduleService.selectBatchSchdul(batchSchdul);
		model.addAttribute("batchSchdul", result);
		LOGGER.debug(" 결과값 : {}", result);

		return "com/sillasystem/bat/batchSchduleUpdt";
	}

	/**
	 * Reference Data 를 설정한다.
	 * @param model   화면용spring Model객체
	 * @throws Exception
	 */
	private void referenceData(ModelMap model) throws Exception {
		ComDefaultCodeVO vo = new ComDefaultCodeVO();
		//DBMS종류코드목록을 코드정보로부터 조회
		vo.setCodeId("COM047");
		List<CmmnDetailCode> executCycleList = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("executCycleList", executCycleList);
		//요일구분코드목록을 코드정보로부터 조회
		vo.setCodeId("COM074");
		List<CmmnDetailCode> executSchdulDfkSeList = cmmUseService.selectCmmCodeDetail(vo);
		model.addAttribute("executSchdulDfkSeList", executSchdulDfkSeList);

		// 실행스케줄 시, 분, 초 값 설정.
		Map<String, String> executSchdulHourList = new LinkedHashMap<String, String>();
		for (int i = 0; i < 24; i++) {
			if (i < 10) {
				executSchdulHourList.put("0" + Integer.toString(i), "0" + Integer.toString(i));
			} else {
				executSchdulHourList.put(Integer.toString(i), Integer.toString(i));
			}
		}
		model.addAttribute("executSchdulHourList", executSchdulHourList);
		Map<String, String> executSchdulMntList = new LinkedHashMap<String, String>();
		for (int i = 0; i < 60; i++) {
			if (i < 10) {
				executSchdulMntList.put("0" + Integer.toString(i), "0" + Integer.toString(i));
			} else {
				executSchdulMntList.put(Integer.toString(i), Integer.toString(i));
			}
		}
		model.addAttribute("executSchdulMntList", executSchdulMntList);
		Map<String, String> executSchdulSecndList = new LinkedHashMap<String, String>();
		for (int i = 0; i < 60; i++) {
			if (i < 10) {
				executSchdulSecndList.put("0" + Integer.toString(i), "0" + Integer.toString(i));
			} else {
				executSchdulSecndList.put(Integer.toString(i), Integer.toString(i));
			}
		}
		model.addAttribute("executSchdulSecndList", executSchdulSecndList);
	}

	/**
	 * 배치스케줄 목록을 조회한다.
	 * @return 리턴URL
	 *
	 * @param searchVO 목록조회조건VO
	 * @param model		ModelMap
	 * @exception Exception Exception
	 */
	@SuppressWarnings("unchecked")
	@IncludedInfo(name = "스케줄처리", listUrl = "/batschdule/list.do", order = 1122, gid = 80)
	@RequestMapping("/batschdule/list.do")
	public String selectBatchSchdulList(@ModelAttribute("searchVO") BatScheduleVO searchVO, ModelMap model) throws Exception {
		searchVO.setPageUnit(propertyService.getInt("pageUnit"));
		searchVO.setPageSize(propertyService.getInt("pageSize"));

		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<BatScheduleVO> resultList = (List<BatScheduleVO>) batScheduleService.selectBatchSchdulList(searchVO);
		int totCnt = batScheduleService.selectBatchSchdulListCnt(searchVO);

		paginationInfo.setTotalRecordCount(totCnt);

		model.addAttribute("resultList", resultList);
		model.addAttribute("resultCnt", totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "com/sillasystem/bat/batchSchduleList";
	}

	/**
	 * 배치스케줄을 수정한다.
	 * @return 리턴URL
	 *
	 * @param batchSchdul 수정대상 배치스케줄model
	 * @param bindingResult		BindingResult
	 * @param model				ModelMap
	 * @exception Exception Exception
	 */
	@RequestMapping("/batschdule/uptcomplete.do")
	public String updateBatchSchdul(BatScheduleVO batchSchdul, BindingResult bindingResult, ModelMap model) throws Exception {
		// 0. Spring Security 사용자권한 처리
		Boolean isAuthenticated = EgovUserDetailsHelper.isAuthenticated();
		if (!isAuthenticated) {
			model.addAttribute("message", egovMessageSource.getMessage("fail.common.login"));
			return "com/sillasystem/login/login";
		}
		//로그인 객체 선언
		LoginVO loginVO = (LoginVO) EgovUserDetailsHelper.getAuthenticatedUser();

		beanValidator.validate(batchSchdul, bindingResult);
		if (bindingResult.hasErrors()) {
			referenceData(model);
			model.addAttribute("batchSchdul", batchSchdul);
			return "com/sillasystem/bat/batchSchduleUpdt";
		}

		// 정보 업데이트
		batchSchdul.setLastUpdusrId(loginVO == null ? "" : EgovStringUtil.isNullToString(loginVO.getUniqId()));
		batScheduleService.updateBatchSchdul(batchSchdul);

		// 배치스케줄러에 스케줄정보반영
		BatScheduleVO target = batScheduleService.selectBatchSchdul(batchSchdul);
		batScheduler.updateBatchSchdul(target);

		return "forward:/batschdule/list.do";

	}
	
	/**
	 * 일반달력 팝업 메인창을 호출한다.
	 * @param model
	 * @return "egovframework/com/sym/cal/EgovNormalCalPopup"
	 * @throws Exception
	 */
	@RequestMapping(value="/batschdule/CalPopup.do")
 	public String callNormalCalPopup (ModelMap model
 			) throws Exception {
		return "com/sillasystem/bat/batchSchdulecalPopup";
	}
	
	
	/**
	 * 일반달력 팝업 정보를 조회한다.
	 * @param restde
	 * @param model
	 * @return "egovframework/com/sym/cal/EgovNormalCalendar"
	 * @throws Exception
	 *//*
	@RequestMapping(value="/sym/cal/EgovselectNormalCalendar.do")
 	public String selectNormalRestdePopup (Restde restde, BindingResult bindingResult
 			, ModelMap model
 			) throws Exception {

		//2011.10.18 달력 출력을 위해 필요한 숫자 이외의 값을 사용하는 경우 체크
		bindingResult = checkRestdeWithValidator(restde, bindingResult);

		if(bindingResult.hasErrors()){

			return "egovframework/com/cmm/error/dataAccessFailure";

		}

		Calendar cal = Calendar.getInstance();

		if(restde.getYear()==null || restde.getYear().equals("")){
			restde.setYear(Integer.toString(cal.get(Calendar.YEAR)));
		}
		if(restde.getMonth()==null || restde.getMonth().equals("")){
			restde.setMonth(Integer.toString(cal.get(Calendar.MONTH)+1));
		}
		int iYear  = Integer.parseInt(restde.getYear());
		int iMonth = Integer.parseInt(restde.getMonth());

		if (iMonth<1){
			iYear--;
			iMonth = 12;
		}
		if (iMonth>12){
			iYear++;
			iMonth = 1;
		}
		if (iYear<1){
			iYear = 1;
			iMonth = 1;
		}
		if (iYear>9999){
			iYear = 9999;
			iMonth = 12;
		}
		restde.setYear(Integer.toString(iYear));
		restde.setMonth(Integer.toString(iMonth));

		cal.set(iYear,iMonth-1,1);

		restde.setStartWeekMonth(cal.get(Calendar.DAY_OF_WEEK));
		restde.setLastDayMonth(cal.getActualMaximum(Calendar.DATE));

        List<?> CalInfoList = restdeManageService.selectNormalRestdePopup(restde);

        model.addAttribute("resultList", CalInfoList);

		return "egovframework/com/sym/cal/EgovNormalCalendar";
	}*/
}
